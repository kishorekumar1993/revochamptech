class MockTestSession {
  final String id;
  final String title;
  final String description;
  final String category;
  final int timeLimitMinutes;
  final int passingScore;
  final List<Question> questions;

  MockTestSession({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.timeLimitMinutes,
    required this.passingScore,
    required this.questions,
  });

  factory MockTestSession.fromJson(Map<String, dynamic> json) {
    return MockTestSession(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      category: json['category'],
      timeLimitMinutes: json['timeLimitMinutes'],
      passingScore: json['passingScore'],
      questions: (json['questions'] as List)
          .map((e) => Question.fromJson(e))
          .toList(),
    );
  }
}

class Question {
  final String id;
  final String question;
  final List<String> options;
  final int correctAnswer;
  final String explanation;
  final String? difficulty;

  Question({
    required this.id,
    required this.question,
    required this.options,
    required this.correctAnswer,
    required this.explanation,
    this.difficulty,
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      id: json['id'],
      question: json['question'],
      options: List<String>.from(json['options']),
      correctAnswer: json['correctAnswer'], // ✅ IMPORTANT
      explanation: json['explanation'],
      difficulty: json['difficulty'],
    );
  }
}

// class MockTestQuestion {
//   final String id;
//   final String question;
//   final List<String> options;
//   final int correctAnswer; // Index of correct option (0-based)
//   final String explanation;
//   final String? category;
//   final String? difficulty;

//   MockTestQuestion({
//     required this.id,
//     required this.question,
//     required this.options,
//     required this.correctAnswer,
//     required this.explanation,
//     this.category,
//     this.difficulty,
//   });

//   factory MockTestQuestion.fromJson(Map<String, dynamic> json) {
//     return MockTestQuestion(
//       id: json['id']?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString(),
//       question: json['question'] ?? '',
//       options: List<String>.from(json['options'] ?? []),
//       correctAnswer: json['answer'] ?? 0,
//       explanation: json['explanation'] ?? 'No explanation provided.',
//       category: json['category'],
//       difficulty: json['difficulty'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'id': id,
//       'question': question,
//       'options': options,
//       'answer': correctAnswer,
//       'explanation': explanation,
//       'category': category,
//       'difficulty': difficulty,
//     };
//   }
// }

// class MockTestSession {
//   final String id;
//   final String title;
//   final String description;
//   final List<MockTestQuestion> questions;
//   final int timeLimitMinutes;
//   final int passingScore;
//   final String? category;

//   MockTestSession({
//     required this.id,
//     required this.title,
//     required this.description,
//     required this.questions,
//     this.timeLimitMinutes = 0,
//     this.passingScore = 70,
//     this.category,
//   });

//   factory MockTestSession.fromJson(Map<String, dynamic> json) {
//     final questionsList = json['questions'] as List? ?? [];
//     return MockTestSession(
//       id: json['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
//       title: json['title'] ?? 'Mock Test',
//       description: json['description'] ?? 'Test your knowledge',
//       questions: questionsList.map((q) => MockTestQuestion.fromJson(q)).toList(),
//       timeLimitMinutes: json['timeLimitMinutes'] ?? 0,
//       passingScore: json['passingScore'] ?? 70,
//       category: json['category'],
//     );
//   }
// }

// class UserAnswer {
//   final String questionId;
//   final int selectedAnswer;
//   final bool isCorrect;
//   final DateTime answeredAt;

//   UserAnswer({
//     required this.questionId,
//     required this.selectedAnswer,
//     required this.isCorrect,
//     required this.answeredAt,
//   });
// }