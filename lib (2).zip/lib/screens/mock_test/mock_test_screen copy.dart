// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'dart:async';
// import 'dart:math' as math;

// // ==================== PREMIUM DATA MODELS ====================

// class UserAnswer {
//   final String questionId;
//   final int selectedAnswer;
//   final bool isCorrect;
//   final DateTime answeredAt;
//   final int timeSpentSeconds;
//   final bool usedHint;
  
//   UserAnswer({
//     required this.questionId,
//     required this.selectedAnswer,
//     required this.isCorrect,
//     required this.answeredAt,
//     this.timeSpentSeconds = 0,
//     this.usedHint = false,
//   });
// }

// class Question {
//   final String id;
//   final String question;
//   final List<String> options;
//   final int correctAnswer;
//   final String explanation;
//   final String? difficulty;
//   final String? topic;
//   final int points;
//   final List<String>? hints;
//   final String? imageUrl;

//   Question({
//     required this.id,
//     required this.question,
//     required this.options,
//     required this.correctAnswer,
//     required this.explanation,
//     this.difficulty,
//     this.topic,
//     this.points = 10,
//     this.hints,
//     this.imageUrl,
//   });

//   factory Question.fromJson(Map<String, dynamic> json) {
//     return Question(
//       id: json['id']?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString(),
//       question: json['question'] ?? '',
//       options: List<String>.from(json['options'] ?? []),
//       correctAnswer: json['correctAnswer'] ?? 0,
//       explanation: json['explanation'] ?? 'No explanation provided.',
//       difficulty: json['difficulty'],
//       topic: json['topic'],
//       points: json['points'] ?? 10,
//       hints: json['hints'] != null ? List<String>.from(json['hints']) : null,
//       imageUrl: json['imageUrl'],
//     );
//   }
// }

// class TestStatistics {
//   final int totalQuestions;
//   final int answered;
//   final int correct;
//   final int incorrect;
//   final int unattempted;
//   final int totalPoints;
//   final int earnedPoints;
//   final double accuracy;
//   final double averageTimePerQuestion;
//   final int totalTimeSpent;
//   final int hintsUsed;

//   TestStatistics({
//     required this.totalQuestions,
//     required this.answered,
//     required this.correct,
//     required this.incorrect,
//     required this.unattempted,
//     required this.totalPoints,
//     required this.earnedPoints,
//     required this.accuracy,
//     required this.averageTimePerQuestion,
//     required this.totalTimeSpent,
//     required this.hintsUsed,
//   });
// }

// class MockTestSession {
//   final String id;
//   final String title;
//   final String description;
//   final String category;
//   final int timeLimitMinutes;
//   final int passingScore;
//   final List<Question> questions;
//   final String? imageUrl;
//   final List<String>? tags;
//   final int totalPoints;
//   final String? difficulty;

//   MockTestSession({
//     required this.id,
//     required this.title,
//     required this.description,
//     required this.category,
//     required this.timeLimitMinutes,
//     required this.passingScore,
//     required this.questions,
//     this.imageUrl,
//     this.tags,
//     this.totalPoints = 0,
//     this.difficulty,
//   });

//   factory MockTestSession.fromJson(Map<String, dynamic> json) {
//     final questionsList = (json['questions'] as List?)
//         ?.map((e) => Question.fromJson(e))
//         .toList() ?? [];
    
//     final totalPoints = questionsList.fold(0, (sum, q) => sum + q.points);
    
//     return MockTestSession(
//       id: json['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
//       title: json['title'] ?? 'Mock Test',
//       description: json['description'] ?? 'Test your knowledge',
//       category: json['category'] ?? 'general',
//       timeLimitMinutes: json['timeLimitMinutes'] ?? 0,
//       passingScore: json['passingScore'] ?? 70,
//       questions: questionsList,
//       imageUrl: json['imageUrl'],
//       tags: json['tags'] != null ? List<String>.from(json['tags']) : null,
//       totalPoints: totalPoints,
//       difficulty: json['difficulty'],
//     );
//   }
// }

// // ==================== PREMIUM THEME ====================

// class PremiumThemes {
//   // Modern Gradient Colors
//   static const Color primary = Color(0xFF6C63FF);
//   static const Color secondary = Color(0xFF3F3D9E);
//   static const Color accent = Color(0xFFFF6584);
//   static const Color success = Color(0xFF00D09C);
//   static const Color error = Color(0xFFFF5A5A);
//   static const Color warning = Color(0xFFFFB347);
//   static const Color info = Color(0xFF4A90E2);
  
//   // Background Colors
//   static const Color darkBackground = Color(0xFF0A0E27);
//   static const Color lightBackground = Color(0xFFF8F9FF);
//   static const Color cardBackground = Color(0xFFFFFFFF);
  
//   // Gradients
//   static const LinearGradient primaryGradient = LinearGradient(
//     begin: Alignment.topLeft,
//     end: Alignment.bottomRight,
//     colors: [Color(0xFF6C63FF), Color(0xFF3F3D9E)],
//   );
  
//   static const LinearGradient accentGradient = LinearGradient(
//     begin: Alignment.topLeft,
//     end: Alignment.bottomRight,
//     colors: [Color(0xFFFF6584), Color(0xFFFF8C42)],
//   );
  
//   static const LinearGradient successGradient = LinearGradient(
//     begin: Alignment.topLeft,
//     end: Alignment.bottomRight,
//     colors: [Color(0xFF00D09C), Color(0xFF00A87E)],
//   );
  
//   static const LinearGradient errorGradient = LinearGradient(
//     begin: Alignment.topLeft,
//     end: Alignment.bottomRight,
//     colors: [Color(0xFFFF5A5A), Color(0xFFE74C3C)],
//   );
  
//   // Shadows
//   static List<BoxShadow> get premiumShadow => [
//     BoxShadow(
//       color: Colors.black.withValues(alpha:0.08),
//       blurRadius: 20,
//       offset: const Offset(0, 8),
//       spreadRadius: 0,
//     ),
//     BoxShadow(
//       color: Colors.black.withValues(alpha:0.04),
//       blurRadius: 4,
//       offset: const Offset(0, 2),
//       spreadRadius: 0,
//     ),
//   ];
  
//   static List<BoxShadow> get glowShadow => [
//     BoxShadow(
//       color: primary.withValues(alpha:0.3),
//       blurRadius: 20,
//       offset: const Offset(0, 4),
//       spreadRadius: 0,
//     ),
//   ];
// }

// // ==================== CUSTOM PAINT ====================

// class WaveClipper extends CustomClipper<Path> {
//   @override
//   Path getClip(Size size) {
//     final path = Path();
//     path.lineTo(0, size.height - 40);
//     path.quadraticBezierTo(
//       size.width / 4, size.height,
//       size.width / 2, size.height - 30,
//     );
//     path.quadraticBezierTo(
//       3 * size.width / 4, size.height - 60,
//       size.width, size.height - 20,
//     );
//     path.lineTo(size.width, 0);
//     path.close();
//     return path;
//   }

//   @override
//   bool shouldReclip(CustomClipper<Path> oldClipper) => false;
// }

// class AnimatedBackground extends StatefulWidget {
//   final Widget child;
  
//   const AnimatedBackground({super.key, required this.child});
  
//   @override
//   State<AnimatedBackground> createState() => _AnimatedBackgroundState();
// }

// class _AnimatedBackgroundState extends State<AnimatedBackground> with SingleTickerProviderStateMixin {
//   late AnimationController _controller;
  
//   @override
//   void initState() {
//     super.initState();
//     _controller = AnimationController(
//       duration: const Duration(seconds: 20),
//       vsync: this,
//     )..repeat();
//   }
  
//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }
  
//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: _controller,
//       builder: (context, child) {
//         return Container(
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 PremiumThemes.lightBackground,
//                 Colors.white,
//                 PremiumThemes.lightBackground,
//               ],
//               stops: const [0, 0.5, 1],
//             ),
//           ),
//           child: child,
//         );
//       },
//       child: widget.child,
//     );
//   }
// }

// // ==================== MAIN SCREEN ====================

// class MockTestScreen extends StatefulWidget {
//   final String? testId;
//   final String? category;
  
//   const MockTestScreen({super.key, this.testId, this.category});
  
//   @override
//   State<MockTestScreen> createState() => _MockTestScreenState();
// }

// class _MockTestScreenState extends State<MockTestScreen> with TickerProviderStateMixin {
//   // Core data
//   MockTestSession? _testSession;
//   bool _isLoading = true;
//   String? _error;
  
//   // User progress
//   final Map<String, UserAnswer> _userAnswers = {};
//   int _currentIndex = 0;
//   bool _isTestSubmitted = false;
//   int _currentScore = 0;
//   int _hintsUsed = 0;
  
//   // UI State
//   bool _showExplanation = false;
//   int? _selectedAnswerForCurrent;
//   bool _isHintVisible = false;
//   int _timeSpentOnCurrentQuestion = 0;
//   Timer? _questionTimer;
  
//   // Timer service
//   Timer? _countdownTimer;
//   int _remainingTimeSeconds = 0;
  
//   // Animation controllers
//   late AnimationController _progressController;
//   late Animation<double> _progressAnimation;
//   late AnimationController _pulseController;
//   late AnimationController _shakeController;
  
//   @override
//   void initState() {
//     super.initState();
//     _progressController = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 800),
//     );
//     _pulseController = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 1500),
//     )..repeat(reverse: true);
//     _shakeController = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 500),
//     );
//     _loadMockTest();
//   }
  
//   @override
//   void dispose() {
//     _progressController.dispose();
//     _pulseController.dispose();
//     _shakeController.dispose();
//     _questionTimer?.cancel();
//     _countdownTimer?.cancel();
//     super.dispose();
//   }
  
//   Future<void> _loadMockTest() async {
//     try {
//       String fileName;
//       if (widget.testId != null) {
//         fileName = widget.testId!;
//       } else if (widget.category != null) {
//         fileName = '${widget.category}_mock_test';
//       } else {
//         fileName = 'sample';
//       }
      
//       final String jsonString = await rootBundle.loadString(
//         'assets/mock_tests/$fileName.json',
//       );
//       final jsonData = jsonDecode(jsonString);
      
//       setState(() {
//         _testSession = MockTestSession.fromJson(jsonData);
//         _isLoading = false;
//         _currentIndex = 0;
//         _startQuestionTimer();
        
//         if (_testSession!.timeLimitMinutes > 0) {
//           _startCountdownTimer();
//         }
        
//         _progressController.forward();
//       });
//     } catch (e) {
//       setState(() {
//         _error = e.toString();
//         _isLoading = false;
//       });
//     }
//   }
  
//   void _startCountdownTimer() {
//     _remainingTimeSeconds = _testSession!.timeLimitMinutes * 60;
//     _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
//       if (mounted && !_isTestSubmitted) {
//         if (_remainingTimeSeconds > 0) {
//           setState(() {
//             _remainingTimeSeconds--;
//           });
          
//           // Warning animation when time is low
//           if (_remainingTimeSeconds <= 60 && _remainingTimeSeconds % 10 == 0) {
//             _shakeController.forward(from: 0);
//           }
//         } else {
//           timer.cancel();
//           _autoSubmitTest();
//         }
//       }
//     });
//   }
  
//   void _startQuestionTimer() {
//     _questionTimer?.cancel();
//     _timeSpentOnCurrentQuestion = 0;
//     _questionTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
//       if (mounted && !_isTestSubmitted && !_showExplanation) {
//         setState(() {
//           _timeSpentOnCurrentQuestion++;
//         });
//       }
//     });
//   }
  
//   void _selectAnswer(int optionIndex) {
//     if (_isTestSubmitted || _showExplanation) return;
    
//     final question = _testSession!.questions[_currentIndex];
//     final isCorrect = optionIndex == question.correctAnswer;
    
//     // Haptic feedback
//     HapticFeedback.lightImpact();
    
//     if (isCorrect) {
//       setState(() {
//         _currentScore += question.points;
//       });
//       _pulseController.forward(from: 0);
//     }
    
//     setState(() {
//       _userAnswers[question.id] = UserAnswer(
//         questionId: question.id,
//         selectedAnswer: optionIndex,
//         isCorrect: isCorrect,
//         answeredAt: DateTime.now(),
//         timeSpentSeconds: _timeSpentOnCurrentQuestion,
//         usedHint: _isHintVisible,
//       );
//       _showExplanation = true;
//       _selectedAnswerForCurrent = optionIndex;
//     });
    
//     if (_isHintVisible) {
//       setState(() {
//         _hintsUsed++;
//       });
//     }
    
//     _questionTimer?.cancel();
    
//     // Auto advance after delay
//     Future.delayed(const Duration(milliseconds: 2500), () {
//       if (mounted && _showExplanation && _currentIndex < _testSession!.questions.length - 1) {
//         _nextQuestion();
//       }
//     });
//   }
  
//   void _nextQuestion() {
//     if (_currentIndex < _testSession!.questions.length - 1) {
//       setState(() {
//         _currentIndex++;
//         _showExplanation = false;
//         _selectedAnswerForCurrent = null;
//         _isHintVisible = false;
//       });
//       _startQuestionTimer();
      
//       // Page transition animation
//       _progressController.reset();
//       _progressController.forward();
//     }
//   }
  
//   void _previousQuestion() {
//     if (_currentIndex > 0) {
//       setState(() {
//         _currentIndex--;
//         _showExplanation = false;
//         _selectedAnswerForCurrent = null;
//         _isHintVisible = false;
//       });
//       _startQuestionTimer();
      
//       _progressController.reset();
//       _progressController.forward();
//     }
//   }
  
//   void _autoSubmitTest() {
//     if (_isTestSubmitted) return;
    
//     int earnedPoints = 0;
//     for (var answer in _userAnswers.values) {
//       if (answer.isCorrect) {
//         final question = _testSession!.questions.firstWhere((q) => q.id == answer.questionId);
//         earnedPoints += question.points;
//       }
//     }
    
//     setState(() {
//       _currentScore = earnedPoints;
//       _isTestSubmitted = true;
//       _countdownTimer?.cancel();
//       _questionTimer?.cancel();
//     });
//   }
  
//   void _submitTest() {
//     if (_isTestSubmitted) return;
    
//     int earnedPoints = 0;
//     for (var answer in _userAnswers.values) {
//       if (answer.isCorrect) {
//         final question = _testSession!.questions.firstWhere((q) => q.id == answer.questionId);
//         earnedPoints += question.points;
//       }
//     }
    
//     setState(() {
//       _currentScore = earnedPoints;
//       _isTestSubmitted = true;
//       _countdownTimer?.cancel();
//       _questionTimer?.cancel();
//     });
//   }
  
//   void _resetTest() {
//     setState(() {
//       _userAnswers.clear();
//       _isTestSubmitted = false;
//       _currentScore = 0;
//       _currentIndex = 0;
//       _showExplanation = false;
//       _selectedAnswerForCurrent = null;
//       _isHintVisible = false;
//       _hintsUsed = 0;
//     });
    
//     _startQuestionTimer();
//     if (_testSession!.timeLimitMinutes > 0) {
//       _startCountdownTimer();
//     }
//   }
  
//   void _showHint() {
//     setState(() {
//       _isHintVisible = true;
//     });
//     HapticFeedback.selectionClick();
//   }
  
//   TestStatistics _getStatistics() {
//     final totalQuestions = _testSession!.questions.length;
//     final answered = _userAnswers.length;
//     final correct = _userAnswers.values.where((a) => a.isCorrect).length;
//     final incorrect = answered - correct;
//     final unattempted = totalQuestions - answered;
//     final totalPoints = _testSession!.totalPoints;
//     final earnedPoints = _currentScore;
//     final accuracy = answered > 0 ? (correct / answered) * 100 : 0;
    
//     final totalTimeSpent = _userAnswers.values.fold<int>(
//       0,
//       (sum, answer) => sum + answer.timeSpentSeconds,
//     );
//     final averageTime = answered > 0 ? totalTimeSpent / answered : 0;
    
//     return TestStatistics(
//       totalQuestions: totalQuestions,
//       answered: answered,
//       correct: correct,
//       incorrect: incorrect,
//       unattempted: unattempted,
//       totalPoints: totalPoints,
//       earnedPoints: earnedPoints,
//       accuracy: accuracy.toDouble(),
//       averageTimePerQuestion: averageTime.toDouble(),
//       totalTimeSpent: totalTimeSpent,
//       hintsUsed: _hintsUsed,
//     );
//   }
  
//   String _formatTime(int seconds) {
//     final minutes = seconds ~/ 60;
//     final remainingSeconds = seconds % 60;
//     return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
//   }
  
//   @override
//   Widget build(BuildContext context) {
//     if (_isLoading) return _buildPremiumLoadingScreen();
//     if (_error != null) return _buildPremiumErrorScreen();
//     if (_testSession == null) return _buildPremiumErrorScreen();
    
//     return AnimatedBackground(
//       child: Scaffold(
//         backgroundColor: Colors.transparent,
//         appBar: _buildPremiumAppBar(),
//         body: _isTestSubmitted ? _buildPremiumResultsScreen() : _buildPremiumTestScreen(),
//       ),
//     );
//   }
  
//   PreferredSizeWidget _buildPremiumAppBar() {
//     final stats = _getStatistics();
//     final percentage = stats.totalQuestions > 0 
//         ? (stats.answered / stats.totalQuestions) * 100 
//         : 0;
    
//     return AppBar(
//       title: Row(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(8),
//             decoration: BoxDecoration(
//               gradient: PremiumThemes.primaryGradient,
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: const Icon(Icons.quiz, color: Colors.white, size: 20),
//           ),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   _testSession!.title,
//                   style: const TextStyle(
//                     fontSize: 16,
//                     fontWeight: FontWeight.w700,
//                     letterSpacing: -0.5,
//                   ),
//                   overflow: TextOverflow.ellipsis,
//                 ),
//                 if (_testSession!.timeLimitMinutes > 0 && !_isTestSubmitted)
//                   AnimatedBuilder(
//                     animation: _shakeController,
//                     builder: (context, child) {
//                       return Transform.translate(
//                         offset: Offset(
//                           math.sin(_shakeController.value * math.pi * 4) * 2,
//                           0,
//                         ),
//                         child: Row(
//                           children: [
//                             Icon(
//                               Icons.timer,
//                               size: 12,
//                               color: _remainingTimeSeconds <= 60 
//                                   ? PremiumThemes.error 
//                                   : Colors.grey,
//                             ),
//                             const SizedBox(width: 4),
//                             Text(
//                               _formatTime(_remainingTimeSeconds),
//                               style: TextStyle(
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.w600,
//                                 color: _remainingTimeSeconds <= 60 
//                                     ? PremiumThemes.error 
//                                     : Colors.grey,
//                               ),
//                             ),
//                           ],
//                         ),
//                       );
//                     },
//                   ),
//               ],
//             ),
//           ),
//         ],
//       ),
//       backgroundColor: Colors.white.withValues(alpha:0.95),
//       elevation: 0,
//       centerTitle: false,
//       leading: IconButton(
//         icon: Container(
//           padding: const EdgeInsets.all(8),
//           decoration: BoxDecoration(
//             color: Colors.grey.shade100,
//             borderRadius: BorderRadius.circular(12),
//           ),
//           child: const Icon(Icons.arrow_back_rounded, size: 20),
//         ),
//         onPressed: () => Navigator.of(context).pop(),
//       ),
//       bottom: PreferredSize(
//         preferredSize: const Size.fromHeight(4),
//         child: TweenAnimationBuilder<double>(
//           tween: Tween(begin: 0, end: percentage / 100),
//           duration: const Duration(milliseconds: 600),
//           builder: (context, value, child) {
//             return LinearProgressIndicator(
//               value: value,
//               backgroundColor: Colors.grey.shade100,
//               color: PremiumThemes.primary,
//               minHeight: 3,
//             );
//           },
//         ),
//       ),
//       actions: [
//         if (!_isTestSubmitted)
//           PopupMenuButton(
//             icon: Container(
//               padding: const EdgeInsets.all(8),
//               decoration: BoxDecoration(
//                 color: Colors.grey.shade100,
//                 borderRadius: BorderRadius.circular(12),
//               ),
//               child: const Icon(Icons.more_vert, size: 20),
//             ),
//             itemBuilder: (context) => [
//               const PopupMenuItem(
//                 value: 'reset',
//                 child: Row(
//                   children: [
//                     Icon(Icons.refresh, size: 20),
//                     SizedBox(width: 12),
//                     Text('Reset Test'),
//                   ],
//                 ),
//               ),
//               const PopupMenuItem(
//                 value: 'submit',
//                 child: Row(
//                   children: [
//                     Icon(Icons.check_circle, size: 20),
//                     SizedBox(width: 12),
//                     Text('Submit Test'),
//                   ],
//                 ),
//               ),
//             ],
//             onSelected: (value) {
//               if (value == 'reset') {
//                 _resetTest();
//               } else if (value == 'submit') {
//                 _submitTest();
//               }
//             },
//           ),
//         const SizedBox(width: 8),
//       ],
//     );
//   }
  
//   Widget _buildPremiumLoadingScreen() {
//     return Scaffold(
//       backgroundColor: PremiumThemes.lightBackground,
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Container(
//               width: 80,
//               height: 80,
//               decoration: BoxDecoration(
//                 gradient: PremiumThemes.primaryGradient,
//                 borderRadius: BorderRadius.circular(24),
//                 boxShadow: PremiumThemes.glowShadow,
//               ),
//               child: const Center(
//                 child: CircularProgressIndicator(
//                   color: Colors.white,
//                   strokeWidth: 3,
//                 ),
//               ),
//             ),
//             const SizedBox(height: 32),
//             const Text(
//               'Preparing your test...',
//               style: TextStyle(
//                 fontSize: 18,
//                 fontWeight: FontWeight.w600,
//                 color: Colors.grey,
//               ),
//             ),
//             const SizedBox(height: 8),
//             Text(
//               'Loading questions',
//               style: TextStyle(
//                 fontSize: 14,
//                 color: Colors.grey.shade400,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
  
//   Widget _buildPremiumErrorScreen() {
//     return Scaffold(
//       backgroundColor: PremiumThemes.lightBackground,
//       body: Center(
//         child: Padding(
//           padding: const EdgeInsets.all(32),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(20),
//                 decoration: BoxDecoration(
//                   color: PremiumThemes.error.withValues(alpha:0.1),
//                   shape: BoxShape.circle,
//                 ),
//                 child: Icon(Icons.error_outline, size: 64, color: PremiumThemes.error),
//               ),
//               const SizedBox(height: 24),
//               Text(
//                 'Oops! Something went wrong',
//                 style: TextStyle(
//                   fontSize: 24,
//                   fontWeight: FontWeight.bold,
//                   color: Colors.grey.shade800,
//                 ),
//               ),
//               const SizedBox(height: 8),
//               Text(
//                 _error ?? 'Failed to load test',
//                 style: TextStyle(color: Colors.grey.shade600),
//                 textAlign: TextAlign.center,
//               ),
//               const SizedBox(height: 32),
//               ElevatedButton(
//                 onPressed: _loadMockTest,
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: PremiumThemes.primary,
//                   padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(16),
//                   ),
//                   elevation: 0,
//                 ),
//                 child: const Text('Try Again'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
  
//   Widget _buildPremiumTestScreen() {
//     final question = _testSession!.questions[_currentIndex];
//     final hasAnswer = _userAnswers.containsKey(question.id);
//     final selectedAnswer = hasAnswer ? _userAnswers[question.id]!.selectedAnswer : -1;
//     final isCorrect = hasAnswer && _userAnswers[question.id]!.isCorrect;
//     final stats = _getStatistics();
    
//     return Column(
//       children: [
//         // Premium Progress Header
//         Container(
//           margin: const EdgeInsets.all(20),
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(24),
//             boxShadow: PremiumThemes.premiumShadow,
//           ),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               _buildPremiumStatChip(
//                 icon: Icons.quiz,
//                 label: 'Q${_currentIndex + 1}/${stats.totalQuestions}',
//                 color: PremiumThemes.primary,
//               ),
//               _buildPremiumStatChip(
//                 icon: Icons.star,
//                 label: '${stats.answered}/$stats.totalQuestions',
//                 color: PremiumThemes.success,
//               ),
//               _buildPremiumStatChip(
//                 icon: Icons.score,
//                 label: '${_currentScore}/${_testSession!.totalPoints}',
//                 color: PremiumThemes.warning,
//               ),
//             ],
//           ),
//         ),
        
//         // Main Content
//         Expanded(
//           child: SingleChildScrollView(
//             physics: const BouncingScrollPhysics(),
//             padding: const EdgeInsets.symmetric(horizontal: 20),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 // Question Card with Animation
//                 TweenAnimationBuilder<double>(
//                   tween: Tween(begin: 0, end: 1),
//                   duration: const Duration(milliseconds: 500),
//                   curve: Curves.easeOutCubic,
//                   builder: (context, value, child) {
//                     return Transform.translate(
//                       offset: Offset(0, 20 * (1 - value)),
//                       child: Opacity(opacity: value, child: child),
//                     );
//                   },
//                   child: Container(
//                     padding: const EdgeInsets.all(24),
//                     decoration: BoxDecoration(
//                       gradient: LinearGradient(
//                         begin: Alignment.topLeft,
//                         end: Alignment.bottomRight,
//                         colors: [
//                           Colors.white,
//                           Colors.grey.shade50,
//                         ],
//                       ),
//                       borderRadius: BorderRadius.circular(32),
//                       border: Border.all(color: Colors.grey.shade100, width: 1),
//                       boxShadow: PremiumThemes.premiumShadow,
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         // Badges Row
//                         Wrap(
//                           spacing: 8,
//                           runSpacing: 8,
//                           children: [
//                             if (question.difficulty != null)
//                               Container(
//                                 padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                                 decoration: BoxDecoration(
//                                   gradient: _getDifficultyGradient(question.difficulty!),
//                                   borderRadius: BorderRadius.circular(20),
//                                 ),
//                                 child: Row(
//                                   mainAxisSize: MainAxisSize.min,
//                                   children: [
//                                     Icon(
//                                       _getDifficultyIcon(question.difficulty!),
//                                       size: 12,
//                                       color: Colors.white,
//                                     ),
//                                     const SizedBox(width: 4),
//                                     Text(
//                                       question.difficulty!.toUpperCase(),
//                                       style: const TextStyle(
//                                         fontSize: 11,
//                                         fontWeight: FontWeight.w600,
//                                         color: Colors.white,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             if (question.topic != null)
//                               Container(
//                                 padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                                 decoration: BoxDecoration(
//                                   color: PremiumThemes.info.withValues(alpha:0.1),
//                                   borderRadius: BorderRadius.circular(20),
//                                 ),
//                                 child: Text(
//                                   question.topic!,
//                                   style: TextStyle(
//                                     fontSize: 11,
//                                     fontWeight: FontWeight.w600,
//                                     color: PremiumThemes.info,
//                                   ),
//                                 ),
//                               ),
//                             Container(
//                               padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                               decoration: BoxDecoration(
//                                 color: PremiumThemes.warning.withValues(alpha:0.1),
//                                 borderRadius: BorderRadius.circular(20),
//                               ),
//                               child: Row(
//                                 mainAxisSize: MainAxisSize.min,
//                                 children: [
//                                   Icon(Icons.bolt, size: 14, color: PremiumThemes.warning),
//                                   const SizedBox(width: 4),
//                                   Text(
//                                     '${question.points} pts',
//                                     style: TextStyle(
//                                       fontSize: 11,
//                                       fontWeight: FontWeight.w600,
//                                       color: PremiumThemes.warning,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 20),
//                         Text(
//                           question.question,
//                           style: const TextStyle(
//                             fontSize: 18,
//                             fontWeight: FontWeight.w700,
//                             color: Color(0xFF1A1A2E),
//                             height: 1.4,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
                
//                 const SizedBox(height: 24),
                
//                 // Options Section
//                 const Text(
//                   'Select Your Answer',
//                   style: TextStyle(
//                     fontSize: 13,
//                     fontWeight: FontWeight.w600,
//                     color: Colors.grey,
//                     letterSpacing: 0.5,
//                   ),
//                 ),
//                 const SizedBox(height: 12),
                
//                 ...List.generate(question.options.length, (index) {
//                   final isSelected = selectedAnswer == index;
//                   final isCorrectOption = index == question.correctAnswer;
                  
//                   return _buildPremiumOptionCard(
//                     option: question.options[index],
//                     letter: String.fromCharCode(65 + index),
//                     isSelected: isSelected,
//                     isCorrect: isCorrectOption,
//                     showResult: _showExplanation && hasAnswer,
//                     onTap: () => _selectAnswer(index),
//                     isEnabled: !_showExplanation && !hasAnswer,
//                     index: index,
//                   );
//                 }),
                
//                 const SizedBox(height: 16),
                
//                 // Hint Section
//                 if (question.hints != null && !_showExplanation && !hasAnswer)
//                   AnimatedSwitcher(
//                     duration: const Duration(milliseconds: 300),
//                     child: _isHintVisible
//                         ? _buildPremiumHintCard(question.hints![0])
//                         : TextButton.icon(
//                             onPressed: _showHint,
//                             icon: Icon(Icons.lightbulb_outline, color: PremiumThemes.warning),
//                             label: Text(
//                               'Need a hint?',
//                               style: TextStyle(color: PremiumThemes.warning),
//                             ),
//                             style: TextButton.styleFrom(
//                               foregroundColor: PremiumThemes.warning,
//                             ),
//                           ),
//                   ),
                
//                 // Explanation Card
//                 if (_showExplanation && hasAnswer)
//                   _buildPremiumExplanationCard(
//                     isCorrect: isCorrect,
//                     explanation: question.explanation,
//                     selectedLetter: String.fromCharCode(65 + selectedAnswer),
//                     selectedText: question.options[selectedAnswer],
//                     correctLetter: String.fromCharCode(65 + question.correctAnswer),
//                     correctText: question.options[question.correctAnswer],
//                     pointsEarned: isCorrect ? question.points : 0,
//                   ),
                
//                 const SizedBox(height: 24),
                
//                 // Navigation Buttons
//                 Row(
//                   children: [
//                     Expanded(
//                       child: AnimatedContainer(
//                         duration: const Duration(milliseconds: 200),
//                         child: OutlinedButton.icon(
//                           onPressed: _currentIndex > 0 ? _previousQuestion : null,
//                           icon: const Icon(Icons.arrow_back, size: 18),
//                           label: const Text('Previous'),
//                           style: OutlinedButton.styleFrom(
//                             padding: const EdgeInsets.symmetric(vertical: 16),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(20),
//                             ),
//                             side: BorderSide(
//                               color: _currentIndex > 0 ? PremiumThemes.primary : Colors.grey.shade300,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     Expanded(
//                       child: AnimatedContainer(
//                         duration: const Duration(milliseconds: 200),
//                         child: ElevatedButton.icon(
//                           onPressed: _currentIndex < stats.totalQuestions - 1
//                               ? (_showExplanation ? _nextQuestion : null)
//                               : (_showExplanation && stats.answered == stats.totalQuestions 
//                                   ? _submitTest 
//                                   : null),
//                           icon: Icon(
//                             _currentIndex < stats.totalQuestions - 1
//                                 ? Icons.arrow_forward
//                                 : Icons.check,
//                             size: 18,
//                           ),
//                           label: Text(
//                             _currentIndex < stats.totalQuestions - 1
//                                 ? 'Next Question'
//                                 : 'Submit Test',
//                           ),
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: PremiumThemes.primary,
//                             padding: const EdgeInsets.symmetric(vertical: 16),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(20),
//                             ),
//                             elevation: 0,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
                
//                 const SizedBox(height: 20),
//               ],
//             ),
//           ),
//         ),
//       ],
//     );
//   }
  
//   Widget _buildPremiumStatChip({
//     required IconData icon,
//     required String label,
//     required Color color,
//   }) {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//       decoration: BoxDecoration(
//         color: color.withValues(alpha:0.1),
//         borderRadius: BorderRadius.circular(16),
//       ),
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           Icon(icon, size: 16, color: color),
//           const SizedBox(width: 6),
//           Text(
//             label,
//             style: TextStyle(
//               fontSize: 13,
//               fontWeight: FontWeight.w600,
//               color: color,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
  
//   Widget _buildPremiumOptionCard({
//     required String option,
//     required String letter,
//     required bool isSelected,
//     required bool isCorrect,
//     required bool showResult,
//     required VoidCallback onTap,
//     required bool isEnabled,
//     required int index,
//   }) {
//     Color backgroundColor = Colors.white;
//     Color borderColor = Colors.grey.shade200;
//     Color letterColor = Colors.grey.shade600;
//     IconData? trailingIcon;
    
//     if (showResult) {
//       if (isCorrect) {
//         backgroundColor = PremiumThemes.success.withValues(alpha:0.08);
//         borderColor = PremiumThemes.success;
//         letterColor = PremiumThemes.success;
//         trailingIcon = Icons.check_circle_rounded;
//       } else if (isSelected && !isCorrect) {
//         backgroundColor = PremiumThemes.error.withValues(alpha:0.08);
//         borderColor = PremiumThemes.error;
//         letterColor = PremiumThemes.error;
//         trailingIcon = Icons.cancel_rounded;
//       }
//     } else if (isSelected) {
//       backgroundColor = PremiumThemes.primary.withValues(alpha:0.08);
//       borderColor = PremiumThemes.primary;
//       letterColor = PremiumThemes.primary;
//     }
    
//     return TweenAnimationBuilder<double>(
//       tween: Tween(begin: 0, end: 1),
//       duration: Duration(milliseconds: 200 + (index * 50)),
//       curve: Curves.easeOutCubic,
//       builder: (context, value, child) {
//         return Transform.translate(
//           offset: Offset(20 * (1 - value), 0),
//           child: Opacity(opacity: value, child: child),
//         );
//       },
//       child: AnimatedContainer(
//         duration: const Duration(milliseconds: 300),
//         margin: const EdgeInsets.only(bottom: 12),
//         decoration: BoxDecoration(
//           color: backgroundColor,
//           borderRadius: BorderRadius.circular(20),
//           border: Border.all(color: borderColor, width: 1.5),
//           boxShadow: [
//             if (!showResult && isEnabled)
//               BoxShadow(
//                 color: Colors.black.withValues(alpha:0.04),
//                 blurRadius: 12,
//                 offset: const Offset(0, 4),
//               ),
//           ],
//         ),
//         child: Material(
//           color: Colors.transparent,
//           child: InkWell(
//             onTap: isEnabled ? onTap : null,
//             borderRadius: BorderRadius.circular(20),
//             child: Container(
//               padding: const EdgeInsets.all(16),
//               child: Row(
//                 children: [
//                   AnimatedContainer(
//                     duration: const Duration(milliseconds: 200),
//                     width: 36,
//                     height: 36,
//                     decoration: BoxDecoration(
//                       gradient: isSelected || (showResult && isCorrect)
//                           ? (isCorrect ? PremiumThemes.successGradient : PremiumThemes.primaryGradient)
//                           : null,
//                       color: isSelected || (showResult && isCorrect)
//                           ? null
//                           : Colors.grey.shade100,
//                       borderRadius: BorderRadius.circular(14),
//                     ),
//                     child: Center(
//                       child: Text(
//                         letter,
//                         style: TextStyle(
//                           fontWeight: FontWeight.bold,
//                           fontSize: 16,
//                           color: isSelected || (showResult && isCorrect) 
//                               ? Colors.white 
//                               : Colors.grey.shade600,
//                         ),
//                       ),
//                     ),
//                   ),
//                   const SizedBox(width: 14),
//                   Expanded(
//                     child: Text(
//                       option,
//                       style: const TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w500,
//                         color: Color(0xFF1A1A2E),
//                       ),
//                     ),
//                   ),
//                   if (trailingIcon != null)
//                     Icon(
//                       trailingIcon,
//                       color: isCorrect ? PremiumThemes.success : PremiumThemes.error,
//                       size: 24,
//                     ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
  
//   Widget _buildPremiumHintCard(String hint) {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             PremiumThemes.warning.withValues(alpha:0.15),
//             PremiumThemes.warning.withValues(alpha:0.05),
//           ],
//         ),
//         borderRadius: BorderRadius.circular(20),
//         border: Border.all(color: PremiumThemes.warning.withValues(alpha:0.3)),
//       ),
//       child: Row(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(8),
//             decoration: BoxDecoration(
//               color: PremiumThemes.warning,
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: const Icon(Icons.lightbulb, color: Colors.white, size: 20),
//           ),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Text(
//               hint,
//               style: const TextStyle(
//                 fontSize: 14,
//                 fontWeight: FontWeight.w500,
//                 color: Color(0xFF1A1A2E),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
  
//   Widget _buildPremiumExplanationCard({
//     required bool isCorrect,
//     required String explanation,
//     required String selectedLetter,
//     required String selectedText,
//     required String correctLetter,
//     required String correctText,
//     required int pointsEarned,
//   }) {
//     return TweenAnimationBuilder<double>(
//       tween: Tween(begin: 0, end: 1),
//       duration: const Duration(milliseconds: 500),
//       curve: Curves.easeOutBack,
//       builder: (context, value, child) {
//         return Transform.scale(
//           scale: value,
//           child: Opacity(opacity: value, child: child),
//         );
//       },
//       child: Container(
//         padding: const EdgeInsets.all(20),
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//             colors: isCorrect
//                 ? [PremiumThemes.success.withValues(alpha:0.1), Colors.white]
//                 : [PremiumThemes.error.withValues(alpha:0.1), Colors.white],
//           ),
//           borderRadius: BorderRadius.circular(24),
//           border: Border.all(
//             color: isCorrect ? PremiumThemes.success : PremiumThemes.error,
//             width: 1.5,
//           ),
//           boxShadow: PremiumThemes.premiumShadow,
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(
//               children: [
//                 Container(
//                   padding: const EdgeInsets.all(10),
//                   decoration: BoxDecoration(
//                     gradient: isCorrect ? PremiumThemes.successGradient : PremiumThemes.errorGradient,
//                     shape: BoxShape.circle,
//                   ),
//                   child: Icon(
//                     isCorrect ? Icons.check : Icons.close,
//                     color: Colors.white,
//                     size: 20,
//                   ),
//                 ),
//                 const SizedBox(width: 14),
//                 Expanded(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         isCorrect ? 'Correct Answer!' : 'Incorrect Answer',
//                         style: TextStyle(
//                           fontSize: 18,
//                           fontWeight: FontWeight.bold,
//                           color: isCorrect ? PremiumThemes.success : PremiumThemes.error,
//                         ),
//                       ),
//                       if (pointsEarned > 0)
//                         Container(
//                           margin: const EdgeInsets.only(top: 4),
//                           padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
//                           decoration: BoxDecoration(
//                             color: PremiumThemes.success.withValues(alpha:0.2),
//                             borderRadius: BorderRadius.circular(12),
//                           ),
//                           child: Text(
//                             '+$pointsEarned points',
//                             style: TextStyle(
//                               fontSize: 11,
//                               fontWeight: FontWeight.w600,
//                               color: PremiumThemes.success,
//                             ),
//                           ),
//                         ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//             const SizedBox(height: 20),
//             if (!isCorrect) ...[
//               Container(
//                 padding: const EdgeInsets.all(14),
//                 decoration: BoxDecoration(
//                   color: PremiumThemes.error.withValues(alpha:0.05),
//                   borderRadius: BorderRadius.circular(16),
//                 ),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     const Text(
//                       'Your Answer',
//                       style: TextStyle(
//                         fontSize: 12,
//                         fontWeight: FontWeight.w600,
//                         color: Colors.grey,
//                       ),
//                     ),
//                     const SizedBox(height: 6),
//                     Text(
//                       '$selectedLetter. $selectedText',
//                       style: const TextStyle(
//                         fontSize: 14,
//                         color: PremiumThemes.error,
//                         fontWeight: FontWeight.w500,
//                       ),
//                     ),
//                     const SizedBox(height: 12),
//                     const Text(
//                       'Correct Answer',
//                       style: TextStyle(
//                         fontSize: 12,
//                         fontWeight: FontWeight.w600,
//                         color: Colors.grey,
//                       ),
//                     ),
//                     const SizedBox(height: 6),
//                     Text(
//                       '$correctLetter. $correctText',
//                       style: const TextStyle(
//                         fontSize: 14,
//                         color: PremiumThemes.success,
//                         fontWeight: FontWeight.w600,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               const SizedBox(height: 20),
//             ],
//             Container(
//               padding: const EdgeInsets.all(14),
//               decoration: BoxDecoration(
//                 color: Colors.grey.shade50,
//                 borderRadius: BorderRadius.circular(16),
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   const Text(
//                     'Explanation',
//                     style: TextStyle(
//                       fontSize: 12,
//                       fontWeight: FontWeight.w600,
//                       color: Colors.grey,
//                     ),
//                   ),
//                   const SizedBox(height: 8),
//                   Text(
//                     explanation,
//                     style: const TextStyle(
//                       fontSize: 14,
//                       height: 1.5,
//                       color: Color(0xFF1A1A2E),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
  
//   Widget _buildPremiumResultsScreen() {
//     final stats = _getStatistics();
//     final percentage = (stats.earnedPoints / stats.totalPoints) * 100;
//     final passed = percentage >= _testSession!.passingScore;
    
//     return SingleChildScrollView(
//       physics: const BouncingScrollPhysics(),
//       padding: const EdgeInsets.all(20),
//       child: Column(
//         children: [
//           // Hero Score Card with Animation
//           TweenAnimationBuilder<double>(
//             tween: Tween(begin: 0, end: percentage),
//             duration: const Duration(seconds: 2),
//             curve: Curves.easeOutCubic,
//             builder: (context, value, child) {
//               return Container(
//                 padding: const EdgeInsets.all(32),
//                 decoration: BoxDecoration(
//                   gradient: passed ? PremiumThemes.successGradient : PremiumThemes.errorGradient,
//                   borderRadius: BorderRadius.circular(40),
//                   boxShadow: [
//                     BoxShadow(
//                       color: (passed ? PremiumThemes.success : PremiumThemes.error).withValues(alpha:0.4),
//                       blurRadius: 30,
//                       offset: const Offset(0, 10),
//                     ),
//                   ],
//                 ),
//                 child: Column(
//                   children: [
//                     TweenAnimationBuilder<double>(
//                       tween: Tween(begin: 0, end: 1),
//                       duration: const Duration(milliseconds: 800),
//                       curve: Curves.elasticOut,
//                       builder: (context, scale, child) {
//                         return Transform.scale(
//                           scale: scale,
//                           child: child,
//                         );
//                       },
//                       child: Icon(
//                         passed ? Icons.emoji_events : Icons.school,
//                         size: 80,
//                         color: Colors.white,
//                       ),
//                     ),
//                     const SizedBox(height: 20),
//                     Text(
//                       '${value.toStringAsFixed(1)}%',
//                       style: const TextStyle(
//                         fontSize: 64,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.white,
//                         letterSpacing: -1,
//                       ),
//                     ),
//                     const SizedBox(height: 12),
//                     Container(
//                       padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
//                       decoration: BoxDecoration(
//                         color: Colors.white.withValues(alpha:0.2),
//                         borderRadius: BorderRadius.circular(30),
//                       ),
//                       child: Text(
//                         passed ? 'PASSED' : 'NEEDS IMPROVEMENT',
//                         style: const TextStyle(
//                           fontSize: 14,
//                           fontWeight: FontWeight.w700,
//                           color: Colors.white,
//                           letterSpacing: 1.5,
//                         ),
//                       ),
//                     ),
//                     const SizedBox(height: 16),
//                     Text(
//                       '${stats.earnedPoints} / ${stats.totalPoints} points',
//                       style: const TextStyle(
//                         fontSize: 18,
//                         color: Colors.white70,
//                         fontWeight: FontWeight.w500,
//                       ),
//                     ),
//                   ],
//                 ),
//               );
//             },
//           ),
          
//           const SizedBox(height: 24),
          
//           // Statistics Grid
//           GridView.count(
//             shrinkWrap: true,
//             physics: const NeverScrollableScrollPhysics(),
//             crossAxisCount: 2,
//             mainAxisSpacing: 14,
//             crossAxisSpacing: 14,
//             childAspectRatio: 1.4,
//             children: [
//               _buildPremiumStatCard('Total Questions', stats.totalQuestions.toString(), Icons.help_outline, Colors.blue),
//               _buildPremiumStatCard('Correct', stats.correct.toString(), Icons.check_circle, PremiumThemes.success),
//               _buildPremiumStatCard('Incorrect', stats.incorrect.toString(), Icons.cancel, PremiumThemes.error),
//               _buildPremiumStatCard('Accuracy', '${stats.accuracy.toStringAsFixed(0)}%', Icons.trending_up, PremiumThemes.warning),
//               _buildPremiumStatCard('Avg. Time', '${stats.averageTimePerQuestion.toStringAsFixed(0)}s', Icons.timer, Colors.purple),
//               _buildPremiumStatCard('Hints Used', stats.hintsUsed.toString(), Icons.lightbulb, Colors.orange),
//             ],
//           ),
          
//           const SizedBox(height: 24),
          
//           // Performance Message
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   passed ? PremiumThemes.success.withValues(alpha:0.1) : PremiumThemes.warning.withValues(alpha:0.1),
//                   Colors.white,
//                 ],
//               ),
//               borderRadius: BorderRadius.circular(24),
//               border: Border.all(color: passed ? PremiumThemes.success.withValues(alpha:0.3) : PremiumThemes.warning.withValues(alpha:0.3)),
//             ),
//             child: Row(
//               children: [
//                 Container(
//                   padding: const EdgeInsets.all(12),
//                   decoration: BoxDecoration(
//                     gradient: passed ? PremiumThemes.successGradient : PremiumThemes.accentGradient,
//                     borderRadius: BorderRadius.circular(20),
//                   ),
//                   child: Icon(
//                     passed ? Icons.celebration : Icons.psychology,
//                     color: Colors.white,
//                     size: 28,
//                   ),
//                 ),
//                 const SizedBox(width: 16),
//                 Expanded(
//                   child: Text(
//                     passed 
//                         ? 'Outstanding performance! You\'ve demonstrated excellent understanding of the material. Keep up the great work! 🎉'
//                         : 'Good effort! Review the explanations below to strengthen your understanding. You\'ve got this! 💪',
//                     style: const TextStyle(height: 1.4, fontSize: 14),
//                   ),
//                 ),
//               ],
//             ),
//           ),
          
//           const SizedBox(height: 24),
          
//           // Question Review Section
//           const Text(
//             'Detailed Review',
//             style: TextStyle(
//               fontSize: 22,
//               fontWeight: FontWeight.bold,
//               letterSpacing: -0.5,
//             ),
//           ),
//           const SizedBox(height: 16),
          
//           ...List.generate(_testSession!.questions.length, (index) {
//             final question = _testSession!.questions[index];
//             final answer = _userAnswers[question.id];
//             final isCorrect = answer?.isCorrect ?? false;
//             final isAnswered = answer != null;
            
//             return Container(
//               margin: const EdgeInsets.only(bottom: 12),
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(20),
//                 border: Border.all(
//                   color: isAnswered
//                       ? (isCorrect ? PremiumThemes.success : PremiumThemes.error)
//                       : Colors.grey.shade200,
//                   width: 1.5,
//                 ),
//                 boxShadow: PremiumThemes.premiumShadow,
//               ),
//               child: ExpansionTile(
//                 leading: Container(
//                   width: 40,
//                   height: 40,
//                   decoration: BoxDecoration(
//                     gradient: isAnswered
//                         ? (isCorrect ? PremiumThemes.successGradient : PremiumThemes.errorGradient)
//                         : null,
//                     color: isAnswered ? null : Colors.grey,
//                     borderRadius: BorderRadius.circular(14),
//                   ),
//                   child: Center(
//                     child: Text(
//                       '${index + 1}',
//                       style: const TextStyle(
//                         color: Colors.white,
//                         fontWeight: FontWeight.bold,
//                         fontSize: 14,
//                       ),
//                     ),
//                   ),
//                 ),
//                 title: Text(
//                   question.question,
//                   style: const TextStyle(
//                     fontWeight: FontWeight.w600,
//                     fontSize: 15,
//                   ),
//                   maxLines: 2,
//                   overflow: TextOverflow.ellipsis,
//                 ),
//                 subtitle: Container(
//                   margin: const EdgeInsets.only(top: 4),
//                   padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
//                   decoration: BoxDecoration(
//                     color: isAnswered
//                         ? (isCorrect ? PremiumThemes.success.withValues(alpha:0.1) : PremiumThemes.error.withValues(alpha:0.1))
//                         : Colors.grey.withValues(alpha:0.1),
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: Text(
//                     isAnswered
//                         ? (isCorrect ? '✓ Correct' : '✗ Incorrect')
//                         : 'Not answered',
//                     style: TextStyle(
//                       color: isAnswered
//                           ? (isCorrect ? PremiumThemes.success : PremiumThemes.error)
//                           : Colors.grey,
//                       fontWeight: FontWeight.w600,
//                       fontSize: 11,
//                     ),
//                   ),
//                 ),
//                 trailing: Icon(
//                   isAnswered
//                       ? (isCorrect ? Icons.check_circle : Icons.cancel)
//                       : Icons.help_outline,
//                   color: isAnswered
//                       ? (isCorrect ? PremiumThemes.success : PremiumThemes.error)
//                       : Colors.grey,
//                 ),
//                 children: [
//                   Padding(
//                     padding: const EdgeInsets.all(20),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         if (!isCorrect && isAnswered)
//                           Container(
//                             padding: const EdgeInsets.all(14),
//                             margin: const EdgeInsets.only(bottom: 16),
//                             decoration: BoxDecoration(
//                               color: PremiumThemes.error.withValues(alpha:0.05),
//                               borderRadius: BorderRadius.circular(16),
//                               border: Border.all(color: PremiumThemes.error.withValues(alpha:0.2)),
//                             ),
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const Text(
//                                   'Your Answer',
//                                   style: TextStyle(
//                                     fontWeight: FontWeight.w600,
//                                     fontSize: 12,
//                                     color: Colors.grey,
//                                   ),
//                                 ),
//                                 const SizedBox(height: 6),
//                                 Text(
//                                   '${String.fromCharCode(65 + answer!.selectedAnswer)}. ${question.options[answer.selectedAnswer]}',
//                                   style: TextStyle(
//                                     fontSize: 14,
//                                     color: PremiumThemes.error,
//                                     fontWeight: FontWeight.w500,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         Container(
//                           padding: const EdgeInsets.all(14),
//                           decoration: BoxDecoration(
//                             color: PremiumThemes.success.withValues(alpha:0.05),
//                             borderRadius: BorderRadius.circular(16),
//                             border: Border.all(color: PremiumThemes.success.withValues(alpha:0.2)),
//                           ),
//                           child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               const Text(
//                                 'Correct Answer',
//                                 style: TextStyle(
//                                   fontWeight: FontWeight.w600,
//                                   fontSize: 12,
//                                   color: Colors.grey,
//                                 ),
//                               ),
//                               const SizedBox(height: 6),
//                               Text(
//                                 '${String.fromCharCode(65 + question.correctAnswer)}. ${question.options[question.correctAnswer]}',
//                                 style: TextStyle(
//                                   fontSize: 14,
//                                   color: PremiumThemes.success,
//                                   fontWeight: FontWeight.w600,
//                                 ),
//                               ),
//                               const SizedBox(height: 16),
//                               const Divider(),
//                               const SizedBox(height: 12),
//                               const Text(
//                                 'Explanation',
//                                 style: TextStyle(
//                                   fontWeight: FontWeight.w600,
//                                   fontSize: 12,
//                                   color: Colors.grey,
//                                 ),
//                               ),
//                               const SizedBox(height: 8),
//                               Text(
//                                 question.explanation,
//                                 style: const TextStyle(height: 1.5, fontSize: 14),
//                               ),
//                             ],
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             );
//           }),
          
//           const SizedBox(height: 24),
          
//           // Action Buttons
//           Row(
//             children: [
//               Expanded(
//                 child: OutlinedButton.icon(
//                   onPressed: _resetTest,
//                   icon: const Icon(Icons.refresh),
//                   label: const Text('Retake Test'),
//                   style: OutlinedButton.styleFrom(
//                     padding: const EdgeInsets.symmetric(vertical: 16),
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(20),
//                     ),
//                     side: BorderSide(color: PremiumThemes.primary),
//                   ),
//                 ),
//               ),
//               const SizedBox(width: 12),
//               Expanded(
//                 child: ElevatedButton.icon(
//                   onPressed: () => Navigator.of(context).pop(),
//                   icon: const Icon(Icons.done),
//                   label: const Text('Done'),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: PremiumThemes.primary,
//                     padding: const EdgeInsets.symmetric(vertical: 16),
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(20),
//                     ),
//                     elevation: 0,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 20),
//         ],
//       ),
//     );
//   }
  
//   Widget _buildPremiumStatCard(String title, String value, IconData icon, Color color) {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(20),
//         border: Border.all(color: Colors.grey.shade100),
//         boxShadow: PremiumThemes.premiumShadow,
//       ),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Container(
//             padding: const EdgeInsets.all(10),
//             decoration: BoxDecoration(
//               color: color.withValues(alpha:0.1),
//               borderRadius: BorderRadius.circular(14),
//             ),
//             child: Icon(icon, color: color, size: 26),
//           ),
//           const SizedBox(height: 10),
//           Text(
//             value,
//             style: TextStyle(
//               fontSize: 26,
//               fontWeight: FontWeight.bold,
//               color: color,
//             ),
//           ),
//           const SizedBox(height: 4),
//           Text(
//             title,
//             style: const TextStyle(
//               fontSize: 12,
//               color: Colors.grey,
//               fontWeight: FontWeight.w500,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
  
//   LinearGradient _getDifficultyGradient(String difficulty) {
//     switch (difficulty.toLowerCase()) {
//       case 'beginner':
//         return const LinearGradient(
//           colors: [Color(0xFF00D09C), Color(0xFF00A87E)],
//         );
//       case 'intermediate':
//         return const LinearGradient(
//           colors: [Color(0xFFFFB347), Color(0xFFFF8C42)],
//         );
//       case 'advanced':
//         return const LinearGradient(
//           colors: [Color(0xFFFF5A5A), Color(0xFFE74C3C)],
//         );
//       default:
//         return PremiumThemes.primaryGradient;
//     }
//   }
  
//   IconData _getDifficultyIcon(String difficulty) {
//     switch (difficulty.toLowerCase()) {
//       case 'beginner':
//         return Icons.auto_awesome;
//       case 'intermediate':
//         return Icons.trending_up;
//       case 'advanced':
//         return Icons.bolt;
//       default:
//         return Icons.star;
//     }
//   }
// }