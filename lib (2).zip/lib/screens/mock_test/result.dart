// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:techtutorial/screens/mock_test/mock_test_screen.dart';



// class ResultsScreen extends StatelessWidget {
//   final TestStatistics stats;
//   final TestSession session;
//   final Map<String, UserAnswer> userAnswers;
//   final VoidCallback onRetake;

//   const ResultsScreen({
//     super.key,
//     required this.stats,
//     required this.session,
//     required this.userAnswers,
//     required this.onRetake,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey.shade50,
//       appBar: AppBar(
//         title: const Text('Test Results'),
//         backgroundColor: Colors.white,
//         elevation: 0,
//         leading: IconButton(
//           icon: const Icon(Icons.close),
//           onPressed: () => Navigator.of(context).pop(),
//         ),
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(20),
//         child: Column(
//           children: [
//             // Score Card
//             Container(
//               padding: const EdgeInsets.all(32),
//               decoration: BoxDecoration(
//                 gradient: LinearGradient(
//                   colors: stats.passed
//                       ? [Colors.green.shade400, Colors.green.shade700]
//                       : [Colors.orange.shade400, Colors.red.shade600],
//                 ),
//                 borderRadius: BorderRadius.circular(24),
//                 boxShadow: [
//                   BoxShadow(
//                     color: (stats.passed ? Colors.green : Colors.red).withValues(alpha:0.3),
//                     blurRadius: 20,
//                     offset: const Offset(0, 10),
//                   ),
//                 ],
//               ),
//               child: Column(
//                 children: [
//                   Icon(
//                     stats.passed ? Icons.emoji_events : Icons.school,
//                     size: 64,
//                     color: Colors.white,
//                   ),
//                   const SizedBox(height: 16),
//                   Text(
//                     '${stats.percentage.toStringAsFixed(1)}%',
//                     style: const TextStyle(
//                       fontSize: 48,
//                       fontWeight: FontWeight.bold,
//                       color: Colors.white,
//                     ),
//                   ),
//                   const SizedBox(height: 8),
//                   Container(
//                     padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withValues(alpha:0.2),
//                       borderRadius: BorderRadius.circular(20),
//                     ),
//                     child: Text(
//                       stats.passed ? 'PASSED' : 'NEEDS IMPROVEMENT',
//                       style: const TextStyle(
//                         fontWeight: FontWeight.bold,
//                         color: Colors.white,
//                         letterSpacing: 1,
//                       ),
//                     ),
//                   ),
//                   const SizedBox(height: 16),
//                   Text(
//                     '${stats.earnedPoints} / ${stats.totalPoints} points',
//                     style: const TextStyle(
//                       fontSize: 18,
//                       color: Colors.white70,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
            
//             const SizedBox(height: 24),
            
//             // Statistics Grid
//             GridView.count(
//               shrinkWrap: true,
//               physics: const NeverScrollableScrollPhysics(),
//               crossAxisCount: 6,
//               mainAxisSpacing: 12,
//               crossAxisSpacing: 12,
//               childAspectRatio: 4.3,
//               children: [
//                 _buildStatCard('Questions', stats.totalQuestions.toString(), Icons.help, Colors.blue),
//                 _buildStatCard('Answered', stats.answered.toString(), Icons.check_circle, Colors.teal),
//                 _buildStatCard('Correct', stats.correct.toString(), Icons.check_circle, Colors.green),
//                 _buildStatCard('Incorrect', stats.incorrect.toString(), Icons.cancel, Colors.red),
//                 _buildStatCard('Accuracy', '${stats.accuracy.toStringAsFixed(0)}%', Icons.trending_up, Colors.orange),
//                 _buildStatCard('Hints Used', stats.hintsUsed.toString(), Icons.lightbulb, Colors.amber),
//               ],
//             ),
            
//             const SizedBox(height: 24),
            
//             // Action Buttons
//             Row(
//               children: [
//                 Expanded(
//                   child: OutlinedButton.icon(
//                     onPressed: onRetake,
//                     icon: const Icon(Icons.refresh),
//                     label: const Text('Retake Test'),
//                     style: OutlinedButton.styleFrom(
//                       padding: const EdgeInsets.symmetric(vertical: 14),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(width: 12),
//                 Expanded(
//                   child: ElevatedButton.icon(
//                     onPressed: () => Navigator.of(context).pop(),
//                     icon: const Icon(Icons.done),
//                     label: const Text('Done'),
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: const Color(0xFF6C63FF),
//                       padding: const EdgeInsets.symmetric(vertical: 14),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
            
//             const SizedBox(height: 24),
            
//             // Detailed Review
//             const Text(
//               'Detailed Review',
//               style: TextStyle(
//                 fontSize: 20,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             const SizedBox(height: 16),
            
//             ...List.generate(session.questions.length, (index) {
//               final question = session.questions[index];
//               final answer = userAnswers[question.id];
//               final isCorrect = answer?.isCorrect ?? false;
              
//               return Card(
//                 margin: const EdgeInsets.only(bottom: 12),
//                 child: ExpansionTile(
//                   leading: CircleAvatar(
//                     backgroundColor: answer != null
//                         ? (isCorrect ? Colors.green : Colors.red)
//                         : Colors.grey,
//                     child: Text(
//                       '${index + 1}',
//                       style: const TextStyle(color: Colors.white),
//                     ),
//                   ),
//                   title: Text(
//                     question.text,
//                     maxLines: 2,
//                     overflow: TextOverflow.ellipsis,
//                   ),
//                   subtitle: Text(
//                     answer != null
//                         ? (isCorrect ? 'Correct' : 'Incorrect')
//                         : 'Not answered',
//                     style: TextStyle(
//                       color: answer != null
//                           ? (isCorrect ? Colors.green : Colors.red)
//                           : Colors.grey,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.all(16),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           if (answer != null && !isCorrect)
//                             Container(
//                               padding: const EdgeInsets.all(12),
//                               margin: const EdgeInsets.only(bottom: 16),
//                               color: Colors.red.shade50,
//                               child: Column(
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   const Text(
//                                     'Your Answer:',
//                                     style: TextStyle(fontWeight: FontWeight.bold),
//                                   ),
//                                   const SizedBox(height: 4),
//                                   Text(
//                                     '${String.fromCharCode(65 + answer.selectedOptionIndex)}. ${question.options[answer.selectedOptionIndex]}',
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           Container(
//                             padding: const EdgeInsets.all(12),
//                             color: Colors.green.shade50,
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const Text(
//                                   'Correct Answer:',
//                                   style: TextStyle(fontWeight: FontWeight.bold),
//                                 ),
//                                 const SizedBox(height: 4),
//                                 Text(
//                                   '${String.fromCharCode(65 + question.correctAnswerIndex)}. ${question.options[question.correctAnswerIndex]}',
//                                 ),
//                                 const SizedBox(height: 12),
//                                 const Text(
//                                   'Explanation:',
//                                   style: TextStyle(fontWeight: FontWeight.bold),
//                                 ),
//                                 const SizedBox(height: 4),
//                                 Text(question.explanation),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               );
//             }),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildStatCard(String title, String value, IconData icon, Color color) {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(16),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withValues(alpha:0.05),
//             blurRadius: 10,
//             offset: const Offset(0, 2),
//           ),
//         ],
//       ),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Container(
//             padding: const EdgeInsets.all(8),
//             decoration: BoxDecoration(
//               color: color.withValues(alpha:0.1),
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Icon(icon, color: color, size: 28),
//           ),
//           const SizedBox(height: 8),
//           Text(
//             value,
//             style: TextStyle(
//               fontSize: 24,
//               fontWeight: FontWeight.bold,
//               color: color,
//             ),
//           ),
//           const SizedBox(height: 4),
//           Text(
//             title,
//             style: const TextStyle(fontSize: 12, color: Colors.grey),
//             textAlign: TextAlign.center,
//           ),
//         ],
//       ),
//     );
//   }
// }