// // ==================== TUTORIAL PAGE - CLEAN FUNCTIONAL DESIGN ====================
// import 'dart:collection';
// import 'dart:convert';
// import 'dart:math';
// import 'dart:html' as html;
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:go_router/go_router.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:techtutorial/screens/AdsenseAd.dart';
// import 'package:techtutorial/screens/tutorial/content_widget.dart';

// import '../../core/meta_service.dart';
// import '../../core/theme.dart';
// import '../../models/content_item.dart';
// import '../../models/quiz_question.dart';
// import '../../models/tutorial_data.dart';
// import '../../models/tutorial_topic.dart';
// import 'editor_widget.dart';
// import 'quiz_widgets.dart';
// import 'package:http/http.dart' as http;

// class TutorialArguments {
//   final String slug;
//   final String category;
//   final List<TutorialTopic> allTopics;

//   TutorialArguments({
//     required this.slug,
//     required this.category,
//     required this.allTopics,
//   });
// }

// class TutorialPage extends StatefulWidget {
//   final TutorialArguments args;
//   const TutorialPage({super.key, required this.args});

//   @override
//   State<TutorialPage> createState() => _TutorialPageState();
// }

// class _TutorialPageState extends State<TutorialPage>
//     with SingleTickerProviderStateMixin {
//   static final LinkedHashMap<String, TutorialData> _cache = LinkedHashMap();
//   static const int _maxCacheSize = 20;

//   String get tutorialsBaseUrl =>
//       'https://json.revochamp.site/${widget.args.category}/';

//   TutorialData? _data;
//   bool _isLoading = true;
//   String? _error;

//   List<QuizQuestionState> _quizStates = [];
//   bool _quizSubmitted = false;
//   int _score = 0;

//   late AnimationController _animationController;
//   late Animation<double> _fadeAnimation;
//   final TextEditingController _codeController = TextEditingController();
//   final ScrollController _scrollController = ScrollController();
//   final ScrollController _sideMenuController = ScrollController();

//   final List<GlobalKey> _headingKeys = [];
//   double _scrollProgress = 0.0;
//   int _currentSectionIndex = 0;

//   final GlobalKey _contentKey = GlobalKey();
//   bool _isFavorite = false;

//   @override
//   void initState() {
//     super.initState();
//     _animationController = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 600),
//     );
//     _fadeAnimation = CurvedAnimation(
//       parent: _animationController,
//       curve: Curves.easeOutCubic,
//     );
//     _loadTutorial();
//     _scrollController.addListener(_updateScrollProgress);
//     _scrollController.addListener(_updateActiveHeading);
//     _checkFavorite();
//   }

//   @override
//   void dispose() {
//     _animationController.dispose();
//     _codeController.dispose();
//     _scrollController.removeListener(_updateScrollProgress);
//     _scrollController.removeListener(_updateActiveHeading);
//     _scrollController.dispose();
//     _sideMenuController.dispose();
//     super.dispose();
//   }

//   void _updateScrollProgress() {
//     if (!mounted) return;
//     if (_scrollController.hasClients && _scrollController.position.maxScrollExtent > 0) {
//       final progress = _scrollController.offset / _scrollController.position.maxScrollExtent;
//       if ((_scrollProgress - progress).abs() > 0.01) {
//         setState(() {
//           _scrollProgress = progress;
//         });
//       }
//     }
//   }

//   void _updateActiveHeading() {
//     if (!mounted || _headingKeys.isEmpty) return;
    
//     int activeIndex = 0;
//     for (int i = 0; i < _headingKeys.length; i++) {
//       final key = _headingKeys[i];
//       final context = key.currentContext;
//       if (context != null) {
//         final box = context.findRenderObject() as RenderBox?;
//         if (box != null) {
//           final position = box.localToGlobal(Offset.zero).dy;
//           if (position > 0 && position < 250) {
//             activeIndex = i;
//             break;
//           }
//         }
//       }
//     }
    
//     if (_currentSectionIndex != activeIndex) {
//       setState(() => _currentSectionIndex = activeIndex);
//       if (_sideMenuController.hasClients) {
//         final double itemHeight = 48.0;
//         final double targetOffset = (activeIndex * itemHeight) - _sideMenuController.position.viewportDimension / 2;
//         _sideMenuController.animateTo(
//           targetOffset.clamp(0.0, _sideMenuController.position.maxScrollExtent),
//           duration: const Duration(milliseconds: 300),
//           curve: Curves.easeOutCubic,
//         );
//       }
//     }
//   }

//   Future<void> _checkFavorite() async {
//     final prefs = await SharedPreferences.getInstance();
//     final favorites = prefs.getStringList('favorites') ?? [];
//     setState(() {
//       _isFavorite = favorites.contains('${widget.args.category}/${widget.args.slug}');
//     });
//   }

//   Future<void> _toggleFavorite() async {
//     final prefs = await SharedPreferences.getInstance();
//     final favorites = prefs.getStringList('favorites') ?? [];
//     final key = '${widget.args.category}/${widget.args.slug}';
    
//     if (_isFavorite) {
//       favorites.remove(key);
//       _showSnackBar('Removed from favorites');
//     } else {
//       favorites.add(key);
//       _showSnackBar('Added to favorites');
//     }
    
//     await prefs.setStringList('favorites', favorites);
//     setState(() {
//       _isFavorite = !_isFavorite;
//     });
//   }

//   Future<void> _loadTutorial() async {
//     final slug = widget.args.slug;
//     if (slug.isEmpty) {
//       setState(() {
//         _error = 'Invalid tutorial slug.';
//         _isLoading = false;
//       });
//       return;
//     }

//     try {
//       if (_cache.containsKey(slug)) {
//         _data = _cache[slug];
//       } else {
//         final url = Uri.parse('$tutorialsBaseUrl$slug.json');
//         debugPrint('Loading tutorial from: $url');
//         final response = await http.get(url);

//         if (response.statusCode == 200) {
//           final json = jsonDecode(response.body);
//           _data = _parseTutorialData(json);
//           _cache[slug] = _data!;
//           if (_cache.length > _maxCacheSize) {
//             _cache.remove(_cache.keys.first);
//           }
//         } else {
//           setState(() {
//             _error = 'Failed to load tutorial: HTTP ${response.statusCode}';
//             _isLoading = false;
//           });
//           return;
//         }
//       }
//       _initializeFromData();
//       setState(() => _isLoading = false);
//       _animationController.forward();
//     } catch (e) {
//       setState(() {
//         _error = 'Failed to load tutorial: $e';
//         _isLoading = false;
//       });
//     }
//   }

// TutorialData _parseTutorialData(Map<String, dynamic> json) {
//   final contentList = <ContentItem>[];
//   try {
//     for (var item in json['content'] ?? []) {
//       final type = item['type'];
//       final value = item['value'];
      
//       if (type == 'heading') {
//         contentList.add(
//           ContentItem(type: ContentType.heading, value: value as String),
//         );
//       } else if (type == 'subheading') {
//         contentList.add(
//           ContentItem(type: ContentType.subheading, value: value as String),
//         );
//       } else if (type == 'text') {
//         contentList.add(
//           ContentItem(type: ContentType.text, value: value as String),
//         );
//       } else if (type == 'code') {
//         contentList.add(
//           ContentItem(
//             type: ContentType.code,
//             value: value as String,
//             language: item['language'],
//           ),
//         );
//       } else if (type == 'list') {
//         // Handle list - store as List directly
//         if (value is List) {
//           contentList.add(
//             ContentItem(type: ContentType.list, value: value),
//           );
//         } else if (value is String) {
//           final listItems = value.split('\n').where((l) => l.trim().isNotEmpty).toList();
//           contentList.add(
//             ContentItem(type: ContentType.list, value: listItems),
//           );
//         } else {
//           contentList.add(
//             ContentItem(type: ContentType.list, value: []),
//           );
//         }
//       } else if (type == 'table') {
//         // Handle table type
//         contentList.add(
//           ContentItem(
//             type: ContentType.table,
//             value: '', // Table doesn't need value string
//             tableData: item['value'] as Map<String, dynamic>?,
//           ),
//         );
//       } else if (type == 'callout') {
//         // Handle callout type
//         contentList.add(
//           ContentItem(
//             type: ContentType.callout,
//             value: value as String,
//             variant: item['variant'] as String? ?? 'info',
//           ),
//         );
//       }
//     }
//   } catch (e) {
//     debugPrint('Error parsing content: $e');
//   }

//   final quizList = <QuizQuestion>[];
//   try {
//     for (var q in json['quiz'] ?? []) {
//       quizList.add(
//         QuizQuestion(
//           question: q['question'],
//           options: List<String>.from(q['options']),
//           answer: q['answer'],
//           explanation: q['explanation'],
//         ),
//       );
//     }
//   } catch (e) {
//     debugPrint('Error parsing quiz: $e');
//   }

//   return TutorialData(
//     title: json['title'] ?? 'Untitled',
//     subtitle: json['subtitle'] ?? '',
//     difficulty: json['difficulty'] ?? '',
//     readTime: json['readTime'] ?? '',
//     meta: json['meta'],
//     faq: (json['faq'] as List?)?.cast<Map<String, dynamic>>() ?? [],
//     content: contentList,
//     quiz: quizList,
//     defaultCode: json['tryEditor']?['defaultCode'] ?? '',
//     relatedSlugs: (json['related'] as List?)?.cast<String>() ?? [],
//   );
// }

//   // TutorialData _parseTutorialData(Map<String, dynamic> json) {
//   //   final contentList = <ContentItem>[];
//   //   try {
//   //     for (var item in json['content'] ?? []) {
//   //       final type = item['type'];
//   //       final value = item['value'];
//   //       if (type == 'heading') {
//   //         contentList.add(
//   //           ContentItem(type: ContentType.heading, value: value as String),
//   //         );
//   //       } else if (type == 'text') {
//   //         contentList.add(
//   //           ContentItem(type: ContentType.text, value: value as String),
//   //         );
//   //       } else if (type == 'code') {
//   //         contentList.add(
//   //           ContentItem(
//   //             type: ContentType.code,
//   //             value: value as String,
//   //             language: item['language'],
//   //           ),
//   //         );
//   //       } else if (type == 'list') {
//   //         final listValue = (value as List).join('\n');
//   //         contentList.add(
//   //           ContentItem(type: ContentType.list, value: listValue),
//   //         );
//   //       }
//   //     }
//   //   } catch (e) {
//   //     debugPrint('Error parsing content: $e');
//   //   }

//   //   final quizList = <QuizQuestion>[];
//   //   try {
//   //     for (var q in json['quiz'] ?? []) {
//   //       quizList.add(
//   //         QuizQuestion(
//   //           question: q['question'],
//   //           options: List<String>.from(q['options']),
//   //           answer: q['answer'],
//   //           explanation: q['explanation'],
//   //         ),
//   //       );
//   //     }
//   //   } catch (e) {
//   //     debugPrint('Error parsing quiz: $e');
//   //   }

//   //   return TutorialData(
//   //     title: json['title'] ?? 'Untitled',
//   //     subtitle: json['subtitle'] ?? '',
//   //     difficulty: json['difficulty'] ?? '',
//   //     readTime: json['readTime'] ?? '',
//   //     meta: json['meta'],
//   //     faq: (json['faq'] as List?)?.cast<Map<String, dynamic>>() ?? [],
//   //     content: contentList,
//   //     quiz: quizList,
//   //     defaultCode: json['tryEditor']?['defaultCode'] ?? '',
//   //     relatedSlugs: (json['related'] as List?)?.cast<String>() ?? [],
//   //   );
//   // }

//   void _initializeFromData() {
//     if (_data == null) return;
//     _quizStates = List.generate(_data!.quiz.length, (_) => QuizQuestionState());
//     _codeController.text = _data!.defaultCode;
//     _headingKeys.clear();
//     for (var i = 0; i < _data!.content.length; i++) {
//       if (_data!.content[i].type == ContentType.heading) {
//         _headingKeys.add(GlobalKey());
//       }
//     }
//     _updateSeo();
//     _updateStructuredData();

//     if (kIsWeb) {
//       _addHiddenH1(_data!.title);
//       _injectFaqHtml();
//       _injectInternalLinks();
//       _injectContentHtml();

//       final parents = [
//         {
//           'name': '${widget.args.category.toUpperCase()} Tutorials',
//           'url': 'https://revochamp.site/tech/${widget.args.category}',
//         },
//       ];
//       MetaService.setBreadcrumbData(
//         title: _data!.title,
//         slug: '${widget.args.category}/${widget.args.slug}',
//         parents: parents,
//       );
//     }
//   }

//   void _addHiddenH1(String text) {
//     final existing = html.document.querySelector('h1.seo-hidden');
//     existing?.remove();

//     final h1 = html.HeadingElement.h1()
//       ..text = text
//       ..className = 'seo-hidden'
//       ..style.position = 'absolute'
//       ..style.left = '-9999px'
//       ..style.top = '-9999px'
//       ..style.width = '1px'
//       ..style.height = '1px'
//       ..style.overflow = 'hidden';

//     html.document.body?.append(h1);
//   }

//   void _injectInternalLinks() {
//     if (!kIsWeb || _data == null) return;

//     final div = html.DivElement()
//       ..style.position = 'absolute'
//       ..style.left = '-9999px';

//     for (var slug in _data!.relatedSlugs) {
//       final a = html.AnchorElement()
//         ..href = '/${widget.args.category}/$slug'
//         ..text = slug;
//       div.append(a);
//     }

//     html.document.body?.append(div);
//   }

//   void _injectContentHtml() {
//     if (!kIsWeb || _data == null) return;

//     final div = html.DivElement()
//       ..style.position = 'absolute'
//       ..style.left = '-9999px';

//     for (var item in _data!.content) {
//       if (item.type == ContentType.text || item.type == ContentType.heading) {
//         div.append(html.ParagraphElement()..text = item.value);
//       }
//     }

//     html.document.body?.append(div);
//   }

//   void _injectFaqHtml() {
//     if (!kIsWeb || _data == null || _data!.faq.isEmpty) return;

//     final container = html.DivElement()
//       ..style.position = 'absolute'
//       ..style.left = '-9999px';

//     for (var f in _data!.faq) {
//       final q = html.HeadingElement.h2()..text = f['question'];
//       final a = html.ParagraphElement()..text = f['answer'];
//       container.append(q);
//       container.append(a);
//     }

//     html.document.body?.append(container);
//   }

//   void _updateSeo() {
//     if (!kIsWeb) return;

//     String description =
//         'Learn ${_data!.title} with this interactive ${widget.args.category} tutorial.';
//     if (_data!.content.isNotEmpty) {
//       final firstText = _data!.content.firstWhere(
//         (item) => item.type == ContentType.text,
//         orElse: () => ContentItem(type: ContentType.text, value: description),
//       );
//       description = firstText.value.substring(
//         0,
//         min(160, firstText.value.length),
//       );
//     }

//     final metaTitle =
//         _data!.meta?['title'] ??
//         '${_data!.title} - ${widget.args.category.toUpperCase()} Tutorials';
//     final metaDescription = _data!.meta?['description'] ?? description;
//     final imageUrl =
//         _data!.meta?['image'] ?? 'https://revochamp.site/banner.png';

//     MetaService.updateMetaTags(
//       title: metaTitle,
//       description: metaDescription,
//       slug: '${widget.args.category}/${widget.args.slug}',
//       keywords: [widget.args.category, 'tutorial', _data!.title.toLowerCase()],
//       isArticle: true,
//       imageUrl: imageUrl,
//     );

//     MetaService.setOGTags(
//       title: metaTitle,
//       description: metaDescription,
//       image: imageUrl,
//     );

//     MetaService.setTwitterTags(
//       title: metaTitle,
//       description: metaDescription,
//       image: imageUrl,
//     );
//   }

//   void _updateStructuredData() {
//     final baseUrl = 'https://revochamp.site/tech';
//     final pageId = 'https://revochamp.site/tech/${widget.args.category}/${widget.args.slug}';
    
//     final structuredData = {
//       "@context": "https://schema.org",
//       "@type": "TechArticle",
//       "headline": _data!.title,
//       "description": _getDescription(),
//       "author": {
//         "@type": "Person",
//         "name": "${widget.args.category.toUpperCase()} Tutorials Team",
//       },
//       "datePublished": _data!.meta?['datePublished'] ?? "2025-01-01",
//       "dateModified":
//           _data!.meta?['dateModified'] ?? DateTime.now().toIso8601String(),
//       "image": _data!.meta?['image'] ?? "$baseUrl/icon.png",
//       "publisher": {
//         "@type": "Organization",
//         "name": "Revochamp",
//         "logo": {"@type": "ImageObject", "url": "$baseUrl/logo.png"},
//       },
//       "mainEntityOfPage": {"@type": "WebPage", "@id": pageId},
//     };

//     if (_data!.faq.isNotEmpty) {
//       final graph = [
//         structuredData,
//         {
//           "@type": "FAQPage",
//           "mainEntity": _data!.faq
//               .map(
//                 (f) => {
//                   "@type": "Question",
//                   "name": f['question'],
//                   "acceptedAnswer": {"@type": "Answer", "text": f['answer']},
//                 },
//               )
//               .toList(),
//         },
//       ];
//       MetaService.setStructuredData({
//         "@context": "https://schema.org",
//         "@graph": graph,
//       });
//     } else {
//       MetaService.setStructuredData(structuredData);
//     }
//   }

//   String _getDescription() {
//     if (_data!.content.isNotEmpty) {
//       final textItem = _data!.content.firstWhere(
//         (item) => item.type == ContentType.text,
//         orElse: () => ContentItem(type: ContentType.text, value: ''),
//       );
//       final value = textItem.value;
//       return value.substring(0, min(160, value.length));
//     }
//     return 'Interactive ${widget.args.category} tutorial about ${_data!.title}.';
//   }

//   void _submitQuiz() {
//     if (_quizStates.any((state) => state.selectedAnswer == null)) {
//       _showSnackBar('Please answer all questions');
//       return;
//     }

//     int score = 0;
//     for (int i = 0; i < _data!.quiz.length; i++) {
//       final isCorrect = _quizStates[i].selectedAnswer == _data!.quiz[i].answer;
//       _quizStates[i].isCorrect = isCorrect;
//       _quizStates[i].explanation = _data!.quiz[i].explanation;
//       if (isCorrect) score++;
//     }

//     setState(() {
//       _score = score;
//       _quizSubmitted = true;
//     });
//     _markCompleted();
//   }

//   Future<void> _markCompleted() async {
//     final prefs = await SharedPreferences.getInstance();
//     final key = 'completed_${widget.args.category}';
//     final completed = prefs.getStringList(key) ?? [];
//     if (!completed.contains(widget.args.slug)) {
//       completed.add(widget.args.slug);
//       await prefs.setStringList(key, completed);
//     }
//   }

//   void _resetQuiz() {
//     setState(() {
//       _quizStates = List.generate(
//         _data!.quiz.length,
//         (_) => QuizQuestionState(),
//       );
//       _quizSubmitted = false;
//       _score = 0;
//     });
//   }

//   void _copyCode(String code) {
//     Clipboard.setData(ClipboardData(text: code));
//     _showSnackBar('Copied to clipboard');
//   }

//   void _goToPrevious() {
//     final topics = widget.args.allTopics;
//     if (topics.isEmpty) {
//       _showSnackBar('Loading topics... please wait');
//       return;
//     }
//     final currentIndex = topics.indexWhere((t) => t.slug == widget.args.slug);

//     if (currentIndex > 0) {
//       final previousSlug = topics[currentIndex - 1].slug;
//       context.go('/${widget.args.category}/$previousSlug');
//     } else {
//       _showSnackBar('This is the first tutorial');
//     }
//   }

//   void _goToNext() {
//     final topics = widget.args.allTopics;
//     if (topics.isEmpty) {
//       _showSnackBar('Loading topics... please wait');
//       return;
//     }
//     final currentIndex = topics.indexWhere((t) => t.slug == widget.args.slug);

//     if (currentIndex < topics.length - 1) {
//       final nextSlug = topics[currentIndex + 1].slug;
//       context.go('/${widget.args.category}/$nextSlug');
//     } else {
//       _showSnackBar('🎉 Congratulations! You completed all tutorials!');
//     }
//   }

//   void _shareTutorial() {
//     final url =
//         'https://revochamp.site/tech/${widget.args.category}/${widget.args.slug}';
//     final title = _data!.title;

//     if (kIsWeb && html.window.navigator.share != null) {
//       html.window.navigator.share!({'title': title, 'url': url})
//           .catchError((error) {
//             _fallbackShare(url);
//           });
//     } else {
//       _fallbackShare(url);
//     }
//   }

//   void _fallbackShare(String url) {
//     Clipboard.setData(ClipboardData(text: url));
//     _showSnackBar('Link copied to clipboard!');
//   }

//   void _showSnackBar(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(message),
//         behavior: SnackBarBehavior.floating,
//         backgroundColor: PremiumTheme.richBlue,
//         duration: const Duration(seconds: 2),
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
//       ),
//     );
//   }

//   List<ContentItem> get _headings {
//     if (_data == null) return [];
//     return _data!.content
//         .where((item) => item.type == ContentType.heading)
//         .toList();
//   }

//   void _scrollToHeading(int index) {
//     if (index < _headingKeys.length &&
//         _headingKeys[index].currentContext != null) {
//       Scrollable.ensureVisible(
//         _headingKeys[index].currentContext!,
//         duration: const Duration(milliseconds: 400),
//         curve: Curves.easeInOutCubic,
//       );
//       setState(() => _currentSectionIndex = index);
//     }
//   }

//   // ==================== SIMPLE AD WIDGET (WITH FIXED HEIGHT) ====================
  
//   Widget _buildAdWidget(String adSlot) {
//     if (!kIsWeb) return const SizedBox.shrink();
    
//     // Fixed height container to prevent infinite size error
//     return Container(
//       height: 260,
//       margin: const EdgeInsets.symmetric(vertical: 24),
//       child: AdsenseAd(
//         adSlot: adSlot,
//         // adFormat: "rectangle",
//       ),
//     );
//   }

//   // ==================== BUILD METHODS ====================

//   @override
//   Widget build(BuildContext context) {
//     if (_isLoading) return _buildLoadingScreen();
//     if (_error != null) return _buildErrorScreen();
//     if (_data == null) return _buildErrorScreen();

//     final isDesktop = MediaQuery.of(context).size.width > 1000;

//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: _buildAppBar(),
//       body: isDesktop ? _buildDesktopLayout() : _buildMobileLayout(),
//     );
//   }

//   PreferredSizeWidget _buildAppBar() {
//     return AppBar(
//       title: Text(
//         _data?.title ?? 'Tutorial',
//         style: const TextStyle(
//           fontSize: 16,
//           fontWeight: FontWeight.w600,
//           color: Colors.black87,
//         ),
//         overflow: TextOverflow.ellipsis,
//       ),
//       backgroundColor: Colors.white,
//       elevation: 0,
//       centerTitle: false,
//       leading: IconButton(
//         icon: const Icon(Icons.arrow_back_rounded, color: Colors.black87),
//         onPressed: () {
//           if (context.canPop()) {
//             context.pop();
//           } else {
//             context.go('/${widget.args.category}');
//           }
//         },
//       ),
//       actions: [
//         IconButton(
//           icon: const Icon(Icons.share_rounded),
//           onPressed: _shareTutorial,
//           tooltip: 'Share',
//         ),
//         IconButton(
//           icon: Icon(
//             _isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
//             color: _isFavorite ? Colors.red : null,
//           ),
//           onPressed: _toggleFavorite,
//           tooltip: _isFavorite ? 'Remove from favorites' : 'Add to favorites',
//         ),
//       ],
//       bottom: PreferredSize(
//         preferredSize: const Size.fromHeight(2),
//         child: LinearProgressIndicator(
//           value: _scrollProgress,
//           minHeight: 2,
//           backgroundColor: Colors.grey.shade200,
//           valueColor: const AlwaysStoppedAnimation(PremiumTheme.richBlue),
//         ),
//       ),
//     );
//   }

//   Widget _buildLoadingScreen() {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const CircularProgressIndicator(),
//             const SizedBox(height: 16),
//             const Text(
//               'Loading tutorial...',
//               style: TextStyle(color: Colors.grey),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildErrorScreen() {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const Icon(Icons.error_outline, size: 48, color: Colors.red),
//             const SizedBox(height: 16),
//             Text(
//               _error ?? 'Something went wrong',
//               style: const TextStyle(color: Colors.grey),
//             ),
//             const SizedBox(height: 16),
//             ElevatedButton(
//               onPressed: () {
//                 setState(() {
//                   _isLoading = true;
//                   _error = null;
//                 });
//                 _loadTutorial();
//               },
//               child: const Text('Try Again'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildDesktopLayout() {
//     return Row(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         // Left Sidebar
//         Container(
//           width: 280,
//           decoration: BoxDecoration(
//             border: Border(right: BorderSide(color: Colors.grey.shade200)),
//           ),
//           child: Column(
//             children: [
//               // Sidebar Header
//               Container(
//                 padding: const EdgeInsets.all(20),
//                 child: Row(
//                   children: [
//                     Icon(Icons.menu_book, color: PremiumTheme.richBlue),
//                     const SizedBox(width: 12),
//                     const Expanded(
//                       child: Text(
//                         'Contents',
//                         style: TextStyle(
//                           fontSize: 16,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ),
//                     Container(
//                       padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
//                       decoration: BoxDecoration(
//                         color: PremiumTheme.richBlue.withValues(alpha:0.1),
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                       child: Text(
//                         '${_headings.length}',
//                         style: TextStyle(
//                           fontSize: 12,
//                           color: PremiumTheme.richBlue,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               const Divider(height: 1),
//               // Headings List
//               Expanded(
//                 child: ListView.builder(
//                   controller: _sideMenuController,
//                   padding: const EdgeInsets.symmetric(vertical: 8),
//                   itemCount: _headings.length,
//                   itemBuilder: (context, index) {
//                     final item = _headings[index];
//                     final isActive = index == _currentSectionIndex;
//                     return _buildSidebarItem(item.value, index, isActive);
//                   },
//                 ),
//               ),
//               // Progress Section
//               Container(
//                 padding: const EdgeInsets.all(20),
//                 decoration: BoxDecoration(
//                   border: Border(top: BorderSide(color: Colors.grey.shade200)),
//                 ),
//                 child: Column(
//                   children: [
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         const Text('Progress', style: TextStyle(fontSize: 12)),
//                         Text(
//                           '${(_scrollProgress * 100).toInt()}%',
//                           style: const TextStyle(
//                             fontSize: 12,
//                             fontWeight: FontWeight.w600,
//                             color: PremiumTheme.richBlue,
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(height: 8),
//                     LinearProgressIndicator(
//                       value: _scrollProgress,
//                       backgroundColor: Colors.grey.shade200,
//                       color: PremiumTheme.richBlue,
//                     ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
        
//         // Main Content
//         Expanded(
//           child: SingleChildScrollView(
//             controller: _scrollController,
//             padding: const EdgeInsets.all(32),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 _buildHeroHeader(),
//                 const SizedBox(height: 32),
//                 ..._buildContentItems(),
//                 const SizedBox(height: 32),
                
//                 // Ad after content
//                 _buildAdWidget("content_ad"),
                
//                 _buildEditorSection(),
//                 const SizedBox(height: 48),
                
//                 // Quiz Section
//                 if (_data!.quiz.isNotEmpty) ...[
//                   _buildAdWidget("quiz_ad"),
//                   const SizedBox(height: 16),
//                   _buildQuizSection(),
//                 ],
                
//                 // FAQ Section
//                 if (_data!.faq.isNotEmpty) ...[
//                   const SizedBox(height: 24),
//                   _buildAdWidget("faq_ad"),
//                   const SizedBox(height: 16),
//                   _buildFaqSection(),
//                 ],
                
//                 // Related Section
//                 if (_data!.relatedSlugs.isNotEmpty) ...[
//                   const SizedBox(height: 24),
//                   _buildRelatedSection(),
//                 ],
                
//                 const SizedBox(height: 48),
//                 _buildNavigationButtons(),
//                 const SizedBox(height: 32),
//               ],
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   Widget _buildMobileLayout() {
//     return SingleChildScrollView(
//       controller: _scrollController,
//       padding: const EdgeInsets.all(20),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           _buildHeroHeader(),
//           const SizedBox(height: 24),
          
//           if (_headings.isNotEmpty) _buildMobileToc(),
//           const SizedBox(height: 24),
          
//           ..._buildContentItems(),
//           const SizedBox(height: 24),
          
//           _buildAdWidget("content_ad_mobile"),
          
//           _buildEditorSection(),
//           const SizedBox(height: 32),
          
//           if (_data!.quiz.isNotEmpty) ...[
//             _buildAdWidget("quiz_ad_mobile"),
//             const SizedBox(height: 16),
//             _buildQuizSection(),
//           ],
          
//           if (_data!.faq.isNotEmpty) ...[
//             const SizedBox(height: 24),
//             _buildAdWidget("faq_ad_mobile"),
//             const SizedBox(height: 16),
//             _buildFaqSection(),
//           ],
          
//           if (_data!.relatedSlugs.isNotEmpty) ...[
//             const SizedBox(height: 24),
//             _buildRelatedSection(),
//           ],
          
//           const SizedBox(height: 32),
//           _buildNavigationButtons(),
//           const SizedBox(height: 32),
//         ],
//       ),
//     );
//   }

//   Widget _buildHeroHeader() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         // Category Badge
//         GestureDetector(
//           onTap: () => context.go('/${widget.args.category}'),
//           child: Container(
//             padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//             decoration: BoxDecoration(
//               color: PremiumTheme.richBlue.withValues(alpha:0.1),
//               borderRadius: BorderRadius.circular(20),
//             ),
//             child: Text(
//               widget.args.category.toUpperCase(),
//               style: TextStyle(
//                 fontSize: 12,
//                 fontWeight: FontWeight.w600,
//                 color: PremiumTheme.richBlue,
//               ),
//             ),
//           ),
//         ),
//         const SizedBox(height: 20),
        
//         // Title
//         Text(
//           _data!.title,
//           style: const TextStyle(
//             fontSize: 36,
//             fontWeight: FontWeight.bold,
//             height: 1.2,
//           ),
//         ),
//         const SizedBox(height: 12),
        
//         // Subtitle
//         if (_data!.subtitle.isNotEmpty)
//           Text(
//             _data!.subtitle,
//             style: const TextStyle(fontSize: 16, color: Colors.grey),
//           ),
//         const SizedBox(height: 20),
        
//         // Meta Chips
//         Wrap(
//           spacing: 12,
//           runSpacing: 10,
//           children: [
//             if (_data!.difficulty.isNotEmpty)
//               _buildMetaChip(
//                 icon: Icons.signal_cellular_alt,
//                 label: _data!.difficulty,
//                 color: _getDifficultyColor(_data!.difficulty),
//               ),
//             if (_data!.readTime.isNotEmpty)
//               _buildMetaChip(
//                 icon: Icons.access_time,
//                 label: _data!.readTime,
//               ),
//             _buildMetaChip(
//               icon: Icons.quiz,
//               label: '${_data!.quiz.length} Quizzes',
//             ),
//             _buildMetaChip(
//               icon: Icons.code,
//               label: '${_data!.content.where((c) => c.type == ContentType.code).length} Examples',
//             ),
//           ],
//         ),
//         const SizedBox(height: 24),
        
//         // Action Buttons
//         Row(
//           children: [
//             Expanded(
//               child: OutlinedButton.icon(
//                 onPressed: _shareTutorial,
//                 icon: const Icon(Icons.share, size: 18),
//                 label: const Text('Share'),
//                 style: OutlinedButton.styleFrom(
//                   padding: const EdgeInsets.symmetric(vertical: 12),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                 ),
//               ),
//             ),
//             const SizedBox(width: 12),
//             Expanded(
//               child: OutlinedButton.icon(
//                 onPressed: _toggleFavorite,
//                 icon: Icon(
//                   _isFavorite ? Icons.favorite : Icons.favorite_border,
//                   size: 18,
//                   color: _isFavorite ? Colors.red : null,
//                 ),
//                 label: Text(_isFavorite ? 'Saved' : 'Save'),
//                 style: OutlinedButton.styleFrom(
//                   padding: const EdgeInsets.symmetric(vertical: 12),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildMetaChip({
//     required IconData icon,
//     required String label,
//     Color? color,
//   }) {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
//       decoration: BoxDecoration(
//         color: Colors.grey.shade50,
//         borderRadius: BorderRadius.circular(20),
//         border: Border.all(color: Colors.grey.shade200),
//       ),
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           Icon(icon, size: 14, color: color ?? Colors.grey),
//           const SizedBox(width: 6),
//           Text(
//             label,
//             style: TextStyle(fontSize: 12, color: color ?? Colors.grey),
//           ),
//         ],
//       ),
//     );
//   }

//   Color _getDifficultyColor(String difficulty) {
//     switch (difficulty.toLowerCase()) {
//       case 'beginner':
//         return Colors.green;
//       case 'intermediate':
//         return Colors.orange;
//       case 'advanced':
//         return Colors.red;
//       default:
//         return PremiumTheme.richBlue;
//     }
//   }

//   Widget _buildSidebarItem(String title, int index, bool isActive) {
//     return InkWell(
//       onTap: () => _scrollToHeading(index),
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
//         decoration: BoxDecoration(
//           color: isActive ? PremiumTheme.richBlue.withValues(alpha:0.05) : null,
//           border: Border(
//             left: BorderSide(
//               color: isActive ? PremiumTheme.richBlue : Colors.transparent,
//               width: 3,
//             ),
//           ),
//         ),
//         child: Text(
//           title,
//           style: TextStyle(
//             fontSize: 13,
//             fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
//             color: isActive ? PremiumTheme.richBlue : Colors.grey.shade700,
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildMobileToc() {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.grey.shade50,
//         borderRadius: BorderRadius.circular(12),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Text(
//             'In this tutorial',
//             style: TextStyle(fontWeight: FontWeight.w600),
//           ),
//           const SizedBox(height: 12),
//           Wrap(
//             spacing: 8,
//             runSpacing: 8,
//             children: _headings.asMap().entries.map((entry) {
//               final idx = entry.key;
//               final heading = entry.value;
//               return GestureDetector(
//                 onTap: () => _scrollToHeading(idx),
//                 child: Container(
//                   padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                   decoration: BoxDecoration(
//                     color: Colors.white,
//                     borderRadius: BorderRadius.circular(20),
//                     border: Border.all(color: Colors.grey.shade200),
//                   ),
//                   child: Text(
//                     heading.value,
//                     style: TextStyle(fontSize: 12, color: PremiumTheme.richBlue),
//                   ),
//                 ),
//               );
//             }).toList(),
//           ),
//         ],
//       ),
//     );
//   }

//   // YOUR ORIGINAL CONTENT ITEMS - UNCHANGED
//   List<Widget> _buildContentItems() {
//     List<Widget> widgets = [];
//     int headingIdx = 0;

//     for (int i = 0; i < _data!.content.length; i++) {
//       final item = _data!.content[i];
      
//       if (item.type == ContentType.heading) {
//         widgets.add(
//           Container(
//             key: headingIdx < _headingKeys.length
//                 ? _headingKeys[headingIdx]
//                 : null,
//             margin: const EdgeInsets.only(top: 24, bottom: 12),
//             child: ContentItemWidget(item: item, onCopy: _copyCode),
//           ),
//         );
//         headingIdx++;
//       } else {
//         widgets.add(
//           Container(
//             margin: const EdgeInsets.symmetric(vertical: 8),
//             child: ContentItemWidget(item: item, onCopy: _copyCode),
//           ),
//         );
//       }
//     }
//     return widgets;
//   }

//   Widget _buildEditorSection() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildSectionHeader(
//           icon: Icons.edit_note,
//           title: 'Try it Yourself',
//           subtitle: 'Experiment with the code below',
//         ),
//         const SizedBox(height: 20),
//         EditorWidget(
//           codeController: _codeController,
//           defaultCode: _data!.defaultCode,
//           onCopy: _copyCode,
//           onRun: () {
//             _showSnackBar('Running your code...');
//           },
//           onReset: () =>
//               setState(() => _codeController.text = _data!.defaultCode),
//         ),
//       ],
//     );
//   }

//   Widget _buildQuizSection() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildSectionHeader(
//           icon: Icons.quiz,
//           title: 'Test Your Knowledge',
//           subtitle: '${_data!.quiz.length} questions to check your understanding',
//         ),
//         const SizedBox(height: 20),
//         for (int i = 0; i < _data!.quiz.length; i++)
//           Padding(
//             padding: const EdgeInsets.only(bottom: 16),
//             child: QuizCard(
//               index: i,
//               total: _data!.quiz.length,
//               question: _data!.quiz[i],
//               state: _quizStates[i],
//               submitted: _quizSubmitted,
//               onAnswerSelected: (answerIndex) {
//                 if (!_quizSubmitted) {
//                   setState(() => _quizStates[i].selectedAnswer = answerIndex);
//                 }
//               },
//             ),
//           ),
//         if (_quizSubmitted)
//           Container(
//             margin: const EdgeInsets.symmetric(vertical: 16),
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               color: Colors.green.withValues(alpha:0.05),
//               borderRadius: BorderRadius.circular(16),
//             ),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     const Text('Your Score', style: TextStyle(color: Colors.grey)),
//                     const SizedBox(height: 4),
//                     Text(
//                       '$_score/${_data!.quiz.length}',
//                       style: const TextStyle(
//                         fontSize: 28,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.green,
//                       ),
//                     ),
//                   ],
//                 ),
//                 Icon(
//                   _score == _data!.quiz.length
//                       ? Icons.emoji_events
//                       : Icons.school,
//                   size: 40,
//                   color: _score == _data!.quiz.length ? Colors.amber : Colors.green,
//                 ),
//               ],
//             ),
//           ),
//         const SizedBox(height: 16),
//         Row(
//           children: [
//             Expanded(
//               child: ElevatedButton(
//                 onPressed: _submitQuiz,
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: PremiumTheme.richBlue,
//                   padding: const EdgeInsets.symmetric(vertical: 14),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                 ),
//                 child: const Text('Submit Answers'),
//               ),
//             ),
//             if (_quizSubmitted) ...[
//               const SizedBox(width: 12),
//               Expanded(
//                 child: OutlinedButton(
//                   onPressed: _resetQuiz,
//                   style: OutlinedButton.styleFrom(
//                     padding: const EdgeInsets.symmetric(vertical: 14),
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(12),
//                     ),
//                   ),
//                   child: const Text('Try Again'),
//                 ),
//               ),
//             ],
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildFaqSection() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildSectionHeader(
//           icon: Icons.help,
//           title: 'Frequently Asked Questions',
//           subtitle: 'Common questions about this topic',
//         ),
//         const SizedBox(height: 20),
//         ..._data!.faq.asMap().entries.map((entry) {
//           final index = entry.key;
//           final item = entry.value;
//           return Container(
//             margin: const EdgeInsets.only(bottom: 12),
//             decoration: BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.circular(12),
//               border: Border.all(color: Colors.grey.shade200),
//             ),
//             child: ExpansionTile(
//               leading: Container(
//                 width: 28,
//                 height: 28,
//                 decoration: BoxDecoration(
//                   color: PremiumTheme.richBlue.withValues(alpha:0.1),
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: Center(
//                   child: Text(
//                     '${index + 1}',
//                     style: TextStyle(
//                       color: PremiumTheme.richBlue,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                 ),
//               ),
//               title: Text(
//                 item['question'] ?? '',
//                 style: const TextStyle(fontWeight: FontWeight.w600),
//               ),
//               children: [
//                 Padding(
//                   padding: const EdgeInsets.all(16),
//                   child: Text(
//                     item['answer'] ?? '',
//                     style: const TextStyle(color: Colors.grey, height: 1.5),
//                   ),
//                 ),
//               ],
//             ),
//           );
//         }),
//       ],
//     );
//   }

//   Widget _buildRelatedSection() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildSectionHeader(
//           icon: Icons.link,
//           title: 'Related Tutorials',
//           subtitle: 'Continue learning with these topics',
//         ),
//         const SizedBox(height: 20),
//         Wrap(
//           spacing: 12,
//           runSpacing: 12,
//           children: _data!.relatedSlugs.map((slug) {
//             final displayName = slug
//                 .replaceFirst('${widget.args.category}-', '')
//                 .replaceAll('-', ' ')
//                 .split(' ')
//                 .map((word) => word[0].toUpperCase() + word.substring(1))
//                 .join(' ');
            
//             return GestureDetector(
//               onTap: () {
//                 context.go('/${widget.args.category}/$slug');
//               },
//               child: Container(
//                 padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//                 decoration: BoxDecoration(
//                   color: Colors.grey.shade50,
//                   borderRadius: BorderRadius.circular(12),
//                   border: Border.all(color: Colors.grey.shade200),
//                 ),
//                 child: Row(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     Icon(Icons.arrow_forward, size: 14, color: PremiumTheme.richBlue),
//                     const SizedBox(width: 8),
//                     Text(
//                       displayName,
//                       style: TextStyle(color: PremiumTheme.richBlue),
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           }).toList(),
//         ),
//       ],
//     );
//   }

//   Widget _buildSectionHeader({
//     required IconData icon,
//     required String title,
//     String? subtitle,
//   }) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Row(
//           children: [
//             Icon(icon, color: PremiumTheme.richBlue),
//             const SizedBox(width: 12),
//             Text(
//               title,
//               style: const TextStyle(
//                 fontSize: 24,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//           ],
//         ),
//         if (subtitle != null) ...[
//           const SizedBox(height: 8),
//           Text(subtitle, style: const TextStyle(color: Colors.grey)),
//         ],
//       ],
//     );
//   }

//   Widget _buildNavigationButtons() {
//     final topics = widget.args.allTopics;
//     final currentIndex = topics.indexWhere((t) => t.slug == widget.args.slug);
//     final isFirst = currentIndex <= 0;
//     final isLast = currentIndex >= topics.length - 1;

//     return Row(
//       children: [
//         Expanded(
//           child: OutlinedButton.icon(
//             onPressed: isFirst ? null : _goToPrevious,
//             icon: const Icon(Icons.arrow_back, size: 18),
//             label: const Text('Previous'),
//             style: OutlinedButton.styleFrom(
//               padding: const EdgeInsets.symmetric(vertical: 14),
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(12),
//               ),
//             ),
//           ),
//         ),
//         const SizedBox(width: 16),
//         Expanded(
//           child: ElevatedButton.icon(
//             onPressed: isLast ? null : _goToNext,
//             icon: const Icon(Icons.arrow_forward, size: 18),
//             label: Text(isLast ? 'Completed' : 'Next'),
//             style: ElevatedButton.styleFrom(
//               backgroundColor: isLast ? Colors.green : PremiumTheme.richBlue,
//               padding: const EdgeInsets.symmetric(vertical: 14),
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(12),
//               ),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }
// // // ==================== TUTORIAL PAGE - MATCHING HOME PAGE DESIGN ====================
// // import 'dart:collection';
// // import 'dart:convert';
// // import 'dart:math';
// // import 'dart:html' as html;
// // import 'package:flutter/foundation.dart';
// // import 'package:flutter/material.dart';
// // import 'package:flutter/services.dart';
// // import 'package:go_router/go_router.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// // import 'package:techtutorial/screens/AdsenseAd.dart';
// // import 'package:techtutorial/screens/tutorial/content_widget.dart';

// // import '../../core/meta_service.dart';
// // import '../../core/theme.dart';
// // import '../../models/content_item.dart';
// // import '../../models/quiz_question.dart';
// // import '../../models/tutorial_data.dart';
// // import '../../models/tutorial_topic.dart';
// // import 'editor_widget.dart';
// // import 'quiz_widgets.dart';
// // import 'package:http/http.dart' as http;

// // class TutorialArguments {
// //   final String slug;
// //   final String category;
// //   final List<TutorialTopic> allTopics;

// //   TutorialArguments({
// //     required this.slug,
// //     required this.category,
// //     required this.allTopics,
// //   });
// // }

// // class TutorialPage extends StatefulWidget {
// //   final TutorialArguments args;
// //   const TutorialPage({super.key, required this.args});

// //   @override
// //   State<TutorialPage> createState() => _TutorialPageState();
// // }

// // class _TutorialPageState extends State<TutorialPage>
// //     with SingleTickerProviderStateMixin {
// //   static final LinkedHashMap<String, TutorialData> _cache = LinkedHashMap();
// //   static const int _maxCacheSize = 20;

// //   String get tutorialsBaseUrl =>
// //       'https://json.revochamp.site/${widget.args.category}/';

// //   TutorialData? _data;
// //   bool _isLoading = true;
// //   String? _error;

// //   List<QuizQuestionState> _quizStates = [];
// //   bool _quizSubmitted = false;
// //   int _score = 0;

// //   late AnimationController _animationController;
// //   late Animation<double> _fadeAnimation;
// //   final TextEditingController _codeController = TextEditingController();
// //   final ScrollController _scrollController = ScrollController();
// //   final ScrollController _sideMenuController = ScrollController();

// //   final List<GlobalKey> _headingKeys = [];
// //   double _scrollProgress = 0.0;
// //   int _currentSectionIndex = 0;

// //   final GlobalKey _contentKey = GlobalKey();
// //   bool _isFavorite = false;

// //   @override
// //   void initState() {
// //     super.initState();
// //     _animationController = AnimationController(
// //       vsync: this,
// //       duration: const Duration(milliseconds: 600),
// //     );
// //     _fadeAnimation = CurvedAnimation(
// //       parent: _animationController,
// //       curve: Curves.easeOutCubic,
// //     );
// //     _loadTutorial();
// //     _scrollController.addListener(_updateScrollProgress);
// //     _scrollController.addListener(_updateActiveHeading);
// //     _checkFavorite();
// //   }

// //   @override
// //   void dispose() {
// //     _animationController.dispose();
// //     _codeController.dispose();
// //     _scrollController.removeListener(_updateScrollProgress);
// //     _scrollController.removeListener(_updateActiveHeading);
// //     _scrollController.dispose();
// //     _sideMenuController.dispose();
// //     super.dispose();
// //   }

// //   void _updateScrollProgress() {
// //     if (!mounted) return;
// //     if (_scrollController.hasClients && _scrollController.position.maxScrollExtent > 0) {
// //       final progress = _scrollController.offset / _scrollController.position.maxScrollExtent;
// //       if ((_scrollProgress - progress).abs() > 0.01) {
// //         setState(() {
// //           _scrollProgress = progress;
// //         });
// //       }
// //     }
// //   }

// //   void _updateActiveHeading() {
// //     if (!mounted || _headingKeys.isEmpty) return;
    
// //     int activeIndex = _headingKeys.length - 1;
// //     for (int i = 0; i < _headingKeys.length; i++) {
// //       final key = _headingKeys[i];
// //       final context = key.currentContext;
// //       if (context != null) {
// //         final box = context.findRenderObject() as RenderBox?;
// //         if (box != null) {
// //           final position = box.localToGlobal(Offset.zero).dy;
// //           // Consider heading active when it's within 100px from top or the user has passed it
// //           if (position > 0 && position < 250) {
// //             activeIndex = i;
// //             break;
// //           } else if (position < 0) {
// //             // User scrolled past this heading, continue to find the next one
// //             continue;
// //           } else if (position > 250 && i > activeIndex) {
// //             // If we're before the next heading and haven't found an active one, keep previous
// //             activeIndex = i > 0 ? i - 1 : 0;
// //             break;
// //           }
// //         }
// //       }
// //     }
    
// //     if (_currentSectionIndex != activeIndex) {
// //       setState(() => _currentSectionIndex = activeIndex);
// //       // Auto-scroll sidebar to keep active item visible
// //       if (_sideMenuController.hasClients) {
// //         final double itemHeight = 48.0; // Approximate height of each sidebar item
// //         final double targetOffset = (activeIndex * itemHeight) - _sideMenuController.position.viewportDimension / 2;
// //         _sideMenuController.animateTo(
// //           targetOffset.clamp(0.0, _sideMenuController.position.maxScrollExtent),
// //           duration: const Duration(milliseconds: 300),
// //           curve: Curves.easeOutCubic,
// //         );
// //       }
// //     }
// //   }

// //   Future<void> _checkFavorite() async {
// //     final prefs = await SharedPreferences.getInstance();
// //     final favorites = prefs.getStringList('favorites') ?? [];
// //     setState(() {
// //       _isFavorite = favorites.contains('${widget.args.category}/${widget.args.slug}');
// //     });
// //   }

// //   Future<void> _toggleFavorite() async {
// //     final prefs = await SharedPreferences.getInstance();
// //     final favorites = prefs.getStringList('favorites') ?? [];
// //     final key = '${widget.args.category}/${widget.args.slug}';
    
// //     if (_isFavorite) {
// //       favorites.remove(key);
// //       _showSnackBar('Removed from favorites');
// //     } else {
// //       favorites.add(key);
// //       _showSnackBar('Added to favorites');
// //     }
    
// //     await prefs.setStringList('favorites', favorites);
// //     setState(() {
// //       _isFavorite = !_isFavorite;
// //     });
// //   }

// //   Future<void> _loadTutorial() async {
// //     final slug = widget.args.slug;
// //     if (slug.isEmpty) {
// //       setState(() {
// //         _error = 'Invalid tutorial slug.';
// //         _isLoading = false;
// //       });
// //       return;
// //     }

// //     try {
// //       if (_cache.containsKey(slug)) {
// //         _data = _cache[slug];
// //       } else {
// //         final url = Uri.parse('$tutorialsBaseUrl$slug.json');
// //         debugPrint('Loading tutorial from: $url');
// //         final response = await http.get(url);

// //         if (response.statusCode == 200) {
// //           final json = jsonDecode(response.body);
// //           _data = _parseTutorialData(json);
// //           _cache[slug] = _data!;
// //           if (_cache.length > _maxCacheSize) {
// //             _cache.remove(_cache.keys.first);
// //           }
// //         } else {
// //           setState(() {
// //             _error = 'Failed to load tutorial: HTTP ${response.statusCode}';
// //             _isLoading = false;
// //           });
// //           return;
// //         }
// //       }
// //       _initializeFromData();
// //       setState(() => _isLoading = false);
// //       _animationController.forward();
// //     } catch (e) {
// //       setState(() {
// //         _error = 'Failed to load tutorial: $e';
// //         _isLoading = false;
// //       });
// //     }
// //   }

// //   TutorialData _parseTutorialData(Map<String, dynamic> json) {
// //     final contentList = <ContentItem>[];
// //     try {
// //       for (var item in json['content'] ?? []) {
// //         final type = item['type'];
// //         final value = item['value'];
// //         if (type == 'heading') {
// //           contentList.add(
// //             ContentItem(type: ContentType.heading, value: value as String),
// //           );
// //         } else if (type == 'text') {
// //           contentList.add(
// //             ContentItem(type: ContentType.text, value: value as String),
// //           );
// //         } else if (type == 'code') {
// //           contentList.add(
// //             ContentItem(
// //               type: ContentType.code,
// //               value: value as String,
// //               language: item['language'],
// //             ),
// //           );
// //         } else if (type == 'list') {
// //           final listValue = (value as List).join('\n');
// //           contentList.add(
// //             ContentItem(type: ContentType.list, value: listValue),
// //           );
// //         }
// //       }
// //     } catch (e) {
// //       debugPrint('Error parsing content: $e');
// //     }

// //     final quizList = <QuizQuestion>[];
// //     try {
// //       for (var q in json['quiz'] ?? []) {
// //         quizList.add(
// //           QuizQuestion(
// //             question: q['question'],
// //             options: List<String>.from(q['options']),
// //             answer: q['answer'],
// //             explanation: q['explanation'],
// //           ),
// //         );
// //       }
// //     } catch (e) {
// //       debugPrint('Error parsing quiz: $e');
// //     }

// //     return TutorialData(
// //       title: json['title'] ?? 'Untitled',
// //       subtitle: json['subtitle'] ?? '',
// //       difficulty: json['difficulty'] ?? '',
// //       readTime: json['readTime'] ?? '',
// //       meta: json['meta'],
// //       faq: (json['faq'] as List?)?.cast<Map<String, dynamic>>() ?? [],
// //       content: contentList,
// //       quiz: quizList,
// //       defaultCode: json['tryEditor']?['defaultCode'] ?? '',
// //       relatedSlugs: (json['related'] as List?)?.cast<String>() ?? [],
// //     );
// //   }

// //   void _initializeFromData() {
// //     if (_data == null) return;
// //     _quizStates = List.generate(_data!.quiz.length, (_) => QuizQuestionState());
// //     _codeController.text = _data!.defaultCode;
// //     _headingKeys.clear();
// //     for (var i = 0; i < _data!.content.length; i++) {
// //       if (_data!.content[i].type == ContentType.heading) {
// //         _headingKeys.add(GlobalKey());
// //       }
// //     }
// //     _updateSeo();
// //     _updateStructuredData();

// //     if (kIsWeb) {
// //       _addHiddenH1(_data!.title);
// //       _injectFaqHtml();
// //       _injectInternalLinks();
// //       _injectContentHtml();

// //       final parents = [
// //         {
// //           'name': '${widget.args.category.toUpperCase()} Tutorials',
// //           'url': 'https://revochamp.site/tech/${widget.args.category}',
// //         },
// //       ];
// //       MetaService.setBreadcrumbData(
// //         title: _data!.title,
// //         slug: '${widget.args.category}/${widget.args.slug}',
// //         parents: parents,
// //       );
// //     }
// //   }

// //   void _addHiddenH1(String text) {
// //     final existing = html.document.querySelector('h1.seo-hidden');
// //     existing?.remove();

// //     final h1 = html.HeadingElement.h1()
// //       ..text = text
// //       ..className = 'seo-hidden'
// //       ..style.position = 'absolute'
// //       ..style.left = '-9999px'
// //       ..style.top = '-9999px'
// //       ..style.width = '1px'
// //       ..style.height = '1px'
// //       ..style.overflow = 'hidden';

// //     html.document.body?.append(h1);
// //   }

// //   void _injectInternalLinks() {
// //     if (!kIsWeb || _data == null) return;

// //     final div = html.DivElement()
// //       ..style.position = 'absolute'
// //       ..style.left = '-9999px';

// //     for (var slug in _data!.relatedSlugs) {
// //       final a = html.AnchorElement()
// //         ..href = '/${widget.args.category}/$slug'
// //         ..text = slug;
// //       div.append(a);
// //     }

// //     html.document.body?.append(div);
// //   }

// //   void _injectContentHtml() {
// //     if (!kIsWeb || _data == null) return;

// //     final div = html.DivElement()
// //       ..style.position = 'absolute'
// //       ..style.left = '-9999px';

// //     for (var item in _data!.content) {
// //       if (item.type == ContentType.text || item.type == ContentType.heading) {
// //         div.append(html.ParagraphElement()..text = item.value);
// //       }
// //     }

// //     html.document.body?.append(div);
// //   }

// //   void _injectFaqHtml() {
// //     if (!kIsWeb || _data == null || _data!.faq.isEmpty) return;

// //     final container = html.DivElement()
// //       ..style.position = 'absolute'
// //       ..style.left = '-9999px';

// //     for (var f in _data!.faq) {
// //       final q = html.HeadingElement.h2()..text = f['question'];
// //       final a = html.ParagraphElement()..text = f['answer'];
// //       container.append(q);
// //       container.append(a);
// //     }

// //     html.document.body?.append(container);
// //   }

// //   void _updateSeo() {
// //     if (!kIsWeb) return;

// //     String description =
// //         'Learn ${_data!.title} with this interactive ${widget.args.category} tutorial.';
// //     if (_data!.content.isNotEmpty) {
// //       final firstText = _data!.content.firstWhere(
// //         (item) => item.type == ContentType.text,
// //         orElse: () => ContentItem(type: ContentType.text, value: description),
// //       );
// //       description = firstText.value.substring(
// //         0,
// //         min(160, firstText.value.length),
// //       );
// //     }

// //     final metaTitle =
// //         _data!.meta?['title'] ??
// //         '${_data!.title} - ${widget.args.category.toUpperCase()} Tutorials';
// //     final metaDescription = _data!.meta?['description'] ?? description;
// //     final imageUrl =
// //         _data!.meta?['image'] ?? 'https://revochamp.site/banner.png';

// //     MetaService.updateMetaTags(
// //       title: metaTitle,
// //       description: metaDescription,
// //       slug: '${widget.args.category}/${widget.args.slug}',
// //       keywords: [widget.args.category, 'tutorial', _data!.title.toLowerCase()],
// //       isArticle: true,
// //       imageUrl: imageUrl,
// //     );

// //     MetaService.setOGTags(
// //       title: metaTitle,
// //       description: metaDescription,
// //       image: imageUrl,
// //     );

// //     MetaService.setTwitterTags(
// //       title: metaTitle,
// //       description: metaDescription,
// //       image: imageUrl,
// //     );
// //   }

// //   void _updateStructuredData() {
// //     final baseUrl = 'https://revochamp.site/tech';
// //     final pageId = 'https://revochamp.site/tech/${widget.args.category}/${widget.args.slug}';
    
// //     final structuredData = {
// //       "@context": "https://schema.org",
// //       "@type": "TechArticle",
// //       "headline": _data!.title,
// //       "description": _getDescription(),
// //       "author": {
// //         "@type": "Person",
// //         "name": "${widget.args.category.toUpperCase()} Tutorials Team",
// //       },
// //       "datePublished": _data!.meta?['datePublished'] ?? "2025-01-01",
// //       "dateModified":
// //           _data!.meta?['dateModified'] ?? DateTime.now().toIso8601String(),
// //       "image": _data!.meta?['image'] ?? "$baseUrl/icon.png",
// //       "publisher": {
// //         "@type": "Organization",
// //         "name": "Revochamp",
// //         "logo": {"@type": "ImageObject", "url": "$baseUrl/logo.png"},
// //       },
// //       "mainEntityOfPage": {"@type": "WebPage", "@id": pageId},
// //     };

// //     if (_data!.faq.isNotEmpty) {
// //       final graph = [
// //         structuredData,
// //         {
// //           "@type": "FAQPage",
// //           "mainEntity": _data!.faq
// //               .map(
// //                 (f) => {
// //                   "@type": "Question",
// //                   "name": f['question'],
// //                   "acceptedAnswer": {"@type": "Answer", "text": f['answer']},
// //                 },
// //               )
// //               .toList(),
// //         },
// //       ];
// //       MetaService.setStructuredData({
// //         "@context": "https://schema.org",
// //         "@graph": graph,
// //       });
// //     } else {
// //       MetaService.setStructuredData(structuredData);
// //     }
// //   }

// //   String _getDescription() {
// //     if (_data!.content.isNotEmpty) {
// //       final textItem = _data!.content.firstWhere(
// //         (item) => item.type == ContentType.text,
// //         orElse: () => ContentItem(type: ContentType.text, value: ''),
// //       );
// //       final value = textItem.value;
// //       return value.substring(0, min(160, value.length));
// //     }
// //     return 'Interactive ${widget.args.category} tutorial about ${_data!.title}.';
// //   }

// //   void _submitQuiz() {
// //     if (_quizStates.any((state) => state.selectedAnswer == null)) {
// //       _showSnackBar('Please answer all questions');
// //       return;
// //     }

// //     int score = 0;
// //     for (int i = 0; i < _data!.quiz.length; i++) {
// //       final isCorrect = _quizStates[i].selectedAnswer == _data!.quiz[i].answer;
// //       _quizStates[i].isCorrect = isCorrect;
// //       _quizStates[i].explanation = _data!.quiz[i].explanation;
// //       if (isCorrect) score++;
// //     }

// //     setState(() {
// //       _score = score;
// //       _quizSubmitted = true;
// //     });
// //     _markCompleted();
// //   }

// //   Future<void> _markCompleted() async {
// //     final prefs = await SharedPreferences.getInstance();
// //     final key = 'completed_${widget.args.category}';
// //     final completed = prefs.getStringList(key) ?? [];
// //     if (!completed.contains(widget.args.slug)) {
// //       completed.add(widget.args.slug);
// //       await prefs.setStringList(key, completed);
// //     }
// //   }

// //   void _resetQuiz() {
// //     setState(() {
// //       _quizStates = List.generate(
// //         _data!.quiz.length,
// //         (_) => QuizQuestionState(),
// //       );
// //       _quizSubmitted = false;
// //       _score = 0;
// //     });
// //   }

// //   void _copyCode(String code) {
// //     Clipboard.setData(ClipboardData(text: code));
// //     _showSnackBar('Copied to clipboard');
// //   }

// //   void _goToPrevious() {
// //     final topics = widget.args.allTopics;
// //     if (topics.isEmpty) {
// //       _showSnackBar('Loading topics... please wait');
// //       return;
// //     }
// //     final currentIndex = topics.indexWhere((t) => t.slug == widget.args.slug);

// //     if (currentIndex > 0) {
// //       final previousSlug = topics[currentIndex - 1].slug;
// //       context.go('/${widget.args.category}/$previousSlug');
// //     } else {
// //       _showSnackBar('This is the first tutorial');
// //     }
// //   }

// //   void _goToNext() {
// //     final topics = widget.args.allTopics;
// //     if (topics.isEmpty) {
// //       _showSnackBar('Loading topics... please wait');
// //       return;
// //     }
// //     final currentIndex = topics.indexWhere((t) => t.slug == widget.args.slug);

// //     if (currentIndex < topics.length - 1) {
// //       final nextSlug = topics[currentIndex + 1].slug;
// //       context.go('/${widget.args.category}/$nextSlug');
// //     } else {
// //       _showSnackBar('🎉 Congratulations! You completed all tutorials!');
// //     }
// //   }

// //   void _shareTutorial() {
// //     final url =
// //         'https://revochamp.site/tech/${widget.args.category}/${widget.args.slug}';
// //     final title = _data!.title;

// //     if (kIsWeb && html.window.navigator.share != null) {
// //       html.window.navigator.share!({'title': title, 'url': url})
// //           .catchError((error) {
// //             _fallbackShare(url);
// //           });
// //     } else {
// //       _fallbackShare(url);
// //     }
// //   }

// //   void _fallbackShare(String url) {
// //     Clipboard.setData(ClipboardData(text: url));
// //     _showSnackBar('Link copied to clipboard!');
// //   }

// //   void _showSnackBar(String message) {
// //     if (!mounted) return;
// //     ScaffoldMessenger.of(context).showSnackBar(
// //       SnackBar(
// //         content: Text(message),
// //         behavior: SnackBarBehavior.floating,
// //         backgroundColor: PremiumTheme.richBlue,
// //         duration: const Duration(seconds: 2),
// //         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
// //       ),
// //     );
// //   }

// //   List<ContentItem> get _headings =>
// //       _data?.content
// //           .where((item) => item.type == ContentType.heading)
// //           .toList() ??
// //       [];

// //   void _scrollToHeading(int index) {
// //     if (index < _headingKeys.length &&
// //         _headingKeys[index].currentContext != null) {
// //       Scrollable.ensureVisible(
// //         _headingKeys[index].currentContext!,
// //         duration: const Duration(milliseconds: 400),
// //         curve: Curves.easeInOutCubic,
// //       );
// //       setState(() => _currentSectionIndex = index);
// //     }
// //   }

// //   // ==================== BUILD METHODS ====================

// //   @override
// //   Widget build(BuildContext context) {
// //     if (_isLoading) return _buildLoadingScreen();
// //     if (_error != null) return _buildErrorScreen();

// //     final isDesktop = MediaQuery.of(context).size.width > 1000;

// //     return Scaffold(
// //       backgroundColor: Colors.white,
// //       appBar: _buildAppBar(),
// //       body: isDesktop ? _buildDesktopLayout() : _buildMobileLayout(),
// //     );
// //   }

// //   PreferredSizeWidget _buildAppBar() {
// //     return AppBar(
// //       title: Text(
// //         _data?.title ?? 'Tutorial',
// //         style: const TextStyle(
// //           fontSize: 16,
// //           fontWeight: FontWeight.w600,
// //           color: PremiumTheme.textDark,
// //         ),
// //         overflow: TextOverflow.ellipsis,
// //       ),
// //       backgroundColor: Colors.white,
// //       elevation: 0,
// //       centerTitle: false,
// //       leading: IconButton(
// //         icon: const Icon(Icons.arrow_back_rounded, color: PremiumTheme.textDark),
// //         onPressed: () {
// //           if (context.canPop()) {
// //             context.pop();
// //           } else {
// //             context.go('/${widget.args.category}');
// //           }
// //         },
// //       ),
// //       actions: [
// //         // Share button
// //         IconButton(
// //           icon: const Icon(Icons.share_rounded, color: PremiumTheme.textDark),
// //           onPressed: _shareTutorial,
// //           tooltip: 'Share',
// //         ),
// //         // Favorite button
// //         IconButton(
// //           icon: Icon(
// //             _isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
// //             color: _isFavorite ? Colors.red : PremiumTheme.textDark,
// //           ),
// //           onPressed: _toggleFavorite,
// //           tooltip: _isFavorite ? 'Remove from favorites' : 'Add to favorites',
// //         ),
// //         const SizedBox(width: 4),
// //       ],
// //       bottom: PreferredSize(
// //         preferredSize: const Size.fromHeight(2),
// //         child: LinearProgressIndicator(
// //           value: _scrollProgress,
// //           minHeight: 2,
// //           backgroundColor: PremiumTheme.lightGray,
// //           valueColor: const AlwaysStoppedAnimation(PremiumTheme.richBlue),
// //         ),
// //       ),
// //     );
// //   }

// //   Widget _buildLoadingScreen() {
// //     return Scaffold(
// //       backgroundColor: Colors.white,
// //       body: Center(
// //         child: Column(
// //           mainAxisAlignment: MainAxisAlignment.center,
// //           children: [
// //             SizedBox(
// //               width: 44,
// //               height: 44,
// //               child: CircularProgressIndicator(
// //                 strokeWidth: 2,
// //                 valueColor: const AlwaysStoppedAnimation(PremiumTheme.richBlue),
// //                 backgroundColor: PremiumTheme.lightGray,
// //               ),
// //             ),
// //             const SizedBox(height: 16),
// //             const Text(
// //               'Loading tutorial...',
// //               style: TextStyle(
// //                 color: PremiumTheme.textMuted,
// //                 fontSize: 14,
// //                 fontWeight: FontWeight.w500,
// //               ),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }

// //   Widget _buildErrorScreen() {
// //     return Scaffold(
// //       backgroundColor: Colors.white,
// //       body: Center(
// //         child: Container(
// //           margin: const EdgeInsets.all(24),
// //           padding: const EdgeInsets.all(32),
// //           decoration: BoxDecoration(
// //             color: Colors.white,
// //             borderRadius: BorderRadius.circular(24),
// //             border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
// //             boxShadow: [
// //               BoxShadow(
// //                 color: Colors.black.withValues(alpha: 0.04),
// //                 blurRadius: 12,
// //                 offset: const Offset(0, 3),
// //               ),
// //             ],
// //           ),
// //           child: Column(
// //             mainAxisSize: MainAxisSize.min,
// //             children: [
// //               Container(
// //                 width: 64,
// //                 height: 64,
// //                 decoration: BoxDecoration(
// //                   color: Colors.red.withValues(alpha: 0.1),
// //                   borderRadius: BorderRadius.circular(20),
// //                 ),
// //                 child: const Icon(
// //                   Icons.error_outline_rounded,
// //                   color: Colors.redAccent,
// //                   size: 32,
// //                 ),
// //               ),
// //               const SizedBox(height: 20),
// //               Text(
// //                 _error!,
// //                 style: const TextStyle(
// //                   color: PremiumTheme.textMuted,
// //                   fontSize: 14,
// //                 ),
// //                 textAlign: TextAlign.center,
// //               ),
// //               const SizedBox(height: 24),
// //               ElevatedButton(
// //                 onPressed: () {
// //                   setState(() => _isLoading = true);
// //                   _loadTutorial();
// //                 },
// //                 style: ElevatedButton.styleFrom(
// //                   backgroundColor: PremiumTheme.richBlue,
// //                   foregroundColor: Colors.white,
// //                   padding: const EdgeInsets.symmetric(
// //                     horizontal: 32,
// //                     vertical: 12,
// //                   ),
// //                   shape: RoundedRectangleBorder(
// //                     borderRadius: BorderRadius.circular(12),
// //                   ),
// //                 ),
// //                 child: const Text('Try Again'),
// //               ),
// //             ],
// //           ),
// //         ),
// //       ),
// //     );
// //   }

// //   Widget _buildDesktopLayout() {
// //     return Row(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         // Sidebar Navigation
// //         SizedBox(
// //           width: 280,
// //           child: Container(
// //             margin: const EdgeInsets.all(20),
// //             decoration: BoxDecoration(
// //               color: Colors.white,
// //               borderRadius: BorderRadius.circular(16),
// //               border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
// //               boxShadow: [
// //                 BoxShadow(
// //                   color: Colors.black.withValues(alpha: 0.04),
// //                   blurRadius: 12,
// //                   offset: const Offset(0, 3),
// //                 ),
// //               ],
// //             ),
// //             child: Column(
// //               children: [
// //                 // Sidebar Header
// //                 Container(
// //                   padding: const EdgeInsets.fromLTRB(18, 20, 18, 12),
// //                   child: Row(
// //                     children: [
// //                       Container(
// //                         width: 32,
// //                         height: 32,
// //                         decoration: BoxDecoration(
// //                           gradient: const LinearGradient(
// //                             begin: Alignment.topLeft,
// //                             end: Alignment.bottomRight,
// //                             colors: [PremiumTheme.richBlue, Color(0xff1e40af)],
// //                           ),
// //                           borderRadius: BorderRadius.circular(8),
// //                         ),
// //                         child: const Icon(
// //                           Icons.menu_book_rounded,
// //                           color: Colors.white,
// //                           size: 16,
// //                         ),
// //                       ),
// //                       const SizedBox(width: 10),
// //                       const Expanded(
// //                         child: Text(
// //                           'Contents',
// //                           style: TextStyle(
// //                             fontSize: 14,
// //                             fontWeight: FontWeight.w700,
// //                             color: PremiumTheme.textDark,
// //                             letterSpacing: 0.3,
// //                           ),
// //                         ),
// //                       ),
// //                       Container(
// //                         padding: const EdgeInsets.symmetric(
// //                           horizontal: 8,
// //                           vertical: 4,
// //                         ),
// //                         decoration: BoxDecoration(
// //                           color: PremiumTheme.richBlue.withValues(alpha: 0.1),
// //                           borderRadius: BorderRadius.circular(6),
// //                         ),
// //                         child: Text(
// //                           '${_headings.length}',
// //                           style: const TextStyle(
// //                             fontSize: 11,
// //                             fontWeight: FontWeight.w600,
// //                             color: PremiumTheme.richBlue,
// //                           ),
// //                         ),
// //                       ),
// //                     ],
// //                   ),
// //                 ),
// //                 Container(height: 1, color: PremiumTheme.lightGray),
// //                 // Topics List
// //                 Expanded(
// //                   child: ListView.builder(
// //                     controller: _sideMenuController,
// //                     padding: const EdgeInsets.symmetric(
// //                       horizontal: 12,
// //                       vertical: 12,
// //                     ),
// //                     itemCount: _headings.length,
// //                     itemBuilder: (context, index) {
// //                       final item = _headings[index];
// //                       final isActive = index == _currentSectionIndex;
// //                       return _buildSidebarItem(item.value, index, isActive);
// //                     },
// //                   ),
// //                 ),
// //                 // Progress Footer
// //                 Container(
// //                   padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
// //                   decoration: BoxDecoration(
// //                     border: Border(
// //                       top: BorderSide(color: PremiumTheme.lightGray),
// //                     ),
// //                   ),
// //                   child: Column(
// //                     children: [
// //                       Row(
// //                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                         children: [
// //                           const Text(
// //                             'Progress',
// //                             style: TextStyle(
// //                               fontSize: 12,
// //                               color: PremiumTheme.textMuted,
// //                             ),
// //                           ),
// //                           Text(
// //                             '${(_scrollProgress * 100).toInt()}%',
// //                             style: const TextStyle(
// //                               fontSize: 12,
// //                               fontWeight: FontWeight.w600,
// //                               color: PremiumTheme.richBlue,
// //                             ),
// //                           ),
// //                         ],
// //                       ),
// //                       const SizedBox(height: 8),
// //                       ClipRRect(
// //                         borderRadius: BorderRadius.circular(10),
// //                         child: LinearProgressIndicator(
// //                           value: _scrollProgress,
// //                           minHeight: 4,
// //                           backgroundColor: PremiumTheme.lightGray,
// //                           valueColor: const AlwaysStoppedAnimation(
// //                             PremiumTheme.richBlue,
// //                           ),
// //                         ),
// //                       ),
// //                     ],
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ),
// //         ),
// //         // Main Content
// //         Expanded(
// //           child: Center(
// //             child: ConstrainedBox(
// //               constraints: const BoxConstraints(maxWidth: 900),
// //               child: FadeTransition(
// //                 opacity: _fadeAnimation,
// //                 child: KeyedSubtree(
// //                   key: _contentKey,
// //                   child: Scrollbar(
// //                     controller: _scrollController,
// //                     thumbVisibility: true,
// //                     child: ListView(
// //                       controller: _scrollController,
// //                       padding: const EdgeInsets.fromLTRB(24, 24, 24, 40),
// //                       children: [
// //                         _buildHeroHeader(),
// //                         const SizedBox(height: 32),
// //                         ..._buildContentItems(),
// //                         const SizedBox(height: 32),
// //                         _buildEditorSection(),
// //                         const SizedBox(height: 48),
// //                         if (_data!.quiz.isNotEmpty) _buildQuizSection(),
// //                         if (_data!.faq.isNotEmpty) _buildFaqSection(),
// //                         if (_data!.relatedSlugs.isNotEmpty)
// //                           _buildRelatedSection(),
// //                         const SizedBox(height: 40),
// //                         _buildNavigationButtons(),
// //                         const SizedBox(height: 30),
// //                       ],
// //                     ),
// //                   ),
// //                 ),
// //               ),
// //             ),
// //           ),
// //         ),
// //       ],
// //     );
// //   }

// //   Widget _buildMobileLayout() {
// //     return Center(
// //       child: ConstrainedBox(
// //         constraints: const BoxConstraints(maxWidth: 900),
// //         child: FadeTransition(
// //           opacity: _fadeAnimation,
// //           child: KeyedSubtree(
// //             key: _contentKey,
// //             child: Scrollbar(
// //               controller: _scrollController,
// //               child: ListView(
// //                 controller: _scrollController,
// //                 padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
// //                 children: [
// //                   _buildHeroHeader(),
// //                   const SizedBox(height: 24),
// //                   if (_headings.isNotEmpty) _buildMobileToc(),
// //                   ..._buildContentItems(),
// //                   const SizedBox(height: 32),
// //                   _buildEditorSection(),
// //                   const SizedBox(height: 48),
// //                   if (_data!.quiz.isNotEmpty) _buildQuizSection(),
// //                   if (_data!.faq.isNotEmpty) _buildFaqSection(),
// //                   if (_data!.relatedSlugs.isNotEmpty) _buildRelatedSection(),
// //                   const SizedBox(height: 40),
// //                   _buildNavigationButtons(),
// //                   const SizedBox(height: 30),
// //                 ],
// //               ),
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }

// //   Widget _buildHeroHeader() {
// //     return Column(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         // Breadcrumb / Category
// //         GestureDetector(
// //           onTap: () => context.go('/${widget.args.category}'),
// //           child: Container(
// //             padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
// //             decoration: BoxDecoration(
// //               color: PremiumTheme.richBlue.withValues(alpha: 0.1),
// //               borderRadius: BorderRadius.circular(20),
// //               border: Border.all(
// //                 color: PremiumTheme.richBlue.withValues(alpha: 0.3),
// //               ),
// //             ),
// //             child: Row(
// //               mainAxisSize: MainAxisSize.min,
// //               children: [
// //                 const Icon(
// //                   Icons.folder_open_rounded,
// //                   size: 12,
// //                   color: PremiumTheme.richBlue,
// //                 ),
// //                 const SizedBox(width: 6),
// //                 Text(
// //                   widget.args.category.toUpperCase(),
// //                   style: const TextStyle(
// //                     fontSize: 11,
// //                     fontWeight: FontWeight.w600,
// //                     color: PremiumTheme.richBlue,
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ),
// //         ),
// //         const SizedBox(height: 24),
// //         // Title
// //         Text(
// //           _data!.title,
// //           style: const TextStyle(
// //             fontSize: 36,
// //             fontWeight: FontWeight.w800,
// //             color: PremiumTheme.textDark,
// //             letterSpacing: -0.5,
// //             height: 1.2,
// //           ),
// //         ),
// //         if (_data!.subtitle.isNotEmpty) ...[
// //           const SizedBox(height: 12),
// //           Text(
// //             _data!.subtitle,
// //             style: const TextStyle(
// //               fontSize: 16,
// //               color: PremiumTheme.textMuted,
// //               height: 1.5,
// //             ),
// //           ),
// //         ],
// //         const SizedBox(height: 20),
// //         // Metadata Row
// //         Wrap(
// //           spacing: 12,
// //           runSpacing: 10,
// //           children: [
// //             if (_data!.difficulty.isNotEmpty)
// //               _buildMetaChip(
// //                 icon: Icons.signal_cellular_alt_rounded,
// //                 label: _data!.difficulty,
// //                 color: _getDifficultyColor(_data!.difficulty),
// //               ),
// //             if (_data!.readTime.isNotEmpty)
// //               _buildMetaChip(
// //                 icon: Icons.access_time_rounded,
// //                 label: _data!.readTime,
// //               ),
// //             _buildMetaChip(
// //               icon: Icons.quiz_rounded,
// //               label: '${_data!.quiz.length} Quiz${_data!.quiz.length != 1 ? 'zes' : ''}',
// //             ),
// //             _buildMetaChip(
// //               icon: Icons.code_rounded,
// //               label: '${_data!.content.where((c) => c.type == ContentType.code).length} Examples',
// //             ),
// //           ],
// //         ),
// //         const SizedBox(height: 24),
// //         // Action Buttons
// //         Row(
// //           children: [
// //             Expanded(
// //               child: OutlinedButton.icon(
// //                 onPressed: _shareTutorial,
// //                 icon: const Icon(Icons.share_rounded, size: 18),
// //                 label: const Text('Share'),
// //                 style: OutlinedButton.styleFrom(
// //                   side: const BorderSide(color: PremiumTheme.lightGray, width: 1.5),
// //                   padding: const EdgeInsets.symmetric(vertical: 12),
// //                   shape: RoundedRectangleBorder(
// //                     borderRadius: BorderRadius.circular(12),
// //                   ),
// //                 ),
// //               ),
// //             ),
// //             const SizedBox(width: 12),
// //             Expanded(
// //               child: OutlinedButton.icon(
// //                 onPressed: _toggleFavorite,
// //                 icon: Icon(
// //                   _isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
// //                   size: 18,
// //                   color: _isFavorite ? Colors.red : PremiumTheme.textMuted,
// //                 ),
// //                 label: Text(
// //                   _isFavorite ? 'Saved' : 'Save',
// //                   style: TextStyle(
// //                     color: _isFavorite ? Colors.red : PremiumTheme.textMuted,
// //                   ),
// //                 ),
// //                 style: OutlinedButton.styleFrom(
// //                   side: BorderSide(
// //                     color: _isFavorite ? Colors.red : PremiumTheme.lightGray,
// //                     width: 1.5,
// //                   ),
// //                   padding: const EdgeInsets.symmetric(vertical: 12),
// //                   shape: RoundedRectangleBorder(
// //                     borderRadius: BorderRadius.circular(12),
// //                   ),
// //                 ),
// //               ),
// //             ),
// //           ],
// //         ),
// //       ],
// //     );
// //   }

// //   Widget _buildMetaChip({
// //     required IconData icon,
// //     required String label,
// //     Color? color,
// //   }) {
// //     return Container(
// //       padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
// //       decoration: BoxDecoration(
// //         color: PremiumTheme.softGray,
// //         borderRadius: BorderRadius.circular(20),
// //         border: Border.all(color: PremiumTheme.lightGray),
// //       ),
// //       child: Row(
// //         mainAxisSize: MainAxisSize.min,
// //         children: [
// //           Icon(icon, size: 14, color: color ?? PremiumTheme.richBlue),
// //           const SizedBox(width: 6),
// //           Text(
// //             label,
// //             style: TextStyle(
// //               fontSize: 12,
// //               fontWeight: FontWeight.w500,
// //               color: color ?? PremiumTheme.textMuted,
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }

// //   Color _getDifficultyColor(String difficulty) {
// //     switch (difficulty.toLowerCase()) {
// //       case 'beginner':
// //         return Colors.green;
// //       case 'intermediate':
// //         return Colors.orange;
// //       case 'advanced':
// //         return Colors.redAccent;
// //       default:
// //         return PremiumTheme.richBlue;
// //     }
// //   }

// //   Widget _buildSidebarItem(String title, int index, bool isActive) {
// //     return MouseRegion(
// //       cursor: SystemMouseCursors.click,
// //       child: GestureDetector(
// //         onTap: () {
// //           _scrollToHeading(index);
// //         },
// //         child: AnimatedContainer(
// //           duration: const Duration(milliseconds: 200),
// //           margin: const EdgeInsets.symmetric(vertical: 2),
// //           padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
// //           decoration: BoxDecoration(
// //             borderRadius: BorderRadius.circular(10),
// //             color: isActive ? PremiumTheme.richBlue.withValues(alpha: 0.1) : Colors.transparent,
// //           ),
// //           child: Row(
// //             children: [
// //               AnimatedContainer(
// //                 duration: const Duration(milliseconds: 200),
// //                 width: 3,
// //                 height: isActive ? 20 : 12,
// //                 decoration: BoxDecoration(
// //                   color: isActive ? PremiumTheme.richBlue : PremiumTheme.lightGray,
// //                   borderRadius: BorderRadius.circular(3),
// //                 ),
// //               ),
// //               const SizedBox(width: 12),
// //               Expanded(
// //                 child: Text(
// //                   title,
// //                   maxLines: 2,
// //                   overflow: TextOverflow.ellipsis,
// //                   style: TextStyle(
// //                     fontSize: 13,
// //                     fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
// //                     color: isActive ? PremiumTheme.richBlue : PremiumTheme.textMuted,
// //                     height: 1.4,
// //                   ),
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //       ),
// //     );
// //   }

// //   Widget _buildMobileToc() {
// //     return Container(
// //       margin: const EdgeInsets.only(bottom: 24),
// //       padding: const EdgeInsets.all(16),
// //       decoration: BoxDecoration(
// //         color: PremiumTheme.softGray,
// //         borderRadius: BorderRadius.circular(16),
// //         border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
// //       ),
// //       child: Column(
// //         crossAxisAlignment: CrossAxisAlignment.start,
// //         children: [
// //           Row(
// //             children: [
// //               Container(
// //                 width: 28,
// //                 height: 28,
// //                 decoration: BoxDecoration(
// //                   gradient: const LinearGradient(
// //                     begin: Alignment.topLeft,
// //                     end: Alignment.bottomRight,
// //                     colors: [PremiumTheme.richBlue, Color(0xff1e40af)],
// //                   ),
// //                   borderRadius: BorderRadius.circular(8),
// //                 ),
// //                 child: const Icon(
// //                   Icons.menu_book_rounded,
// //                   color: Colors.white,
// //                   size: 14,
// //                 ),
// //               ),
// //               const SizedBox(width: 10),
// //               const Text(
// //                 'Table of Contents',
// //                 style: TextStyle(
// //                   fontSize: 14,
// //                   fontWeight: FontWeight.w700,
// //                   color: PremiumTheme.textDark,
// //                 ),
// //               ),
// //             ],
// //           ),
// //           const SizedBox(height: 16),
// //           Wrap(
// //             spacing: 8,
// //             runSpacing: 8,
// //             children: _headings.asMap().entries.map((entry) {
// //               final idx = entry.key;
// //               final heading = entry.value;
// //               final hasValidKey = idx < _headingKeys.length;
// //               return GestureDetector(
// //                 onTap: hasValidKey ? () => _scrollToHeading(idx) : null,
// //                 child: Container(
// //                   padding: const EdgeInsets.symmetric(
// //                     horizontal: 12,
// //                     vertical: 7,
// //                   ),
// //                   decoration: BoxDecoration(
// //                     color: Colors.white,
// //                     borderRadius: BorderRadius.circular(20),
// //                     border: Border.all(color: PremiumTheme.lightGray),
// //                   ),
// //                   child: Text(
// //                     heading.value,
// //                     style: const TextStyle(
// //                       fontSize: 12,
// //                       color: PremiumTheme.richBlue,
// //                       fontWeight: FontWeight.w500,
// //                     ),
// //                   ),
// //                 ),
// //               );
// //             }).toList(),
// //           ),
// //         ],
// //       ),
// //     );
// //   }

// //   List<Widget> _buildContentItems() {
// //     List<Widget> widgets = [];
// //     int headingIdx = 0;

// //     for (int i = 0; i < _data!.content.length; i++) {
// //       final item = _data!.content[i];
      
// //       if (item.type == ContentType.heading) {
// //         widgets.add(
// //           Container(
// //             key: headingIdx < _headingKeys.length
// //                 ? _headingKeys[headingIdx]
// //                 : null,
// //             margin: const EdgeInsets.only(top: 16, bottom: 8),
// //             child: ContentItemWidget(item: item, onCopy: _copyCode),
// //           ),
// //         );
// //         headingIdx++;
// //       } else {
// //         widgets.add(
// //           Container(
// //             margin: const EdgeInsets.symmetric(vertical: 8),
// //             decoration: BoxDecoration(
// //               color: Colors.white,
// //               borderRadius: BorderRadius.circular(16),
// //               border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
// //             ),
// //             child: Padding(
// //               padding: const EdgeInsets.all(4),
// //               child: ContentItemWidget(item: item, onCopy: _copyCode),
// //             ),
// //           ),
// //         );
// //       }
// //       widgets.add(const SizedBox(height: 12));
// //     }
// //     return widgets;
// //   }

// //   Widget _buildEditorSection() {
// //     return Column(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         _buildSectionHeader(
// //           icon: Icons.edit_note_rounded,
// //           title: 'Try it Yourself',
// //           subtitle: 'Experiment with the code below',
// //         ),
// //         const SizedBox(height: 20),
// //         EditorWidget(
// //           codeController: _codeController,
// //           defaultCode: _data!.defaultCode,
// //           onCopy: _copyCode,
// //           onRun: () {
// //             _showSnackBar('Running your code...');
// //           },
// //           onReset: () =>
// //               setState(() => _codeController.text = _data!.defaultCode),
// //         ),
// //       ],
// //     );
// //   }

// //   Widget _buildQuizSection() {
// //     return Column(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         _buildSectionHeader(
// //           icon: Icons.quiz_rounded,
// //           title: 'Test Your Knowledge',
// //           subtitle: '${_data!.quiz.length} question${_data!.quiz.length != 1 ? 's' : ''} to check your understanding',
// //         ),
// //         const SizedBox(height: 20),
// //         for (int i = 0; i < _data!.quiz.length; i++)
// //           Padding(
// //             padding: const EdgeInsets.only(bottom: 16),
// //             child: QuizCard(
// //               index: i,
// //               total: _data!.quiz.length,
// //               question: _data!.quiz[i],
// //               state: _quizStates[i],
// //               submitted: _quizSubmitted,
// //               onAnswerSelected: (answerIndex) {
// //                 if (!_quizSubmitted) {
// //                   setState(() => _quizStates[i].selectedAnswer = answerIndex);
// //                 }
// //               },
// //             ),
// //           ),
// //         if (_quizSubmitted)
// //           Container(
// //             margin: const EdgeInsets.symmetric(vertical: 16),
// //             padding: const EdgeInsets.all(20),
// //             decoration: BoxDecoration(
// //               gradient: LinearGradient(
// //                 begin: Alignment.topLeft,
// //                 end: Alignment.bottomRight,
// //                 colors: [
// //                   PremiumTheme.richBlue.withValues(alpha: 0.05),
// //                   Colors.white,
// //                 ],
// //               ),
// //               borderRadius: BorderRadius.circular(16),
// //               border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
// //             ),
// //             child: Row(
// //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //               children: [
// //                 Column(
// //                   crossAxisAlignment: CrossAxisAlignment.start,
// //                   children: [
// //                     const Text(
// //                       'Your Score',
// //                       style: TextStyle(
// //                         fontSize: 12,
// //                         color: PremiumTheme.textMuted,
// //                       ),
// //                     ),
// //                     const SizedBox(height: 4),
// //                     Text(
// //                       '$_score/${_data!.quiz.length}',
// //                       style: const TextStyle(
// //                         fontSize: 28,
// //                         fontWeight: FontWeight.w800,
// //                         color: PremiumTheme.richBlue,
// //                       ),
// //                     ),
// //                   ],
// //                 ),
// //                 Container(
// //                   padding: const EdgeInsets.all(12),
// //                   decoration: BoxDecoration(
// //                     color: _score == _data!.quiz.length
// //                         ? Colors.green.withValues(alpha: 0.1)
// //                         : PremiumTheme.richBlue.withValues(alpha: 0.1),
// //                     borderRadius: BorderRadius.circular(12),
// //                   ),
// //                   child: Icon(
// //                     _score == _data!.quiz.length
// //                         ? Icons.emoji_events_rounded
// //                         : Icons.school_rounded,
// //                     color: _score == _data!.quiz.length
// //                         ? Colors.green
// //                         : PremiumTheme.richBlue,
// //                     size: 28,
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ),
// //         const SizedBox(height: 16),
// //         Row(
// //           children: [
// //             Expanded(
// //               child: ElevatedButton(
// //                 onPressed: _submitQuiz,
// //                 style: ElevatedButton.styleFrom(
// //                   backgroundColor: PremiumTheme.richBlue,
// //                   foregroundColor: Colors.white,
// //                   padding: const EdgeInsets.symmetric(vertical: 14),
// //                   shape: RoundedRectangleBorder(
// //                     borderRadius: BorderRadius.circular(12),
// //                   ),
// //                   elevation: 0,
// //                 ),
// //                 child: const Text('Submit Answers'),
// //               ),
// //             ),
// //             if (_quizSubmitted) ...[
// //               const SizedBox(width: 12),
// //               Expanded(
// //                 child: OutlinedButton(
// //                   onPressed: _resetQuiz,
// //                   style: OutlinedButton.styleFrom(
// //                     side: const BorderSide(color: PremiumTheme.lightGray, width: 1.5),
// //                     padding: const EdgeInsets.symmetric(vertical: 14),
// //                     shape: RoundedRectangleBorder(
// //                       borderRadius: BorderRadius.circular(12),
// //                     ),
// //                   ),
// //                   child: const Text('Try Again'),
// //                 ),
// //               ),
// //             ],
// //           ],
// //         ),
// //       ],
// //     );
// //   }

// //   Widget _buildFaqSection() {
// //     return Column(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         _buildSectionHeader(
// //           icon: Icons.help_center_rounded,
// //           title: 'Frequently Asked Questions',
// //           subtitle: 'Common questions about this topic',
// //         ),
// //         const SizedBox(height: 20),
// //         ..._data!.faq.asMap().entries.map((entry) {
// //           final index = entry.key;
// //           final item = entry.value;
// //           return Container(
// //             margin: const EdgeInsets.only(bottom: 12),
// //             decoration: BoxDecoration(
// //               color: Colors.white,
// //               borderRadius: BorderRadius.circular(16),
// //               border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
// //             ),
// //             child: Theme(
// //               data: Theme.of(context).copyWith(
// //                 dividerColor: Colors.transparent,
// //                 splashColor: Colors.transparent,
// //               ),
// //               child: ExpansionTile(
// //                 tilePadding: const EdgeInsets.symmetric(
// //                   horizontal: 18,
// //                   vertical: 4,
// //                 ),
// //                 childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
// //                 leading: Container(
// //                   width: 28,
// //                   height: 28,
// //                   decoration: BoxDecoration(
// //                     gradient: const LinearGradient(
// //                       begin: Alignment.topLeft,
// //                       end: Alignment.bottomRight,
// //                       colors: [PremiumTheme.richBlue, Color(0xff1e40af)],
// //                     ),
// //                     borderRadius: BorderRadius.circular(8),
// //                   ),
// //                   child: Center(
// //                     child: Text(
// //                       '${index + 1}',
// //                       style: const TextStyle(
// //                         color: Colors.white,
// //                         fontSize: 12,
// //                         fontWeight: FontWeight.w700,
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 title: Text(
// //                   item['question'] ?? '',
// //                   style: const TextStyle(
// //                     fontWeight: FontWeight.w600,
// //                     fontSize: 14,
// //                     color: PremiumTheme.textDark,
// //                   ),
// //                 ),
// //                 iconColor: PremiumTheme.textMuted,
// //                 collapsedIconColor: PremiumTheme.textLight,
// //                 children: [
// //                   const SizedBox(height: 8),
// //                   Text(
// //                     item['answer'] ?? '',
// //                     style: const TextStyle(
// //                       fontSize: 14,
// //                       color: PremiumTheme.textMuted,
// //                       height: 1.6,
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //             ),
// //           );
// //         }),
// //       ],
// //     );
// //   }

// //   Widget _buildRelatedSection() {
// //     return Column(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         _buildSectionHeader(
// //           icon: Icons.link_rounded,
// //           title: 'Related Tutorials',
// //           subtitle: 'Continue learning with these topics',
// //         ),
// //         const SizedBox(height: 20),
// //         Wrap(
// //           spacing: 10,
// //           runSpacing: 10,
// //           children: _data!.relatedSlugs.map((slug) {
// //             final displayName = slug
// //                 .replaceFirst('${widget.args.category}-', '')
// //                 .replaceAll('-', ' ')
// //                 .split(' ')
// //                 .map((word) => word[0].toUpperCase() + word.substring(1))
// //                 .join(' ');
            
// //             return GestureDetector(
// //               onTap: () {
// //                 context.go('/${widget.args.category}/$slug');
// //               },
// //               child: Container(
// //                 padding: const EdgeInsets.symmetric(
// //                   horizontal: 16,
// //                   vertical: 10,
// //                 ),
// //                 decoration: BoxDecoration(
// //                   color: PremiumTheme.softGray,
// //                   borderRadius: BorderRadius.circular(12),
// //                   border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
// //                 ),
// //                 child: Row(
// //                   mainAxisSize: MainAxisSize.min,
// //                   children: [
// //                     const Icon(
// //                       Icons.arrow_forward_rounded,
// //                       size: 14,
// //                       color: PremiumTheme.richBlue,
// //                     ),
// //                     const SizedBox(width: 8),
// //                     Text(
// //                       displayName,
// //                       style: const TextStyle(
// //                         fontSize: 13,
// //                         color: PremiumTheme.richBlue,
// //                         fontWeight: FontWeight.w500,
// //                       ),
// //                     ),
// //                   ],
// //                 ),
// //               ),
// //             );
// //           }).toList(),
// //         ),
// //       ],
// //     );
// //   }

// //   Widget _buildSectionHeader({
// //     required IconData icon,
// //     required String title,
// //     String? subtitle,
// //   }) {
// //     return Column(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         Row(
// //           children: [
// //             Container(
// //               width: 36,
// //               height: 36,
// //               decoration: BoxDecoration(
// //                 gradient: const LinearGradient(
// //                   begin: Alignment.topLeft,
// //                   end: Alignment.bottomRight,
// //                   colors: [PremiumTheme.richBlue, Color(0xff1e40af)],
// //                 ),
// //                 borderRadius: BorderRadius.circular(10),
// //               ),
// //               child: Icon(icon, color: Colors.white, size: 18),
// //             ),
// //             const SizedBox(width: 12),
// //             Text(
// //               title,
// //               style: const TextStyle(
// //                 fontSize: 24,
// //                 fontWeight: FontWeight.w800,
// //                 color: PremiumTheme.textDark,
// //                 letterSpacing: -0.3,
// //               ),
// //             ),
// //           ],
// //         ),
// //         if (subtitle != null) ...[
// //           const SizedBox(height: 8),
// //           Text(
// //             subtitle,
// //             style: const TextStyle(
// //               fontSize: 13,
// //               color: PremiumTheme.textMuted,
// //             ),
// //           ),
// //         ],
// //       ],
// //     );
// //   }

// //   Widget _buildNavigationButtons() {
// //     final topics = widget.args.allTopics;
// //     final currentIndex = topics.indexWhere((t) => t.slug == widget.args.slug);
// //     final isFirst = currentIndex <= 0;
// //     final isLast = currentIndex >= topics.length - 1;

// //     return Container(
// //       padding: const EdgeInsets.all(20),
// //       decoration: BoxDecoration(
// //         color: PremiumTheme.softGray,
// //         borderRadius: BorderRadius.circular(20),
// //         border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
// //       ),
// //       child: Row(
// //         children: [
// //           Expanded(
// //             child: OutlinedButton.icon(
// //               onPressed: isFirst ? null : _goToPrevious,
// //               icon: const Icon(Icons.arrow_back_rounded, size: 18),
// //               label: const Text('Previous'),
// //               style: OutlinedButton.styleFrom(
// //                 foregroundColor: isFirst ? PremiumTheme.textLight : PremiumTheme.textDark,
// //                 side: BorderSide(
// //                   color: isFirst ? PremiumTheme.lightGray : PremiumTheme.richBlue,
// //                   width: 1.5,
// //                 ),
// //                 padding: const EdgeInsets.symmetric(vertical: 14),
// //                 shape: RoundedRectangleBorder(
// //                   borderRadius: BorderRadius.circular(12),
// //                 ),
// //               ),
// //             ),
// //           ),
// //           const SizedBox(width: 16),
// //           Expanded(
// //             child: ElevatedButton.icon(
// //               onPressed: isLast ? null : _goToNext,
// //               icon: const Icon(Icons.arrow_forward_rounded, size: 18),
// //               label: Text(isLast ? 'Completed' : 'Next'),
// //               style: ElevatedButton.styleFrom(
// //                 backgroundColor: isLast ? Colors.green : PremiumTheme.richBlue,
// //                 foregroundColor: Colors.white,
// //                 padding: const EdgeInsets.symmetric(vertical: 14),
// //                 shape: RoundedRectangleBorder(
// //                   borderRadius: BorderRadius.circular(12),
// //                 ),
// //                 elevation: 0,
// //               ),
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// // }