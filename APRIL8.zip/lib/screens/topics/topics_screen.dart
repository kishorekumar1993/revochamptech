// lib/screens/topics/topics_screen.dart - SEO OPTIMIZED VERSION
import 'dart:async';
import 'dart:convert';
import 'dart:html' as html;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:techtutorial/core/meta_service.dart';

import '../../models/topic_screen_config.dart';
import '../../models/tutorial_topic.dart';
import '../../utils/json_parser.dart';
import '../../core/theme.dart';
import 'topic_card.dart';

// ==================== SEO CONFIGURATION ====================
class TopicSEOConfig {
  final String category;
  final int topicCount;
  final List<String> popularTopics;
  
  TopicSEOConfig({
    required this.category,
    required this.topicCount,
    required this.popularTopics,
  });
  
  String get canonicalUrl => 'https://revochamp.site/tech/${category.toLowerCase()}';
  String get ogImageUrl => 'https://revochamp.site/tech/og-images/${category.toLowerCase()}.png';
  
  String get pageTitle => 
      '${_capitalize(category)} Tutorials | Learn ${_capitalize(category)} Programming | RevoChamp';
  
  String get metaDescription => 
      'Master ${_capitalize(category)} with $topicCount+ free tutorials. '
      'Learn ${popularTopics.take(3).join(', ')}, and more. '
      'Step-by-step guides, practical examples, and best practices for beginners to advanced developers.';
  
  List<String> get keywords => [
    category.toLowerCase(),
    '$category tutorials',
    'learn $category',
    '$category programming',
    '$category guide',
    '$category examples',
    '$category course',
    '$category for beginners',
    'advanced $category',
    ...popularTopics.map((t) => '$category $t'),
    'free $category tutorials',
    'online $category course',
  ];
  
  static String _capitalize(String text) {
    if (text.isEmpty) return text;
    return text[0].toUpperCase() + text.substring(1);
  }
}

class TopicsScreen extends StatefulWidget {
  final String category;

  const TopicsScreen({super.key, required this.category});
  
  // ============ CACHE MANAGEMENT ============
  static final Map<String, List<TutorialTopic>> _cachedTopics = {};
  static final Map<String, TopicSEOConfig> _seoConfigCache = {};
  static bool _organizationSchemaSet = false;
  static bool _sitemapReferenceSet = false;
  static bool _preconnectSet = false;
  
  static List<TutorialTopic> getTopicsByCategory(String category) {
    return _cachedTopics[category.toLowerCase()] ?? [];
  }
  
  static void clearCache() {
    _cachedTopics.clear();
    _seoConfigCache.clear();
    _organizationSchemaSet = false;
  }

  @override
  State<TopicsScreen> createState() => _TopicsScreenState();
}

class _TopicsScreenState extends State<TopicsScreen>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  
  @override
  bool get wantKeepAlive => true;

  // Data
  List<TutorialTopic> allTopics = [];
  Map<String, List<TutorialTopic>> groupedTopics = {};
  Map<String, List<TutorialTopic>> groupedFilteredTopics = {};
  late TopicSEOConfig _seoConfig;

  // UI state
  final TextEditingController _searchController = TextEditingController();
  final Set<String> _completedTopics = {};
  bool _isLoading = true;
  String? _lastTopicSlug;
  Timer? _debounce;
  String _selectedDifficulty = 'All';
  String _searchQuery = '';

  ScreenConfig? _config;
  bool _isLoadingConfig = true;

  final ScrollController _scrollController = ScrollController();
  SharedPreferences? _prefs;

  late AnimationController _heroController;
  late Animation<double> _heroAnimation;

  // Pagination
  int _displayCount = 20;
  final int _itemsPerPage = 20;
  
  // Analytics tracking
  int _pageLoadStartTime = 0;
  int _scrollDepth = 0;

  @override
  void initState() {
    super.initState();
    _pageLoadStartTime = DateTime.now().millisecondsSinceEpoch;
    _seoConfig = TopicSEOConfig(
      category: widget.category,
      topicCount: 0,
      popularTopics: [],
    );
    _setupGlobalSEOOnce();
    _setupSEOTags();
    _loadConfiguration();
    _initAll();
    _setupAnimations();
    _scrollController.addListener(_onScroll);
    _trackPageView();
  }

  // ==================== GLOBAL SEO SETUP (RUN ONCE) ====================
  void _setupGlobalSEOOnce() {
    if (!kIsWeb) return;
    
    _setDocumentLanguage();
    _addSitemapReference();
    _addPreconnectUrls();
    _addResourceHints();
    _setVerificationTags();
  }

  void _setDocumentLanguage() {
    if (!kIsWeb) return;
    html.document.documentElement?.lang = 'en';
    html.document.documentElement?.setAttribute('prefix', 'og: http://ogp.me/ns#');
  }

  void _addSitemapReference() {
    if (!kIsWeb) return;
    if (TopicsScreen._sitemapReferenceSet) return;
    
    final existing = html.document.querySelector('link[rel="sitemap"]');
    if (existing != null) return;
    
    final sitemapLink = html.LinkElement()
      ..rel = 'sitemap'
      ..type = 'application/xml'
      ..href = 'https://revochamp.site/sitemap.xml';
    html.document.head?.append(sitemapLink);
    
    TopicsScreen._sitemapReferenceSet = true;
  }

  void _addPreconnectUrls() {
    if (!kIsWeb) return;
    if (TopicsScreen._preconnectSet) return;
    
    final urls = [
      'https://json.revochamp.site',
      'https://fonts.googleapis.com',
      'https://fonts.gstatic.com',
      'https://cdnjs.cloudflare.com',
    ];
    
    for (final url in urls) {
      final existing = html.document.querySelector('link[rel="preconnect"][href="$url"]');
      if (existing != null) continue;
      
      final link = html.LinkElement()
        ..rel = 'preconnect'
        ..href = url;
      html.document.head?.append(link);
      
      // Add DNS-prefetch as fallback
      final dnsLink = html.LinkElement()
        ..rel = 'dns-prefetch'
        ..href = url;
      html.document.head?.append(dnsLink);
    }
    
    TopicsScreen._preconnectSet = true;
  }

  void _addResourceHints() {
    if (!kIsWeb) return;
    
    // Preload critical fonts
    final fontPreload = html.LinkElement()
      ..rel = 'preload'
      ..as = 'font'
      ..href = 'https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxK.woff2'
      ..setAttribute('crossorigin', 'anonymous');
    html.document.head?.append(fontPreload);
  }

  void _setVerificationTags() {
    if (!kIsWeb) return;
    if (TopicsScreen._organizationSchemaSet) return;
    
    MetaService.setVerificationTags(
      google: 'YOUR_GOOGLE_VERIFICATION_CODE',
      bing: 'YOUR_BING_VERIFICATION_CODE',
    );
  }

  // ==================== PAGE-SPECIFIC SEO SETUP ====================
  void _setupSEOTags() {
    if (!kIsWeb) return;
    
    _addH1Tag();
    _updateMetaTags();
    _setOrganizationSchemaOnce();
    _setBreadcrumbSchema();
  }

  void _addH1Tag() {
    if (!kIsWeb) return;
    
    final existing = html.document.querySelector('.seo-h1');
    existing?.remove();

    final h1 = html.HeadingElement.h1()
      ..text = '${_capitalize(widget.category)} Tutorials - Learn ${_capitalize(widget.category)} Programming'
      ..className = 'seo-h1'
      ..style.position = 'absolute'
      ..style.left = '-9999px'
      ..style.top = '-9999px'
      ..style.width = '1px'
      ..style.height = '1px'
      ..style.overflow = 'hidden';

    html.document.body?.append(h1);
  }

  void _addH2Tag(String text) {
    if (!kIsWeb) return;
    
    final existing = html.document.querySelector('.seo-h2');
    existing?.remove();

    final h2 = html.HeadingElement.h2()
      ..text = text
      ..className = 'seo-h2'
      ..style.position = 'absolute'
      ..style.left = '-9999px'
      ..style.top = '-9999px'
      ..style.width = '1px'
      ..style.height = '1px'
      ..style.overflow = 'hidden';

    html.document.body?.append(h2);
  }

  void _updateMetaTags() {
    if (!kIsWeb) return;
    
    MetaService.updateMetaTags(
      title: _seoConfig.pageTitle,
      description: _seoConfig.metaDescription,
      slug: 'tech/${widget.category.toLowerCase()}',
      imageUrl: _seoConfig.ogImageUrl,
      keywords: _seoConfig.keywords,
      isArticle: false,
      noIndex: false,
    );
    
    MetaService.setCanonical(_seoConfig.canonicalUrl);
    
    // Add alternate language links
    MetaService.setAlternateLanguage(_seoConfig.canonicalUrl, 'en');
    MetaService.setAlternateLanguage('${_seoConfig.canonicalUrl}?hl=en', 'x-default');
  }

  void _updateSEOBasedOnData() {
    if (!kIsWeb) return;
    
    final popularTopics = allTopics
        .take(10)
        .map((t) => t.title)
        .toList();
    
    setState(() {
      _seoConfig = TopicSEOConfig(
        category: widget.category,
        topicCount: allTopics.length,
        popularTopics: popularTopics,
      );
    });
    
    _updateMetaTags();
    _updateCollectionPageSchema();
    _setFaqSchema();
    _addHowToSchema();
    _addVideoSchemaIfApplicable();
  }

  // ==================== SCHEMA.ORG MARKUP ====================
  void _setOrganizationSchemaOnce() {
    if (!kIsWeb) return;
    if (TopicsScreen._organizationSchemaSet) return;
    
    MetaService.setOrganizationSchema(
      logoUrl: 'https://revochamp.site/logo.png',
      description: 'RevoChamp - Free technology tutorials and comprehensive learning resources for modern developers',
    );
    
    MetaService.setWebsiteSchema();
    
    TopicsScreen._organizationSchemaSet = true;
  }

  void _updateCollectionPageSchema() {
    if (!kIsWeb) return;
    
    final items = allTopics.take(20).map((topic) {
      return {
        'name': topic.title,
        'url': 'https://revochamp.site/tech/${widget.category.toLowerCase()}/${topic.slug}',
        'description': 'Learn ${topic.title} - ${topic.emoji} tutorial with practical examples',
        'position': allTopics.indexOf(topic) + 1,
      };
    }).toList();
    
    MetaService.setStructuredData({
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      "name": "${_capitalize(widget.category)} Tutorials Library",
      "headline": "Comprehensive ${_capitalize(widget.category)} Learning Resources",
      "description": _seoConfig.metaDescription,
      "url": _seoConfig.canonicalUrl,
      "inLanguage": "en",
      "isPartOf": {
        "@type": "WebSite",
        "name": "RevoChamp",
        "url": "https://revochamp.site"
      },
      "mainEntity": {
        "@type": "ItemList",
        "numberOfItems": allTopics.length,
        "itemListElement": items.asMap().entries.map((entry) => {
          "@type": "ListItem",
          "position": entry.key + 1,
          "item": {
            "@type": "Article",
            "name": entry.value['name'],
            "url": entry.value['url'],
            "description": entry.value['description'],
          }
        }).toList(),
      },
      "about": {
        "@type": "Thing",
        "name": widget.category,
        "description": "Technology tutorials and programming resources for ${widget.category}"
      },
      "educationalLevel": ["Beginner", "Intermediate", "Advanced"],
      "teaches": widget.category,
    }, id: 'collection-page-schema');
  }

  void _setBreadcrumbSchema() {
    if (!kIsWeb) return;
    
    MetaService.setBreadcrumbData(
      title: _capitalize(widget.category),
      slug: 'tech/${widget.category.toLowerCase()}',
      parents: [
        {'name': 'Home', 'url': 'https://revochamp.site/'},
        {'name': 'Tech Tutorials', 'url': 'https://revochamp.site/tech'},
        {'name': 'All Courses', 'url': 'https://revochamp.site/tech/courses'},
      ],
    );
  }

  void _setFaqSchema() {
    if (!kIsWeb) return;
    
    // final faqs = _config?.faqs?.map((faq) => {
    //   'question': faq.question,
    //   'answer': faq.answer,
    // }).toList() ??
    
    final faqs =  _getDefaultFaqs();
    
    MetaService.setFAQSchemaFromMap(faqs);
  }

  List<Map<String, String>> _getDefaultFaqs() {
    final category = _capitalize(widget.category);
    return [
      {
        "question": "What is $category and why should I learn it?",
        "answer": "$category is a powerful technology used for modern application development. "
            "Learning $category opens doors to high-demand job opportunities, enables you to build "
            "scalable applications, and provides a strong foundation for your tech career. "
            "Our tutorials cover everything from basics to advanced concepts."
      },
      {
        "question": "How long does it take to learn $category?",
        "answer": "The basics of $category can be learned in 2-4 weeks with consistent practice "
            "(2-3 hours daily). Intermediate proficiency takes 2-3 months, while mastery requires "
            "6-12 months of regular coding and project building. Our structured learning path "
            "with ${allTopics.length} tutorials helps you progress efficiently."
      },
      {
        "question": "Is $category good for beginners with no programming experience?",
        "answer": "Yes! $category has excellent documentation, a supportive community, and many "
            "beginner-friendly resources. We recommend starting with our beginner tutorials that "
            "cover fundamental concepts. Take it step-by-step, practice regularly, and don't "
            "hesitate to join community forums for help."
      },
      {
        "question": "What can I build with $category?",
        "answer": "With $category, you can build web applications, mobile apps, desktop software, "
            "backend services, APIs, games, AI/ML applications, and more. The versatility of "
            "$category makes it valuable across web development, mobile development, cloud computing, "
            "and emerging technologies."
      },
      {
        "question": "Are these $category tutorials really free?",
        "answer": "Yes! All ${allTopics.length}+ tutorials on RevoChamp are completely free. "
            "We believe in democratizing tech education. You get full access to all tutorials, "
            "code examples, projects, and resources without any paywalls or subscriptions."
      },
      {
        "question": "Do you offer certificates for completing $category tutorials?",
        "answer": "Yes! You receive a free certificate of completion for each tutorial track "
            "you finish. These certificates can be shared on LinkedIn and added to your "
            "professional portfolio to showcase your $category skills to employers."
      },
      {
        "question": "How are your $category tutorials structured?",
        "answer": "Our tutorials are structured progressively from beginner to advanced levels. "
            "Each tutorial includes: clear learning objectives, step-by-step instructions, "
            "practical code examples, downloadable resources, hands-on exercises, and quizzes "
            "to test your understanding."
      },
    ];
  }

  void _addHowToSchema() {
    if (!kIsWeb) return;
    
    // Add HowTo schema for getting started guide
    MetaService.setHowToSchema(
      name: 'How to Start Learning ${_capitalize(widget.category)}',
      description: 'A step-by-step guide to begin your ${widget.category} learning journey',
      totalTime: 'PT2H',
      steps: [
        {
          'name': 'Choose Your Learning Path',
          'description': 'Select beginner-friendly tutorials from our curated list',
          'image': 'https://revochamp.site/images/step1.png',
        },
        {
          'name': 'Set Up Development Environment',
          'description': 'Follow our setup guide to install necessary tools',
          'image': 'https://revochamp.site/images/step2.png',
        },
        {
          'name': 'Start with Fundamentals',
          'description': 'Begin with basic concepts and simple exercises',
          'image': 'https://revochamp.site/images/step3.png',
        },
      ],
    );
  }

  void _addVideoSchemaIfApplicable() {
    // Add video schema if category has video content
    // if (allTopics.any((t) => t.hasVideo)) {
    //   MetaService.setVideoSchema(
    //     name: '${_capitalize(widget.category)} Tutorial Videos',
    //     description: 'Video tutorials for learning ${widget.category}',
    //     thumbnailUrl: 'https://revochamp.site/thumbnails/${widget.category}.jpg',
    //     contentUrl: 'https://revochamp.site/videos/${widget.category}/intro.mp4',
    //     embedUrl: 'https://www.youtube.com/embed/revochamp_${widget.category}',
    //     duration: const Duration(minutes: 45),
    //   );
    // }
  }

  // ==================== ANALYTICS TRACKING ====================
  void _trackPageView() {
    if (kReleaseMode) {
      // Send to analytics
      final loadTime = DateTime.now().millisecondsSinceEpoch - _pageLoadStartTime;
      debugPrint('📊 ${widget.category} page loaded in ${loadTime}ms');
    }
  }

  void _trackScrollDepth(double depth) {
    final percentage = (depth * 100).toInt();
    if (percentage > _scrollDepth) {
      _scrollDepth = percentage;
      if (kReleaseMode && percentage % 25 == 0) {
        debugPrint('📊 Scroll depth: $percentage%');
      }
    }
  }

  void _trackTopicClick(TutorialTopic topic) {
    if (kReleaseMode) {
      debugPrint('📊 Topic clicked: ${topic.title}');
    }
  }

  // ==================== LIFECYCLE ====================
  @override
  void didUpdateWidget(covariant TopicsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.category != widget.category) {
      _pageLoadStartTime = DateTime.now().millisecondsSinceEpoch;
      _seoConfig = TopicSEOConfig(
        category: widget.category,
        topicCount: 0,
        popularTopics: [],
      );
      _setupSEOTags();
      _resetAndReload();
    }
  }

  void _resetAndReload() {
    setState(() {
      _isLoading = true;
      allTopics = [];
      groupedTopics = {};
      groupedFilteredTopics = {};
      _completedTopics.clear();
      _searchQuery = '';
      _searchController.clear();
      _selectedDifficulty = 'All';
      _displayCount = 20;
    });
    _initAll();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _heroController.dispose();
    super.dispose();
  }

  // ==================== DATA LOADING ====================
  String getBaseUrl() => 'https://json.revochamp.site/${widget.category.toLowerCase()}/topics.json';
  String getConfigUrl() => 'https://json.revochamp.site/${widget.category.toLowerCase()}/config.json';

  void _setupAnimations() {
    _heroController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _heroAnimation = CurvedAnimation(
      parent: _heroController,
      curve: Curves.easeOutCubic,
    );
    _heroController.forward();
  }

  Future<void> _loadConfiguration() async {
    try {
      final response = await http.get(Uri.parse(getConfigUrl()))
          .timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            _config = ScreenConfig.fromJson(jsonData);
            _isLoadingConfig = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _config = ScreenConfig.getDefault();
            _isLoadingConfig = false;
          });
        }
      }
    } catch (e) {
      debugPrint('Error loading config: $e');
      if (mounted) {
        setState(() {
          _config = ScreenConfig.getDefault();
          _isLoadingConfig = false;
        });
      }
    }
  }

  Future<void> _initAll() async {
    final normalizedCategory = widget.category.toLowerCase();
    
    // Check cache first
    if (TopicsScreen._cachedTopics.containsKey(normalizedCategory)) {
      _applyData(
        topics: TopicsScreen._cachedTopics[normalizedCategory]!,
        completed: _completedTopics,
        lastTopic: _lastTopicSlug,
      );
      return;
    }

    try {
      _prefs = await SharedPreferences.getInstance();
      if (!mounted) return;

      final response = await http.get(Uri.parse(getBaseUrl()))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        throw Exception('HTTP ${response.statusCode}');
      }

      final topics = await compute(parseTopics, response.body);

      if (topics.isEmpty) {
        throw Exception('No topics found');
      }

      // Cache the results
      TopicsScreen._cachedTopics[normalizedCategory] = topics;

      final completedList = _prefs!.getStringList('completed_${widget.category}') ?? [];
      final lastTopic = _prefs!.getString('last_topic_${widget.category}');

      _applyData(
        topics: topics,
        completed: completedList,
        lastTopic: lastTopic,
      );
    } catch (e) {
      debugPrint('Error loading topics: $e');
      if (!mounted) return;
      _showErrorSnackbar('Failed to load topics. Please check your connection.');
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _applyData({
    required List<TutorialTopic> topics,
    required Iterable<String> completed,
    String? lastTopic,
  }) {
    final grouped = _groupTopicsSync(topics);
    
    if (mounted) {
      setState(() {
        allTopics = topics;
        groupedTopics = grouped;
        groupedFilteredTopics = grouped;
        _completedTopics.addAll(completed);
        _lastTopicSlug = lastTopic;
        _isLoading = false;
      });
      
      // Update SEO based on loaded data
      _updateSEOBasedOnData();
    }
  }

  // ==================== PAGINATION & FILTERS ====================
  void _onScroll() {
    if (!_scrollController.hasClients) return;
    
    final position = _scrollController.position;
    final maxExtent = position.maxScrollExtent;
    final currentPixels = position.pixels;
    
    // Track scroll depth
    _trackScrollDepth(currentPixels / maxExtent);
    
    // Load more when near bottom
    if (currentPixels >= maxExtent - 300) {
      _loadMore();
    }
  }

  void _loadMore() {
    if (!mounted) return;
    final totalItems = _getCurrentDisplayTopics().length;
    if (totalItems < _getTotalFilteredCount()) {
      setState(() {
        _displayCount += _itemsPerPage;
      });
      
      _addPaginationMeta();
    }
  }

  void _addPaginationMeta() {
    if (!kIsWeb) return;
    
    final currentPage = (_displayCount / _itemsPerPage).ceil();
    final totalPages = (_getTotalFilteredCount() / _itemsPerPage).ceil();
    
    // Remove existing pagination links
    html.document.querySelectorAll('link[rel="next"], link[rel="prev"]').forEach((e) => e.remove());
    
    final baseUrl = _seoConfig.canonicalUrl;
    
    if (currentPage < totalPages) {
      final nextLink = html.LinkElement()
        ..rel = 'next'
        ..href = '$baseUrl?page=${currentPage + 1}';
      html.document.head?.append(nextLink);
    }
    
    if (currentPage > 1) {
      final prevLink = html.LinkElement()
        ..rel = 'prev'
        ..href = currentPage == 2 ? baseUrl : '$baseUrl?page=${currentPage - 1}';
      html.document.head?.append(prevLink);
    }
  }

  int _getTotalFilteredCount() {
    return groupedFilteredTopics.values.fold(0, (sum, list) => sum + list.length);
  }

  List<TutorialTopic> _getCurrentDisplayTopics() {
    final allFiltered = groupedFilteredTopics.values.expand((list) => list).toList();
    return allFiltered.take(_displayCount).toList();
  }

  Map<String, List<TutorialTopic>> _groupTopicsSync(List<TutorialTopic> topics) {
    final map = <String, List<TutorialTopic>>{};
    for (final t in topics) {
      final category = t.category.isNotEmpty ? t.category : 'General Topics';
      map.putIfAbsent(category, () => []).add(t);
    }
    // Sort topics within each category
    for (final key in map.keys) {
      map[key]!.sort((a, b) => a.title.compareTo(b.title));
    }
    return map;
  }

  void _applyFilters() {
    if (!mounted) return;
    final query = _searchQuery.trim().toLowerCase();
    final filteredBySearch = query.isEmpty
        ? allTopics
        : allTopics.where((t) => 
            t.title.toLowerCase().contains(query) ||
            t.category.toLowerCase().contains(query)
          ).toList();

    final filtered = _selectedDifficulty == 'All'
        ? filteredBySearch
        : filteredBySearch.where((t) => t.level == _selectedDifficulty).toList();

    final grouped = _groupTopicsSync(filtered);

    setState(() {
      groupedFilteredTopics = grouped;
      _displayCount = 20;
    });
    
    _updateFilteredMeta();
  }

  void _updateFilteredMeta() {
    if (!kIsWeb) return;
    
    if (_searchQuery.isNotEmpty) {
      MetaService.updateMetaTags(
        title: 'Search: $_searchQuery - ${_capitalize(widget.category)} Tutorials',
        description: 'Found ${_getTotalFilteredCount()} results for "$_searchQuery" in ${widget.category}. Learn ${widget.category} with our comprehensive tutorials.',
        slug: 'tech/${widget.category.toLowerCase()}',
        isArticle: false,
        noIndex: true, // Prevent search result pages from being indexed
      );
    } else if (_selectedDifficulty != 'All') {
      MetaService.updateMetaTags(
        title: '$_selectedDifficulty Level ${_capitalize(widget.category)} Tutorials',
        description: 'Browse $_selectedDifficulty level ${widget.category} tutorials. Perfect for ${_selectedDifficulty.toLowerCase()} developers.',
        slug: 'tech/${widget.category.toLowerCase()}/difficulty/${_selectedDifficulty.toLowerCase()}',
        isArticle: false,
        noIndex: true,
      );
    } else {
      _updateMetaTags();
    }
    
    // Always set canonical to main category page to prevent duplicate content
    MetaService.setCanonical(_seoConfig.canonicalUrl);
  }

  void _onSearchChanged(String query) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), () {
      setState(() {
        _searchQuery = query;
      });
      _applyFilters();
    });
  }

  void _clearSearch() {
    setState(() {
      _searchQuery = "";
      _searchController.clear();
    });
    _applyFilters();
  }

  // ==================== PERSISTENCE ====================
  Future<void> _saveLastTopic(String slug) async {
    _prefs ??= await SharedPreferences.getInstance();
    await _prefs?.setString('last_topic_${widget.category}', slug);
  }

  Future<void> _saveCompletedTopics() async {
    _prefs ??= await SharedPreferences.getInstance();
    await _prefs?.setStringList('completed_${widget.category}', _completedTopics.toList());
  }

  // ==================== SHARING & UTILITIES ====================
  void _shareTopicsPage() {
    final url = _seoConfig.canonicalUrl;
    final title = '${_capitalize(widget.category)} Tutorials - RevoChamp';
    
    if (kIsWeb) {
      html.window.navigator.share!({
        'title': title,
        'text': 'Check out these free ${widget.category} tutorials!',
        'url': url,
      }).catchError((_) => _copyToClipboard(url));
    } else {
      _copyToClipboard(url);
    }
  }

  void _copyToClipboard(String text) {
    if (kIsWeb) {
      html.window.navigator.clipboard?.writeText(text);
    }
    _showSnackBar('📋 Link copied to clipboard!');
  }

  void _showErrorSnackbar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.red.shade600,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _showSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: PremiumTheme.richBlue,
        duration: const Duration(seconds: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  double get _progress =>
      allTopics.isEmpty ? 0 : _completedTopics.length / allTopics.length;

  void _scrollToTop() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
      );
    }
  }

  bool get isMobile => MediaQuery.of(context).size.width < 600;

  int _getGridCrossAxisCount(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1400) return 4;
    if (width >= 1000) return 3;
    if (width >= 600) return 2;
    return 1;
  }

  String _capitalize(String text) {
    if (text.isEmpty) return text;
    return text[0].toUpperCase() + text.substring(1);
  }

  String _getLastUpdatedDate() {
    return _formatDate(DateTime.now());
  }

  String _formatDate(DateTime date) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${months[date.month - 1]} ${date.year}';
  }

  List<Map<String, String>> _getRelatedCategories() {
    final relations = {
      'dart': [
        {'name': 'Flutter Basics', 'slug': 'flutter'},
        {'name': 'OOP Concepts', 'slug': 'oop'},
        {'name': 'Async Programming', 'slug': 'async'},
      ],
      'flutter': [
        {'name': 'Widgets', 'slug': 'widgets'},
        {'name': 'State Management', 'slug': 'state'},
        {'name': 'Animations', 'slug': 'animations'},
      ],
    };
    
    return relations[widget.category.toLowerCase()] ?? [];
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    super.build(context);
    
    final crossAxisCount = _getGridCrossAxisCount(context);
    final mobile = isMobile;
    final features = _config?.features ?? FeatureFlags.getDefault();
    final displayTopics = _getCurrentDisplayTopics();
    final hasMore = displayTopics.length < _getTotalFilteredCount();

    return Scaffold(
      backgroundColor: Colors.white,
      body: _isLoading || _isLoadingConfig
          ? _buildSkeletonLoader(mobile)
          : CustomScrollView(
              controller: _scrollController,
              slivers: [
                _buildAppBar(mobile),
                SliverToBoxAdapter(child: _buildBreadcrumbs(mobile)),
                if (features.showHeroSection)
                  SliverToBoxAdapter(
                    child: FadeTransition(
                      opacity: _heroAnimation,
                      child: _buildHeroSection(mobile),
                    ),
                  ),
                if (features.showProgressSection && allTopics.isNotEmpty)
                  SliverToBoxAdapter(child: _buildProgressSection(mobile)),
                if (features.showStatsSection && allTopics.isNotEmpty)
                  SliverToBoxAdapter(child: _buildStatsSection(mobile)),
                if (features.showContinueBanner &&
                    _lastTopicSlug != null &&
                    _lastTopicSlug!.isNotEmpty)
                  SliverToBoxAdapter(child: _buildContinueBanner(mobile)),
                if (features.showSearchFilters) ...[
                  SliverToBoxAdapter(child: _buildSearchSection(mobile)),
                  SliverToBoxAdapter(child: _buildDifficultyFilter(mobile)),
                ],
                if ((_searchQuery.isNotEmpty || _selectedDifficulty != 'All') &&
                    features.showSearchFilters)
                  SliverToBoxAdapter(child: _buildResultCount(mobile)),
                if (groupedFilteredTopics.isEmpty)
                  SliverToBoxAdapter(child: _buildEmptyState())
                else
                  ..._buildGroupedContent(crossAxisCount, mobile, displayTopics),
                if (hasMore)
                  const SliverToBoxAdapter(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Center(
                        child: SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      ),
                    ),
                  ),
                SliverToBoxAdapter(child: _buildRelatedCategories()),
                SliverToBoxAdapter(child: _buildLastUpdated()),
                SliverToBoxAdapter(child: _buildSeoFooter(mobile)),
                const SliverToBoxAdapter(child: SizedBox(height: 40)),
              ],
            ),
      floatingActionButton: features.showFloatingButton && allTopics.length > 10
          ? FloatingActionButton(
              mini: true,
              onPressed: _scrollToTop,
              backgroundColor: PremiumTheme.richBlue,
              child: const Icon(Icons.keyboard_arrow_up_rounded, color: Colors.white),
            )
          : null,
    );
  }

  Widget _buildSkeletonLoader(bool isMobile) {
    return CustomScrollView(
      slivers: [
        _buildAppBar(isMobile),
        SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 80, vertical: 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSkeletonBox(height: 40, width: 200),
                const SizedBox(height: 20),
                _buildSkeletonBox(height: 120),
                const SizedBox(height: 30),
                _buildSkeletonBox(height: 30, width: 150),
                const SizedBox(height: 20),
                ...List.generate(4, (_) => _buildSkeletonBox(height: 80)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSkeletonBox({double height = 100, double? width}) {
    return Container(
      height: height,
      width: width,
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }

  List<Widget> _buildGroupedContent(int crossAxisCount, bool mobile, List<TutorialTopic> displayTopics) {
    final Map<String, List<TutorialTopic>> groupedDisplay = {};
    for (final topic in displayTopics) {
      final category = topic.category.isNotEmpty ? topic.category : 'General Topics';
      groupedDisplay.putIfAbsent(category, () => []).add(topic);
    }

    return groupedDisplay.entries.expand((entry) {
      final categoryName = entry.key;
      final topicsInCategory = entry.value;
      
      return [
        SliverToBoxAdapter(
          child: _buildCategoryHeader(categoryName, mobile),
        ),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final topic = topicsInCategory[index];
                final isCompleted = _completedTopics.contains(topic.slug);
                return TopicCard(
                  topic: topic,
                  isCompleted: isCompleted,
                  onTap: () async {
                    _trackTopicClick(topic);
                    if (!_completedTopics.contains(topic.slug)) {
                      setState(() {
                        _completedTopics.add(topic.slug);
                      });
                      await _saveCompletedTopics();
                    }
                    await _saveLastTopic(topic.slug);
                    if (context.mounted) {
                      context.go('/${widget.category.toLowerCase()}/${topic.slug}');
                    }
                  },
                );
              },
              childCount: topicsInCategory.length,
            ),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: crossAxisCount,
              childAspectRatio: 3.5,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 8)),
      ];
    }).toList();
  }

  // ==================== UI COMPONENTS ====================
  SliverAppBar _buildAppBar(bool isMobile) {
    return SliverAppBar(
      pinned: true,
      backgroundColor: Colors.white,
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
      title: _buildLogo(),
      centerTitle: false,
      actions: [
        IconButton(
          icon: const Icon(Icons.share, color: PremiumTheme.textMuted),
          onPressed: _shareTopicsPage,
          tooltip: 'Share this page',
        ),
        if (!isMobile) ...[
          TextButton(
            onPressed: () => context.go('/'),
            child: const Text("Home", style: TextStyle(color: PremiumTheme.textMuted, fontWeight: FontWeight.w500, fontSize: 14)),
          ),
          TextButton(
            onPressed: () => context.go('/courses'),
            child: const Text("All Courses", style: TextStyle(color: PremiumTheme.textMuted, fontWeight: FontWeight.w500, fontSize: 14)),
          ),
          const SizedBox(width: 20),
          OutlinedButton(
            onPressed: () => _showSnackBar("Login feature coming soon"),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: PremiumTheme.lightGray, width: 1.5),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text("Sign In", style: TextStyle(color: PremiumTheme.textMuted, fontWeight: FontWeight.w500, fontSize: 13)),
          ),
          const SizedBox(width: 10),
          ElevatedButton(
            onPressed: () => _showSnackBar("Sign up feature coming soon"),
            style: ElevatedButton.styleFrom(
              backgroundColor: PremiumTheme.richBlue,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              elevation: 0,
            ),
            child: const Text("Get Started", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
          ),
          const SizedBox(width: 24),
        ],
      ],
    );
  }

  Widget _buildLogo() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [PremiumTheme.richBlue, Color(0xff1e40af)],
            ),
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: PremiumTheme.richBlue.withValues(alpha: 0.2),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: const Center(child: Text("RC", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14))),
        ),
        const SizedBox(width: 10),
        const Text("RevoChamp", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: PremiumTheme.textDark)),
      ],
    );
  }

  Widget _buildBreadcrumbs(bool isMobile) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 80, vertical: 12),
      child: Row(
        children: [
          InkWell(
            onTap: () => context.go('/'),
            child: Text('Home', style: TextStyle(color: PremiumTheme.richBlue, fontSize: 13)),
          ),
          const Icon(Icons.chevron_right, size: 16, color: PremiumTheme.textLight),
          InkWell(
            onTap: () => context.go('/courses'),
            child: Text('Courses', style: TextStyle(color: PremiumTheme.richBlue, fontSize: 13)),
          ),
          const Icon(Icons.chevron_right, size: 16, color: PremiumTheme.textLight),
          Text(
            _capitalize(widget.category),
            style: TextStyle(color: PremiumTheme.textMuted, fontSize: 13, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroSection(bool isMobile) {
    final hero = _config?.hero ?? HeroConfig.getDefault();
    final topicCount = allTopics.length;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 24 : 80, vertical: isMobile ? 40 : 50),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            PremiumTheme.richBlue.withValues(alpha: 0.05),
            Colors.white,
            PremiumTheme.softGray.withValues(alpha: 0.5),
          ],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: PremiumTheme.richBlue,
              borderRadius: BorderRadius.circular(50),
              boxShadow: [
                BoxShadow(
                  color: PremiumTheme.richBlue.withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Text(
              topicCount > 0 ? '$topicCount+ Free Tutorials' : hero.badge,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white),
            ),
          ),
          const SizedBox(height: 30),
          Text(
            'Master ${_capitalize(widget.category)}',
            style: TextStyle(
              fontSize: isMobile ? 36 : 48,
              fontWeight: FontWeight.w800,
              color: PremiumTheme.textDark,
              letterSpacing: -0.5,
              height: 1.1,
            ),
          ),
          const SizedBox(height: 8),
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [PremiumTheme.richBlue, Color(0xff1e40af)],
            ).createShader(bounds),
            child: Text(
              'From Zero to Hero',
              style: TextStyle(
                fontSize: isMobile ? 36 : 48,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                height: 1.1,
                letterSpacing: -0.5,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Container(
            constraints: const BoxConstraints(maxWidth: 600),
            child: Text(
              hero.description.replaceAll(
                '{category}',
                _capitalize(widget.category),
              ),
              style: TextStyle(
                fontSize: isMobile ? 15 : 16,
                color: PremiumTheme.textMuted,
                height: 1.6,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          if (hero.chips.isNotEmpty) ...[
            const SizedBox(height: 30),
            Wrap(
              spacing: 16,
              runSpacing: 12,
              children: hero.chips.map((chip) => _buildHeroChip(chip)).toList(),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildHeroChip(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: PremiumTheme.lightGray,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: PremiumTheme.lightGray),
      ),
      child: Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: PremiumTheme.textMuted)),
    );
  }

  Widget _buildStatsSection(bool isMobile) {
    final totalTopics = allTopics.length;
    final completedCount = _completedTopics.length;
    final totalHours = allTopics.fold<double>(0.0, (sum, topic) => sum + (topic.estimatedHours ?? 0.0));
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 80, vertical: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: PremiumTheme.softGray,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem("$totalTopics", "Topics"),
          Container(width: 1, height: 30, color: PremiumTheme.lightGray),
          _buildStatItem("$completedCount", "Completed"),
          Container(width: 1, height: 30, color: PremiumTheme.lightGray),
          _buildStatItem("${totalHours.toStringAsFixed(0)}+", "Hours"),
        ],
      ),
    );
  }

  Widget _buildStatItem(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: PremiumTheme.textDark)),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 11, color: PremiumTheme.textMuted, fontWeight: FontWeight.w500)),
      ],
    );
  }

  Widget _buildProgressSection(bool isMobile) {
    final pct = (_progress * 100).toInt();

    return Container(
      margin: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 80, vertical: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 12, offset: const Offset(0, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Your Learning Progress', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: PremiumTheme.textDark)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  gradient: PremiumTheme.elegantGradient,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '$pct% • ${_completedTopics.length}/${allTopics.length}',
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: _progress,
              backgroundColor: PremiumTheme.lightGray,
              color: PremiumTheme.richBlue,
              minHeight: 8,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _progress > 0.8
                ? "🎉 You're almost there! Keep pushing forward!"
                : _progress > 0.3
                ? "💪 Great progress! Keep learning, one topic at a time."
                : "🌟 Start your journey today. Every expert was once a beginner.",
            style: TextStyle(fontSize: 12, color: PremiumTheme.textMuted),
          ),
        ],
      ),
    );
  }

  Widget _buildContinueBanner(bool isMobile) {
    final lastTopic = allTopics.firstWhere(
      (t) => t.slug == _lastTopicSlug,
      orElse: () => allTopics.isNotEmpty ? allTopics.first : TutorialTopic(slug: '', title: '', emoji: '', estimatedHours: 0.0, category: '', level: ''),
    );
    if (lastTopic.slug.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 80, vertical: 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [PremiumTheme.success.withValues(alpha: 0.12), PremiumTheme.successBg.withValues(alpha: 0.06)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PremiumTheme.success.withValues(alpha: 0.25)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(colors: [Color(0xFF11998E), Color(0xFF38EF7D)]),
            boxShadow: [
              BoxShadow(color: const Color(0xFF11998E).withValues(alpha: 0.3), blurRadius: 10, offset: const Offset(0, 3)),
            ],
          ),
          child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 24),
        ),
        title: Text('Continue: ${lastTopic.title}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: PremiumTheme.textDark)),
        subtitle: const Text('Tap to resume where you left off', style: TextStyle(fontSize: 12, color: PremiumTheme.textMuted)),
        trailing: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(shape: BoxShape.circle, color: PremiumTheme.success.withValues(alpha: 0.12)),
          child: const Icon(Icons.arrow_forward_rounded, size: 16, color: PremiumTheme.success),
        ),
        onTap: () {
          _saveLastTopic(lastTopic.slug);
          if (context.mounted) {
            context.go('/${widget.category.toLowerCase()}/${lastTopic.slug}');
          }
        },
      ),
    );
  }

  Widget _buildSearchSection(bool isMobile) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 80, vertical: 16),
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: PremiumTheme.lightGray, width: 1.5),
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 12, offset: const Offset(0, 2)),
          ],
        ),
        child: Row(
          children: [
            const SizedBox(width: 16),
            const Icon(Icons.search, color: PremiumTheme.textLight, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                onChanged: _onSearchChanged,
                decoration: InputDecoration(
                  hintText: "Search ${allTopics.length}+ ${widget.category} topics...",
                  hintStyle: const TextStyle(color: PremiumTheme.textLight, fontSize: 13, fontWeight: FontWeight.w500),
                  border: InputBorder.none,
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              IconButton(
                icon: const Icon(Icons.clear, size: 18, color: PremiumTheme.textLight),
                onPressed: _clearSearch,
              ),
            Container(
              margin: const EdgeInsets.all(6),
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
              decoration: BoxDecoration(
                color: PremiumTheme.richBlue,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text("Search", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 12)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDifficultyFilter(bool isMobile) {
    final difficulties = _config?.difficulties ?? DifficultyConfig.getDefault();

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 80, vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildLevelChip('All Levels', _selectedDifficulty == 'All', () {
              setState(() => _selectedDifficulty = 'All');
              _applyFilters();
            }),
            const SizedBox(width: 10),
            ...difficulties.map((difficulty) {
              final isSelected = _selectedDifficulty == difficulty.name;
              return Padding(
                padding: const EdgeInsets.only(right: 10),
                child: _buildLevelChip(
                  difficulty.name,
                  isSelected,
                  () {
                    setState(() => _selectedDifficulty = difficulty.name);
                    _applyFilters();
                  },
                  icon: difficulty.icon,
                  color: difficulty.colorObj,
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildLevelChip(String label, bool isSelected, VoidCallback onTap, {String? icon, Color? color}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
        decoration: BoxDecoration(
          color: isSelected ? (color ?? PremiumTheme.richBlue) : Colors.transparent,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(
            color: isSelected ? (color ?? PremiumTheme.richBlue) : PremiumTheme.lightGray,
            width: 1.5,
          ),
          boxShadow: isSelected ? [
            BoxShadow(
              color: (color ?? PremiumTheme.richBlue).withValues(alpha: 0.25),
              blurRadius: 8,
              offset: const Offset(0, 3),
            )
          ] : [],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Text(icon, style: const TextStyle(fontSize: 14)),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                color: isSelected ? Colors.white : PremiumTheme.textMuted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultCount(bool isMobile) {
    final total = _getTotalFilteredCount();
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 80, vertical: 8),
      child: Text(
        'Showing $total result${total != 1 ? 's' : ''}',
        style: const TextStyle(fontSize: 12, color: PremiumTheme.textMuted, fontWeight: FontWeight.w500),
      ),
    );
  }

  Widget _buildCategoryHeader(String categoryName, bool isMobile) {
    return Padding(
      padding: EdgeInsets.fromLTRB(isMobile ? 20 : 20, 32, isMobile ? 20 : 20, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            categoryName,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: PremiumTheme.textDark, letterSpacing: -0.3),
          ),
          const SizedBox(height: 8),
          Container(
            width: 50,
            height: 3,
            decoration: BoxDecoration(
              gradient: PremiumTheme.elegantGradient,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(60),
        child: Column(
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(shape: BoxShape.circle, color: PremiumTheme.lightGray),
              child: const Center(child: Icon(Icons.search_off_rounded, size: 40, color: PremiumTheme.textLight)),
            ),
            const SizedBox(height: 20),
            const Text('No topics found', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: PremiumTheme.textDark)),
            const SizedBox(height: 8),
            Text(
              'Try adjusting your search or filter',
              textAlign: TextAlign.center,
              style: TextStyle(color: PremiumTheme.textMuted, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRelatedCategories() {
    final relatedCategories = _getRelatedCategories();
    if (relatedCategories.isEmpty) return const SizedBox.shrink();
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: PremiumTheme.softGray,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Explore More Topics', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: relatedCategories.map((category) {
              return ActionChip(
                label: Text(category['name']!),
                onPressed: () {
                  context.go('/tech/${category['slug']}');
                },
                backgroundColor: Colors.white,
                side: BorderSide(color: PremiumTheme.lightGray),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildLastUpdated() {
    final lastUpdated = _getLastUpdatedDate();
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.update, size: 12, color: PremiumTheme.textLight),
          const SizedBox(width: 4),
          Text(
            'Last updated: $lastUpdated',
            style: const TextStyle(fontSize: 11, color: PremiumTheme.textLight),
          ),
        ],
      ),
    );
  }

  Widget _buildSeoFooter(bool isMobile) {
    final seo = _config?.seo ?? SEOConfig.getDefault();

    return Container(
      margin: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 80, vertical: 40),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: PremiumTheme.softGray,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PremiumTheme.lightGray),
      ),
      child: Column(
        children: [
          Text(seo.emoji, style: const TextStyle(fontSize: 32)),
          const SizedBox(height: 12),
          Text(
            seo.title.replaceAll('{category}', _capitalize(widget.category)),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: PremiumTheme.textDark),
          ),
          const SizedBox(height: 12),
          Text(
            seo.description.replaceAll('{category}', widget.category),
            style: TextStyle(fontSize: 13, color: PremiumTheme.textMuted, height: 1.6),
            textAlign: TextAlign.center,
          ),
          if (seo.tags.isNotEmpty) ...[
            const SizedBox(height: 20),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              alignment: WrapAlignment.center,
              children: seo.tags.map((tag) => _buildSeoTag(tag)).toList(),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSeoTag(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: PremiumTheme.lightGray),
      ),
      child: Text(text, style: const TextStyle(fontSize: 11, color: PremiumTheme.textMuted, fontWeight: FontWeight.w500)),
    );
  }
}